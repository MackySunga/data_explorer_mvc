<?php
// app/Views/stats.php
$M = $fmt['meta'] ?? [];
$num = $fmt['stats_numeric'] ?? [];
$cat = $fmt['stats_categorical'] ?? [];

$columns = (int)($M['columns'] ?? 0);
$numericCols = (int)($M['numeric_columns'] ?? 0);
$categoricalCols = (int)($M['categorical_columns'] ?? 0);

// Build column lists for dropdowns
$numericNames = [];
foreach ($num as $r) $numericNames[] = (string)($r['column'] ?? '');

$catNames = [];
foreach ($cat as $r) $catNames[] = (string)($r['column'] ?? '');

// Missing top rows for chart
$missingTop = $fmt['missing_top'] ?? [];
?>
<div class="d-flex justify-content-between align-items-start mb-3">
  <div>
    <h1 class="h4 mb-1">Stats: <?= e($meta['name'] ?? '') ?></h1>
    <div class="text-muted small">
      Values shown here are formatted the same way as the PDF report.
      · Max rows used: <strong><?= (int)$maxRows ?></strong>
    </div>
  </div>

  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/table">Explore</a>
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/reports">Reports</a>
    <form method="post" action="?r=explore/report_save" class="d-inline">
      <input type="hidden" name="max_rows" value="<?= (int)$maxRows ?>">
      <button class="btn btn-primary btn-sm" type="submit">Save Report</button>
    </form>
  </div>
</div>

<div class="card shadow-sm mb-3">
  <div class="card-body">
    <form class="row g-2 align-items-end" method="get">
      <input type="hidden" name="r" value="explore/stats">

      <div class="col-sm-4 col-md-3">
        <label class="form-label">Max rows used for stats</label>
        <input id="maxRowsStats" name="max_rows" class="form-control" type="number" min="1000" max="200000" value="<?= (int)$maxRows ?>">
        <div class="form-text">Higher = more accurate, but slower.</div>
      </div>

      <div class="col-sm-3 col-md-2">
        <button class="btn btn-primary w-100" type="submit">Recompute</button>
      </div>

      <div class="col-sm-3 col-md-2">
        <a class="btn btn-outline-secondary w-100" href="?r=explore/table">Explore</a>
      </div>
    </form>
  </div>
</div>

<!-- SUMMARY CARDS -->
<div class="row g-3 mb-3">
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="text-muted small">Columns</div>
        <div class="h5 mb-0"><?= $columns ?></div>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="text-muted small">Numeric columns</div>
        <div class="h5 mb-0"><?= $numericCols ?></div>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <div class="text-muted small">Categorical columns</div>
        <div class="h5 mb-0"><?= $categoricalCols ?></div>
      </div>
    </div>
  </div>
</div>

<style>
  .report-table { font-size: 0.92rem; }
  .report-mono { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace; }
  .report-table th { white-space: nowrap; }

  /* IMPORTANT: stop “giant chart” */
  .chart-box {
    height: 260px;           /* fixed height so the chart stays sane */
    position: relative;
  }
  .chart-box canvas {
    width: 100% !important;
    height: 100% !important;
  }
</style>

<!-- CHARTS (SELECTABLE) -->
<div class="card shadow-sm mb-3">
  <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <div class="fw-semibold">Stats Charts</div>
      <div class="small text-muted">Choose what to show · Queued: <span data-queue-count>0</span></div>
    </div>

    <div class="row g-3">
      <div class="col-lg-4">
        <div class="border rounded p-3">
          <div class="mb-2">
            <label class="form-label">Chart</label>
            <select id="statsChartKind" class="form-select">
              <option value="types_doughnut">Column Types (doughnut)</option>
              <option value="types_bar">Column Types (bar)</option>
              <option value="missing_top">Missing % (Top N)</option>
              <option value="hist">Histogram (numeric)</option>
              <option value="topcat_bar">Top Categories (bar)</option>
              <option value="topcat_pie">Top Categories (pie)</option>
            </select>
          </div>

          <div id="blockMissingTop" class="mb-2" style="display:none;">
            <label class="form-label">Top N columns</label>
            <input id="missingTopN" class="form-control" type="number" min="5" max="35" value="12">
            <div class="form-text">Uses the same missing-values table data (capped like the PDF).</div>
          </div>

          <div id="blockHist" class="mb-2" style="display:none;">
            <label class="form-label">Numeric column</label>
            <select id="histCol" class="form-select mb-2">
              <?php foreach ($numericNames as $c): ?>
                <option value="<?= e($c) ?>"><?= e($c) ?></option>
              <?php endforeach; ?>
            </select>

            <label class="form-label">Bins</label>
            <input id="histBins" class="form-control" type="number" min="5" max="50" value="12">
          </div>

          <div id="blockTopCat" class="mb-2" style="display:none;">
            <label class="form-label">Categorical column</label>
            <select id="catCol" class="form-select mb-2">
              <?php foreach ($catNames as $c): ?>
                <option value="<?= e($c) ?>"><?= e($c) ?></option>
              <?php endforeach; ?>
            </select>

            <label class="form-label">Top N categories</label>
            <input id="catTopN" class="form-control" type="number" min="5" max="50" value="12">
          </div>

          <div class="form-check mb-2">
            <input class="form-check-input" type="checkbox" id="statsShowLegend" checked>
            <label class="form-check-label" for="statsShowLegend">Show legend</label>
          </div>

          <div class="d-flex flex-wrap gap-2">
            <button id="btnStatsDraw" class="btn btn-primary btn-sm" type="button">Draw</button>

            <button class="btn btn-outline-primary btn-sm" type="button"
              data-queue-add="#statsMainChart"
              data-queue-status="#statsQueueStatus">
              Add chart to PDF queue
            </button>

            <button class="btn btn-success btn-sm" type="button"
              data-queue-download
              data-maxrows="<?= (int)$maxRows ?>">
              Download PDF (queued charts)
            </button>

            <button class="btn btn-outline-secondary btn-sm" type="button" data-queue-clear>
              Clear queue
            </button>
          </div>

          <div id="statsQueueStatus" class="small text-muted mt-2"></div>
          <div id="statsChartError" class="small text-danger mt-1"></div>
        </div>
      </div>

      <div class="col-lg-8">
        <div class="chart-box border rounded p-2">
          <canvas id="statsMainChart" data-report-chart data-report-chart-title="Stats Chart"></canvas>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- TABLES -->
<div class="card shadow-sm mb-3">
  <div class="card-body">
    <h2 class="h6 mb-2">Numeric Columns</h2>

    <?php if (empty($num)): ?>
      <div class="text-muted small">No numeric columns found.</div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-sm table-bordered report-table align-middle">
          <thead class="table-light">
            <tr>
              <th>Column</th>
              <th class="text-end">Count</th>
              <th class="text-end">Missing</th>
              <th class="text-end">Mean</th>
              <th class="text-end">Std</th>
              <th class="text-end">Min</th>
              <th class="text-end">Q1</th>
              <th class="text-end">Median</th>
              <th class="text-end">Q3</th>
              <th class="text-end">Max</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($num as $r): ?>
            <tr>
              <td class="fw-semibold"><?= e((string)$r['column']) ?></td>
              <td class="text-end"><?= (int)$r['count'] ?></td>
              <td class="text-end"><?= (int)$r['missing'] ?></td>
              <td class="text-end report-mono"><?= e((string)$r['mean']) ?></td>
              <td class="text-end report-mono"><?= e((string)$r['std']) ?></td>
              <td class="text-end report-mono"><?= e((string)$r['min']) ?></td>
              <td class="text-end report-mono"><?= e((string)$r['q1']) ?></td>
              <td class="text-end report-mono"><?= e((string)$r['median']) ?></td>
              <td class="text-end report-mono"><?= e((string)$r['q3']) ?></td>
              <td class="text-end report-mono"><?= e((string)$r['max']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="card shadow-sm">
  <div class="card-body">
    <h2 class="h6 mb-2">Categorical Columns</h2>

    <?php if (empty($cat)): ?>
      <div class="text-muted small">No categorical columns found.</div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-sm table-bordered report-table align-middle">
          <thead class="table-light">
            <tr>
              <th>Column</th>
              <th class="text-end">Count</th>
              <th class="text-end">Missing</th>
              <th class="text-end">Unique</th>
              <th>Top values (up to 3)</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($cat as $r): ?>
            <tr>
              <td class="fw-semibold"><?= e((string)$r['column']) ?></td>
              <td class="text-end"><?= (int)$r['count'] ?></td>
              <td class="text-end"><?= (int)$r['missing'] ?></td>
              <td class="text-end"><?= (int)$r['unique'] ?></td>
              <td><?= e((string)$r['top3']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
(function () {
  const canvas = document.getElementById('statsMainChart');
  const errEl = document.getElementById('statsChartError');
  const kindEl = document.getElementById('statsChartKind');

  if (!canvas || typeof Chart === 'undefined') return;

  let chart = null;

  function setErr(msg) {
    errEl.textContent = msg || '';
  }

  function destroy() {
    if (chart) { chart.destroy(); chart = null; }
  }

  function showBlocks() {
    const k = kindEl.value;
    document.getElementById('blockMissingTop').style.display = (k === 'missing_top') ? '' : 'none';
    document.getElementById('blockHist').style.display = (k === 'hist') ? '' : 'none';
    document.getElementById('blockTopCat').style.display = (k === 'topcat_bar' || k === 'topcat_pie') ? '' : 'none';
  }

  async function fetchJson(url) {
    const r = await fetch(url);
    return await r.json();
  }

  function baseOptions(showLegend) {
    return {
      responsive: true,
      maintainAspectRatio: false, // KEY FIX: prevents “giant chart”
      plugins: {
        legend: { display: !!showLegend, position: 'bottom' },
        tooltip: { enabled: true }
      }
    };
  }

  async function draw() {
    setErr('');
    destroy();

    const showLegend = document.getElementById('statsShowLegend').checked;
    const k = kindEl.value;
    const maxRows = document.getElementById('maxRowsStats')?.value || <?= (int)$maxRows ?>;

    try {
      // 1) Column types
      if (k === 'types_doughnut' || k === 'types_bar') {
        const type = (k === 'types_bar') ? 'bar' : 'doughnut';
        const title = (k === 'types_bar') ? 'Stats: Column Types (bar)' : 'Stats: Column Types (doughnut)';
        canvas.setAttribute('data-report-chart-title', title);

        chart = new Chart(canvas, {
          type,
          data: {
            labels: ['Numeric', 'Categorical'],
            datasets: [{ label: 'Columns', data: [<?= (int)$numericCols ?>, <?= (int)$categoricalCols ?>] }]
          },
          options: Object.assign(baseOptions(showLegend), {
            scales: (type === 'bar') ? { y: { beginAtZero: true } } : {}
          })
        });
        return;
      }

      // 2) Missing top
      if (k === 'missing_top') {
        const topN = parseInt(document.getElementById('missingTopN').value || '12', 10);
        const rows = <?= json_encode($missingTop, JSON_UNESCAPED_SLASHES) ?>;
        const slice = rows.slice(0, Math.max(5, Math.min(35, topN)));

        const labels = slice.map(r => r.column);
        const pct = slice.map(r => parseFloat(String(r.pct || '0').replace('%','')) || 0);

        const title = 'Missing: Top % Missing';
        canvas.setAttribute('data-report-chart-title', title);

        chart = new Chart(canvas, {
          type: 'bar',
          data: { labels, datasets: [{ label: '% missing', data: pct }] },
          options: Object.assign(baseOptions(showLegend), {
            scales: {
              y: { beginAtZero: true, ticks: { callback: v => v + '%' } }
            }
          })
        });
        return;
      }

      // 3) Histogram (numeric) - uses your existing API
      if (k === 'hist') {
        const col = document.getElementById('histCol').value;
        const bins = document.getElementById('histBins').value || 12;

        const res = await fetchJson(`?r=api/histogram&col=${encodeURIComponent(col)}&bins=${encodeURIComponent(bins)}&max_rows=${encodeURIComponent(maxRows)}`);
        if (!res.ok) throw new Error(res.error || 'Histogram failed.');

        const title = `Histogram: ${col}`;
        canvas.setAttribute('data-report-chart-title', 'Stats: ' + title);

        chart = new Chart(canvas, {
          type: 'bar',
          data: { labels: res.labels, datasets: [{ label: title, data: res.counts }] },
          options: Object.assign(baseOptions(showLegend), {
            scales: { y: { beginAtZero: true } }
          })
        });
        return;
      }

      // 4) Top categories (bar/pie) - uses your existing API
      if (k === 'topcat_bar' || k === 'topcat_pie') {
        const col = document.getElementById('catCol').value;
        const topN = document.getElementById('catTopN').value || 12;

        const res = await fetchJson(`?r=api/value_counts&col=${encodeURIComponent(col)}&top=${encodeURIComponent(topN)}&max_rows=${encodeURIComponent(maxRows)}`);
        if (!res.ok) throw new Error(res.error || 'Value counts failed.');

        const type = (k === 'topcat_pie') ? 'pie' : 'bar';
        const title = (type === 'pie') ? `Top Categories (pie): ${col}` : `Top Categories (bar): ${col}`;
        canvas.setAttribute('data-report-chart-title', 'Stats: ' + title);

        chart = new Chart(canvas, {
          type,
          data: { labels: res.labels, datasets: [{ label: col, data: res.counts }] },
          options: Object.assign(baseOptions(showLegend), {
            scales: (type === 'bar') ? { y: { beginAtZero: true } } : {}
          })
        });
        return;
      }

      setErr('Unknown chart type.');
    } catch (e) {
      console.error(e);
      setErr(e?.message || String(e));
    }
  }

  kindEl.addEventListener('change', () => { showBlocks(); draw(); });
  document.getElementById('btnStatsDraw').addEventListener('click', draw);

  // init
  showBlocks();
  draw();
})();
</script>
