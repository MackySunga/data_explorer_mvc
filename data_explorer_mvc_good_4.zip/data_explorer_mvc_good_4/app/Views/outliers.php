<?php
$M = $fmt['meta'] ?? [];
$outs = $fmt['outliers_top'] ?? [];
?>

<div class="d-flex justify-content-between align-items-start mb-3">
  <div>
    <h1 class="h4 mb-1">Outliers: <?= e($meta['name'] ?? '') ?></h1>
    <div class="text-muted small">
      Same values & sorting as the PDF report (top numeric columns by IQR outlier count).
      · Max rows used: <strong><?= (int)$maxRows ?></strong>
    </div>
  </div>

  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/table">Explore</a>
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/reports">Reports</a>
    <a class="btn btn-primary btn-sm" href="?r=explore/report_save&max_rows=<?= (int)$maxRows ?>">Save Report</a>
  </div>
</div>

<div class="card shadow-sm mb-3">
  <div class="card-body">
    <form class="row g-2 align-items-end" method="get">
      <input type="hidden" name="r" value="explore/outliers">

      <div class="col-sm-4 col-md-3">
        <label class="form-label">Max rows used</label>
        <input name="max_rows" class="form-control" type="number" min="1000" max="200000" value="<?= (int)$maxRows ?>">
        <div class="form-text">Higher = more accurate, but slower.</div>
      </div>

      <div class="col-sm-3 col-md-2">
        <button class="btn btn-primary w-100" type="submit">Recompute</button>
      </div>

      <div class="col-sm-3 col-md-2">
        <a class="btn btn-outline-secondary w-100" href="?r=explore/table">Explore</a>
      </div>
    </form>
  </div>
</div>

<!-- Small chart -->
<div class="card shadow-sm mb-3">
  <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <div class="fw-semibold">Top IQR Outlier Counts</div>
      <div class="text-muted small">Top 12 columns (same list basis as table)</div>
    </div>

    <?php if (empty($outs)): ?>
      <div class="text-muted small">No outlier data found.</div>
    <?php else: ?>
      <canvas id="outlierChart" height="140"></canvas>

      <div class="d-flex flex-wrap gap-2 mt-2 align-items-center">
        <button class="btn btn-outline-primary btn-sm" type="button"
          data-queue-add="#outlierChart"
          data-queue-title="Outliers: Top IQR Outlier Counts"
          data-queue-status="#queueStatusOutliers">
          Add chart to PDF queue
        </button>

        <button class="btn btn-success btn-sm" type="button"
          data-queue-download
          data-maxrows="<?= (int)$maxRows ?>">
          Download PDF (queued charts)
        </button>

        <button class="btn btn-outline-secondary btn-sm" type="button" data-queue-clear>
          Clear queue
        </button>

        <span class="small text-muted">Queued: <span data-queue-count></span></span>
        <span id="queueStatusOutliers" class="small text-muted"></span>
      </div>
    <?php endif; ?>

    <hr class="my-3">
    <div class="fw-semibold mb-2">PDF Queue Items</div>
    <div id="queueInfoOutliers" class="small"></div>
  </div>
</div>

<style>
  .report-table { font-size: 0.92rem; }
  .report-mono { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace; }
  .report-table th { white-space: nowrap; }
</style>

<div class="card shadow-sm">
  <div class="card-body">
    <h2 class="h6 mb-2">Outliers (Top)</h2>
    <div class="text-muted small mb-2">Showing top numeric columns by IQR outlier count (same as PDF).</div>

    <?php if (empty($outs)): ?>
      <div class="text-muted small">No outlier data found.</div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-sm table-bordered report-table align-middle">
          <thead class="table-light">
            <tr>
              <th>Column</th>
              <th class="text-end">N</th>
              <th class="text-end">IQR outliers</th>
              <th class="text-end">Z outliers</th>
              <th>IQR fences</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($outs as $r): ?>
            <tr>
              <td class="fw-semibold"><?= e((string)$r['column']) ?></td>
              <td class="text-end"><?= (int)$r['n'] ?></td>
              <td class="text-end"><?= e((string)$r['iqr_outliers']) ?></td>
              <td class="text-end"><?= e((string)$r['z_outliers']) ?></td>
              <td class="report-mono"><?= e((string)$r['fence']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php if (!empty($outs)): ?>
<script>
(function(){
  const rows = <?= json_encode(array_slice($outs, 0, 12), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
  const ctx = document.getElementById('outlierChart');
  if (!ctx || typeof Chart === 'undefined') return;

  const labels = rows.map(r => String(r.column));
  const vals = rows.map(r => parseFloat(String(r.iqr_outliers || '0')) || 0);

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'IQR outliers',
        data: vals
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      plugins: {
        legend: { display: true, position: 'bottom' },
        tooltip: { enabled: true }
      },
      scales: {
        x: { beginAtZero: true }
      }
    }
  });
})();
</script>
<?php endif; ?>

<script>
(function(){
  const KEY = "data_explorer_pdf_queue_v1";
  const box = document.getElementById("queueInfoOutliers");
  if (!box) return;

  const esc = (s) => String(s).replace(/[&<>"']/g, (m) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[m]));

  function loadQ(){
    try {
      const q = JSON.parse(localStorage.getItem(KEY) || "[]");
      return Array.isArray(q) ? q : [];
    } catch (e) {
      return [];
    }
  }

  function saveQ(q) {
    localStorage.setItem(KEY, JSON.stringify(q || []));
    document.querySelectorAll("[data-queue-count]").forEach(el => el.textContent = String((q||[]).length));
    if (window.ReportQueue && typeof window.ReportQueue.updateCountEls === "function") {
      window.ReportQueue.updateCountEls();
    }
  }

  function render(){
    const q = loadQ();
    document.querySelectorAll("[data-queue-count]").forEach(el => el.textContent = String(q.length));

    if (!q.length) {
      box.innerHTML = '<span class="text-muted">Queue is empty. Add charts from any page using “Add chart to PDF queue”.</span>';
      return;
    }

    const rows = q.map((c, i) => `
      <div class="d-flex justify-content-between align-items-center border rounded p-2 mb-1">
        <div><strong>${i+1}.</strong> ${esc(c.title || "Chart")}</div>
        <button type="button" class="btn btn-sm btn-outline-danger" data-q-remove="${i}">Remove</button>
      </div>
    `).join("");

    box.innerHTML = `
      <div class="mb-2"><strong>Queued charts:</strong> ${q.length}</div>
      ${rows}
      <div class="d-flex gap-2 mt-2">
        <button type="button" class="btn btn-sm btn-outline-secondary" data-q-clear>Clear queue</button>
      </div>
    `;

    box.querySelectorAll("[data-q-remove]").forEach(btn => {
      btn.addEventListener("click", () => {
        const idx = parseInt(btn.getAttribute("data-q-remove"), 10);
        const qq = loadQ();
        qq.splice(idx, 1);
        saveQ(qq);
        render();
      });
    });

    box.querySelector("[data-q-clear]")?.addEventListener("click", () => {
      if (!confirm("Clear queued charts?")) return;
      saveQ([]);
      render();
    });
  }

  render();

  document.querySelectorAll("[data-queue-add],[data-queue-clear],[data-queue-download]").forEach(btn => {
    btn.addEventListener("click", () => setTimeout(render, 250));
  });

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) render();
  });
})();
</script>
