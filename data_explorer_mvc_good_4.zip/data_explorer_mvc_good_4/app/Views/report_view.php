<?php
$M = $fmt['meta'] ?? [];
$corr = $fmt['corr'] ?? ['cols'=>[], 'matrix'=>[], 'cap'=>12];
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <div class="h5 mb-0">Data Explorer Report</div>
    <div class="text-muted small">
      Dataset: <strong><?= e((string)($M['dataset_name'] ?? '')) ?></strong>
      · Generated: <?= e((string)($M['generated_at'] ?? '')) ?>
      · Max rows: <?= e((string)($M['max_rows'] ?? '')) ?>
    </div>
  </div>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/reports">Back</a>
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/report_download&file=<?= e($file) ?>">Download JSON</a>
    <a class="btn btn-primary btn-sm" href="?r=explore/report_pdf&file=<?= e($file) ?>">Download PDF</a>
  </div>
</div>

<style>
/* Make preview look like PDF pages */
.report-page {
  background: #fff;
  border: 1px solid rgba(0,0,0,.12);
  border-radius: 10px;
  padding: 14px;
  margin-bottom: 14px;
  font-family: Arial, Helvetica, sans-serif;
}
.report-title { font-size: 18px; font-weight: 700; margin-bottom: 8px; }
.report-h2 { font-size: 14px; font-weight: 700; margin: 10px 0 6px; }
.report-note { font-size: 12px; color: rgba(0,0,0,.65); }
.report-table { font-size: 12px; }
.report-table th { white-space: nowrap; }
.report-mono { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace; }

/* Print-friendly (optional) */
@media print {
  .btn, nav, .navbar, footer { display: none !important; }
  .report-page { border: none; border-radius: 0; margin: 0; padding: 0; }
  .page-break { page-break-after: always; }
}
</style>

<div class="report-page">
  <div class="report-title">Quick Summary</div>
  <div class="row g-2">
    <div class="col-md-4"><div class="report-note">Columns</div><div class="fw-semibold"><?= (int)($M['columns'] ?? 0) ?></div></div>
    <div class="col-md-4"><div class="report-note">Numeric columns</div><div class="fw-semibold"><?= (int)($M['numeric_columns'] ?? 0) ?></div></div>
    <div class="col-md-4"><div class="report-note">Categorical columns</div><div class="fw-semibold"><?= (int)($M['categorical_columns'] ?? 0) ?></div></div>
  </div>
</div>

<div class="report-page page-break">
  <div class="report-title">Descriptive Statistics</div>

  <div class="report-h2">Numeric Columns</div>
  <?php $num = $fmt['stats_numeric'] ?? []; ?>
  <?php if (empty($num)): ?>
    <div class="report-note">No numeric columns found.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-sm table-bordered report-table align-middle">
        <thead class="table-light">
          <tr>
            <th>Column</th><th class="text-end">Count</th><th class="text-end">Missing</th>
            <th class="text-end">Mean</th><th class="text-end">Std</th><th class="text-end">Min</th>
            <th class="text-end">Q1</th><th class="text-end">Median</th><th class="text-end">Q3</th><th class="text-end">Max</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($num as $r): ?>
          <tr>
            <td class="fw-semibold"><?= e((string)$r['column']) ?></td>
            <td class="text-end"><?= (int)$r['count'] ?></td>
            <td class="text-end"><?= (int)$r['missing'] ?></td>
            <td class="text-end report-mono"><?= e((string)$r['mean']) ?></td>
            <td class="text-end report-mono"><?= e((string)$r['std']) ?></td>
            <td class="text-end report-mono"><?= e((string)$r['min']) ?></td>
            <td class="text-end report-mono"><?= e((string)$r['q1']) ?></td>
            <td class="text-end report-mono"><?= e((string)$r['median']) ?></td>
            <td class="text-end report-mono"><?= e((string)$r['q3']) ?></td>
            <td class="text-end report-mono"><?= e((string)$r['max']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>

  <div class="report-h2 mt-3">Categorical Columns</div>
  <?php $cat = $fmt['stats_categorical'] ?? []; ?>
  <?php if (empty($cat)): ?>
    <div class="report-note">No categorical columns found.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-sm table-bordered report-table align-middle">
        <thead class="table-light">
          <tr>
            <th>Column</th><th class="text-end">Count</th><th class="text-end">Missing</th><th class="text-end">Unique</th><th>Top values (up to 3)</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($cat as $r): ?>
          <tr>
            <td class="fw-semibold"><?= e((string)$r['column']) ?></td>
            <td class="text-end"><?= (int)$r['count'] ?></td>
            <td class="text-end"><?= (int)$r['missing'] ?></td>
            <td class="text-end"><?= (int)$r['unique'] ?></td>
            <td><?= e((string)$r['top3']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="report-page page-break">
  <div class="report-title">Missing Values</div>
  <div class="report-note">Showing top 35 columns by % missing (same as PDF).</div>

  <?php $miss = $fmt['missing_top'] ?? []; ?>
  <?php if (empty($miss)): ?>
    <div class="report-note">No missing-values data found.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-sm table-bordered report-table align-middle">
        <thead class="table-light">
          <tr><th>Column</th><th class="text-end">Missing</th><th class="text-end">Total</th><th class="text-end">% Missing</th></tr>
        </thead>
        <tbody>
        <?php foreach ($miss as $r): ?>
          <tr>
            <td class="fw-semibold"><?= e((string)$r['column']) ?></td>
            <td class="text-end"><?= (int)$r['missing'] ?></td>
            <td class="text-end"><?= (int)$r['total'] ?></td>
            <td class="text-end report-mono"><?= e((string)$r['pct']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="report-page page-break">
  <div class="report-title">Outliers</div>
  <div class="report-note">Showing top 35 numeric columns by IQR outlier count (same as PDF).</div>

  <?php $outs = $fmt['outliers_top'] ?? []; ?>
  <?php if (empty($outs)): ?>
    <div class="report-note">No outlier data found.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-sm table-bordered report-table align-middle">
        <thead class="table-light">
          <tr>
            <th>Column</th><th class="text-end">N</th><th class="text-end">IQR outliers</th><th class="text-end">Z outliers</th><th>IQR fences</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($outs as $r): ?>
          <tr>
            <td class="fw-semibold"><?= e((string)$r['column']) ?></td>
            <td class="text-end"><?= (int)$r['n'] ?></td>
            <td class="text-end"><?= e((string)$r['iqr_outliers']) ?></td>
            <td class="text-end"><?= e((string)$r['z_outliers']) ?></td>
            <td class="report-mono"><?= e((string)$r['fence']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="report-page">
  <div class="report-title">Correlation Matrix (Pearson r)</div>
  <div class="report-note">Capped to first <?= (int)($corr['cap'] ?? 12) ?> numeric columns (same as PDF).</div>

  <?php $cc = $corr['cols'] ?? []; $cm = $corr['matrix'] ?? []; ?>
  <?php if (empty($cc) || empty($cm)): ?>
    <div class="report-note">No correlation matrix found.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-sm table-bordered report-table align-middle">
        <thead class="table-light">
          <tr>
            <th></th>
            <?php foreach ($cc as $c): ?>
              <th class="text-end"><?= e((string)$c) ?></th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($cm as $i => $row): ?>
            <tr>
              <th><?= e((string)($cc[$i] ?? '')) ?></th>
              <?php foreach ($row as $v): ?>
                <td class="text-end report-mono"><?= e((string)$v) ?></td>
              <?php endforeach; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
