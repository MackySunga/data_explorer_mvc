<?php
// app/Views/regression.php

// Expected from controller:
//  - $meta
//  - $numericCols, $y, $x, $maxRows, $diagPoints, $result, $error

$meta = $meta ?? null;

$numericCols = $numericCols ?? [];
$y = $y ?? '';
$x = $x ?? [];
$maxRows = (int)($maxRows ?? 50000);
$diagPoints = (int)($diagPoints ?? 2000);
$result = $result ?? null;
$error = $error ?? '';
?>

<style>
  :root { --regChartH: 460px; }
  .reg-chart-wrap {
    height: var(--regChartH);
    position: relative;
  }
  .reg-chart-wrap canvas {
    width: 100% !important;
    height: 100% !important;
  }
</style>

<!-- marker so app.js can detect dataset id -->
<div class="d-none" data-dataset-id="<?= e((string)($meta['id'] ?? '')) ?>"></div>

<div class="d-flex justify-content-between align-items-start mb-3">
  <div>
    <h1 class="h4 mb-1">Regression (OLS)</h1>
    <div class="text-muted small">
      OLS (Ordinary Least Squares) output + diagnostics (Residuals, Q–Q, Cook’s Distance).
    </div>
  </div>

  <div class="d-flex gap-2 align-items-start">
    <div class="d-flex flex-column align-items-end">
      <label class="form-label small mb-1">Chart size</label>
      <select id="chartSize" class="form-select form-select-sm">
        <option value="380">Small</option>
        <option value="460" selected>Medium</option>
        <option value="620">Large</option>
      </select>
    </div>

    <div class="d-flex gap-2">
      <a class="btn btn-outline-secondary btn-sm" href="?r=explore/table">Explore</a>
      <a class="btn btn-outline-secondary btn-sm" href="?r=explore/reports">Reports</a>
    </div>
  </div>
</div>

<?php if ($error !== ''): ?>
  <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>

<form class="card shadow-sm mb-3" method="post" action="?r=explore/regression">
  <div class="card-body">
    <div class="row g-3">
      <div class="col-lg-4">
        <label class="form-label">Dependent (Y)</label>
        <select class="form-select" name="y" required>
          <option value="">(select)</option>
          <?php foreach ($numericCols as $c): ?>
            <option value="<?= e($c) ?>" <?= $c===$y ? 'selected' : '' ?>><?= e($c) ?></option>
          <?php endforeach; ?>
        </select>
        <div class="form-text">Numeric columns only.</div>
      </div>

      <div class="col-lg-8">
        <label class="form-label">Independent (X) — select one or more</label>
        <select class="form-select" name="x[]" multiple size="6" required>
          <?php foreach ($numericCols as $c): ?>
            <?php if ($c === $y) continue; ?>
            <option value="<?= e($c) ?>" <?= in_array($c, $x, true) ? 'selected' : '' ?>>
              <?= e($c) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <div class="form-text">Rows with missing/non-numeric values in Y or any X are dropped.</div>
      </div>

      <div class="col-lg-3">
        <label class="form-label">Max rows</label>
        <input class="form-control" type="number" name="max_rows" min="1000" max="200000" value="<?= (int)$maxRows ?>">
      </div>

      <div class="col-lg-3">
        <label class="form-label">Diagnostics points</label>
        <input class="form-control" type="number" name="diag_points" min="200" max="5000" value="<?= (int)$diagPoints ?>">
        <div class="form-text">Used for charts only.</div>
      </div>

      <div class="col-lg-6 d-flex align-items-end">
        <button class="btn btn-primary w-100" type="submit">RUN REGRESSION</button>
      </div>
    </div>
  </div>
</form>

<?php if (is_array($result)): ?>
  <?php
    $rs = $result['regression_stats'] ?? [];
    $an = $result['anova'] ?? [];
    $coef = $result['coefficients'] ?? [];
    $diag = $result['diagnostics'] ?? [];

    // This is what app.js will store (TABLES) so PDF can print them
    $regPayload = [
      'y' => (string)$y,
      'x' => array_values(array_map('strval', $x)),
      'max_rows' => (int)$maxRows,
      'diag_points' => (int)$diagPoints,
      'generated_at' => date('c'),
      'regression_stats' => $rs,
      'anova' => $an,
      'coefficients' => $coef,
    ];
  ?>

  <script id="regression-json" type="application/json"><?= json_encode($regPayload, JSON_UNESCAPED_SLASHES) ?></script>

  <div class="card shadow-sm mb-3">
    <div class="card-body d-flex flex-wrap gap-2 align-items-center justify-content-between">
      <div class="d-flex gap-2 flex-wrap">
        <button class="btn btn-outline-secondary btn-sm" type="button" data-reg-save>
          Save Regression (tables) for PDF
        </button>
        <button class="btn btn-outline-secondary btn-sm" type="button" data-reg-queue>
          Add Regression Charts to Queue
        </button>
        <button class="btn btn-success btn-sm" type="button" data-reg-pdf>
          Download PDF (tables + charts)
        </button>
      </div>
      <div class="text-muted small">
        Queue: <strong data-queue-count>0</strong>
        <span id="regStatus" class="ms-2"></span>
      </div>
    </div>
  </div>

  <div class="row g-3">
    <div class="col-lg-5">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="fw-semibold mb-2">Regression Statistics</div>
          <table class="table table-sm mb-0">
            <tr><td>Multiple R</td><td class="text-end"><?= e(sprintf('%.6f', (float)($rs['multiple_r'] ?? 0))) ?></td></tr>
            <tr><td>R Square</td><td class="text-end"><?= e(sprintf('%.6f', (float)($rs['r2'] ?? 0))) ?></td></tr>
            <tr><td>Adjusted R Square</td><td class="text-end"><?= e(sprintf('%.6f', (float)($rs['adj_r2'] ?? 0))) ?></td></tr>
            <tr><td>Standard Error</td><td class="text-end"><?= e(sprintf('%.6f', (float)($rs['std_error'] ?? 0))) ?></td></tr>
            <tr><td>Observations</td><td class="text-end"><?= (int)($rs['observations'] ?? 0) ?></td></tr>
          </table>
        </div>
      </div>
    </div>

    <div class="col-lg-7">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="fw-semibold mb-2">ANOVA (Analysis of Variance)</div>
          <table class="table table-sm mb-0">
            <thead class="table-light">
              <tr>
                <th></th><th class="text-end">df</th><th class="text-end">SS</th><th class="text-end">MS</th><th class="text-end">F</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Regression</td>
                <td class="text-end"><?= (int)($an['df_reg'] ?? 0) ?></td>
                <td class="text-end"><?= e(sprintf('%.6g', (float)($an['ssr'] ?? 0))) ?></td>
                <td class="text-end"><?= e(sprintf('%.6g', (float)($an['msr'] ?? 0))) ?></td>
                <td class="text-end"><?= e(sprintf('%.6g', (float)($an['f'] ?? 0))) ?></td>
              </tr>
              <tr>
                <td>Residual</td>
                <td class="text-end"><?= (int)($an['df_res'] ?? 0) ?></td>
                <td class="text-end"><?= e(sprintf('%.6g', (float)($an['sse'] ?? 0))) ?></td>
                <td class="text-end"><?= e(sprintf('%.6g', (float)($an['mse'] ?? 0))) ?></td>
                <td class="text-end"></td>
              </tr>
              <tr>
                <td>Total</td>
                <td class="text-end"><?= (int)($an['df_tot'] ?? 0) ?></td>
                <td class="text-end"><?= e(sprintf('%.6g', (float)($an['sst'] ?? 0))) ?></td>
                <td class="text-end"></td>
                <td class="text-end"></td>
              </tr>
            </tbody>
          </table>
          <div class="text-muted small mt-2">
            P-values are normal-approx (accurate when observations are large).
          </div>
        </div>
      </div>
    </div>

    <div class="col-12">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="fw-semibold mb-2">Coefficients</div>
          <div class="table-responsive">
            <table class="table table-sm table-bordered align-middle mb-0">
              <thead class="table-light">
                <tr>
                  <th>Term</th>
                  <th class="text-end">Coefficient</th>
                  <th class="text-end">Std Error</th>
                  <th class="text-end">t Stat</th>
                  <th class="text-end">P-value</th>
                  <th class="text-end">Lower 95%</th>
                  <th class="text-end">Upper 95%</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($coef as $r): ?>
                  <tr>
                    <td class="fw-semibold"><?= e((string)($r['name'] ?? '')) ?></td>
                    <td class="text-end"><?= e(sprintf('%.6g', (float)($r['coef'] ?? 0))) ?></td>
                    <td class="text-end"><?= e(sprintf('%.6g', (float)($r['se'] ?? 0))) ?></td>
                    <td class="text-end"><?= e(sprintf('%.6g', (float)($r['t'] ?? 0))) ?></td>
                    <td class="text-end"><?= e(sprintf('%.6g', (float)($r['p'] ?? 0))) ?></td>
                    <td class="text-end"><?= e(sprintf('%.6g', (float)($r['lo'] ?? 0))) ?></td>
                    <td class="text-end"><?= e(sprintf('%.6g', (float)($r['hi'] ?? 0))) ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- Charts: Residuals vs Fitted + Q-Q in one row (wide screens), Cook full width below -->
    <div class="col-lg-6">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="fw-semibold mb-2">Residuals vs Fitted</div>
          <div class="reg-chart-wrap">
            <canvas id="chartResFit"></canvas>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="fw-semibold mb-2">Q–Q Plot</div>
          <div class="reg-chart-wrap">
            <canvas id="chartQQ"></canvas>
          </div>
        </div>
      </div>
    </div>

    <div class="col-12">
      <div class="card shadow-sm">
        <div class="card-body">
          <div class="fw-semibold mb-2">Cook’s Distance</div>
          <div class="reg-chart-wrap">
            <canvas id="chartCook"></canvas>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
  (function(){
    // chart height dropdown
    const sel = document.getElementById('chartSize');
    if (sel) {
      const apply = () => document.documentElement.style.setProperty('--regChartH', String(sel.value) + 'px');
      sel.addEventListener('change', apply);
      apply();
    }

    if (typeof Chart === 'undefined') return;

    const diag = <?= json_encode($diag, JSON_UNESCAPED_SLASHES) ?>;

    // Residuals vs Fitted (scatter)
    new Chart(document.getElementById('chartResFit'), {
      type: 'scatter',
      data: {
        datasets: [{
          label: 'Residuals',
          data: (diag.fitted || []).map((x, i) => ({ x: x, y: (diag.residuals || [])[i] ?? 0 }))
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { title: { display: true, text: 'Fitted' } },
          y: { title: { display: true, text: 'Residual' } }
        }
      }
    });

    // Q-Q (scatter)
    new Chart(document.getElementById('chartQQ'), {
      type: 'scatter',
      data: {
        datasets: [{
          label: 'Q-Q',
          data: (diag.qq_x || []).map((x, i) => ({ x: x, y: (diag.qq_y || [])[i] ?? 0 }))
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { title: { display: true, text: 'Theoretical (Normal)' } },
          y: { title: { display: true, text: 'Residual (sorted)' } }
        }
      }
    });

    // Cook’s Distance (bar)
    new Chart(document.getElementById('chartCook'), {
      type: 'bar',
      data: {
        labels: (diag.cooks || []).map((_, i) => String(i + 1)),
        datasets: [{
          label: "Cook's D",
          data: diag.cooks || []
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: false,
        plugins: { legend: { display: false } },
        scales: { x: { display: false }, y: { beginAtZero: true } }
      }
    });
  })();
  </script>
<?php endif; ?>
