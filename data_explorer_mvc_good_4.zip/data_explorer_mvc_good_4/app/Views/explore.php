<?php
// app/Views/explore.php
// Expected: $meta, $columns, $selected, $rows, $page, $perPage, $totalMatched, $totalPages, $q, $sort, $dir
// New: $types, $colInfo, $statsSampleRows, $f_op, $f_v1, $f_v2
$types = $types ?? [];
$colInfo = $colInfo ?? [];
$statsSampleRows = (int)($statsSampleRows ?? 20000);
$f_op = $f_op ?? [];
$f_v1 = $f_v1 ?? [];
$f_v2 = $f_v2 ?? [];

$base = $_GET;
$base['r'] = 'explore/table';
?>

<style>
  .kaggle-th { vertical-align: bottom; }
  .col-meta { font-size: .78rem; color: rgba(0,0,0,.6); }
  .sticky-head thead th { position: sticky; top: 0; z-index: 2; }
  .cell-wrap { max-width: 360px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .mini-progress { height: 4px; }
  .profile-card .kv { font-size: .9rem; }
  .profile-card .kv .k { color: rgba(0,0,0,.6); font-size: .78rem; }
  .profile-card .kv .v { font-weight: 600; }
</style>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h1 class="h4 mb-1">Explore: <?= e($meta['name']) ?></h1>
    <div class="text-muted small">
      Kaggle-like filters + quick column profiling (no query syntax).
      · Profile sample rows: <strong><?= (int)$statsSampleRows ?></strong>
    </div>
  </div>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/stats">Stats</a>
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/visualize">Visualize</a>
  </div>
</div>

<form class="card shadow-sm mb-3" method="get">
  <input type="hidden" name="r" value="explore/table">
  <input type="hidden" name="sort" value="<?= e((string)($sort ?? '')) ?>">
  <input type="hidden" name="dir"  value="<?= e((string)($dir ?? 'asc')) ?>">

  <div class="card-body">
    <div class="row g-3">
      <div class="col-lg-4">
        <label class="form-label">Global Search (row search)</label>
        <input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Search across all columns...">
      </div>

      <div class="col-lg-2">
        <label class="form-label">Rows / page</label>
        <input class="form-control" type="number" name="per_page" min="10" max="100" value="<?= (int)$perPage ?>">
      </div>

      <div class="col-lg-2">
        <label class="form-label">Profile rows</label>
        <input class="form-control" type="number" name="profile_rows" min="1000" max="50000" value="<?= (int)$statsSampleRows ?>">
        <div class="form-text">Used for type/missing/unique info.</div>
      </div>

      <div class="col-lg-4">
        <label class="form-label">Columns to show</label>
        <select class="form-select" multiple name="cols[]">
          <?php foreach ($columns as $c): ?>
            <option value="<?= e($c) ?>" <?= in_array($c, $selected, true) ? 'selected' : '' ?>>
              <?= e($c) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <div class="form-text">Hold Ctrl to select multiple.</div>
      </div>

      <!-- Per-column filters (Kaggle-like) -->
<?php
$numericCols = [];
$catCols = [];
foreach ($selected as $c) {
  $t = (string)($types[$c] ?? 'categorical');
  if ($t === 'numeric') $numericCols[] = $c;
  else $catCols[] = $c;
}
?>

<div class="col-12">
  <div class="border rounded p-3 bg-body-tertiary">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <div class="fw-semibold">Column Filters</div>
      <div class="text-muted small">Numeric and Categorical are separated</div>
    </div>

    <!-- NUMERIC FILTERS -->
    <?php if (!empty($numericCols)): ?>
      <div class="fw-semibold mb-1">Numeric Filters</div>
      <div class="table-responsive mb-3">
        <table class="table table-sm align-middle mb-0">
          <thead>
            <tr class="text-muted small">
              <th style="width: 22%">Column</th>
              <th style="width: 18%">Operator</th>
              <th style="width: 30%">Value / Min</th>
              <th style="width: 30%">Max (between only)</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($numericCols as $c): ?>
              <?php $op = (string)($f_op[$c] ?? ''); ?>
              <tr class="filter-row" data-type="numeric">
                <td class="fw-semibold">
                  <?= e($c) ?> <span class="badge text-bg-light border ms-1">numeric</span>
                </td>
                <td>
                  <select class="form-select form-select-sm num-op" name="f_op[<?= e($c) ?>]">
                    <option value="">(none)</option>
                    <option value="between" <?= $op==='between'?'selected':'' ?>>between</option>
                    <option value="gte" <?= $op==='gte'?'selected':'' ?>>≥ (gte)</option>
                    <option value="lte" <?= $op==='lte'?'selected':'' ?>>≤ (lte)</option>
                    <option value="eq"  <?= $op==='eq'?'selected':'' ?>>= (eq)</option>
                    <option value="ne"  <?= $op==='ne'?'selected':'' ?>>≠ (ne)</option>
                    <option value="is_blank" <?= $op==='is_blank'?'selected':'' ?>>is blank</option>
                    <option value="not_blank" <?= $op==='not_blank'?'selected':'' ?>>not blank</option>
                  </select>
                </td>
                <td>
                  <input class="form-control form-control-sm num-v1"
                         name="f_v1[<?= e($c) ?>]"
                         value="<?= e((string)($f_v1[$c] ?? '')) ?>"
                         placeholder="value or min">
                </td>
                <td>
                  <input class="form-control form-control-sm num-v2"
                         name="f_v2[<?= e($c) ?>]"
                         value="<?= e((string)($f_v2[$c] ?? '')) ?>"
                         placeholder="max (between only)">
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

    <!-- CATEGORICAL FILTERS -->
    <?php if (!empty($catCols)): ?>
      <div class="fw-semibold mb-1">Categorical Filters</div>
      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
          <thead>
            <tr class="text-muted small">
              <th style="width: 22%">Column</th>
              <th style="width: 18%">Operator</th>
              <th style="width: 60%">Value</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($catCols as $c): ?>
              <?php $op = (string)($f_op[$c] ?? ''); ?>
              <?php $cur = (string)($f_v1[$c] ?? ''); ?>

              <tr class="filter-row" data-type="categorical" data-col="<?= e($c) ?>">
                <td class="fw-semibold">
                  <?= e($c) ?> <span class="badge text-bg-light border ms-1">categorical</span>
                </td>

                <td>
                  <select class="form-select form-select-sm cat-op" name="f_op[<?= e($c) ?>]">
                    <option value="">(none)</option>
                    <option value="equals" <?= $op==='equals'?'selected':'' ?>>equals</option>
                    <option value="not_equals" <?= $op==='not_equals'?'selected':'' ?>>not equals</option>
                    <option value="contains" <?= $op==='contains'?'selected':'' ?>>contains</option>
                    <option value="starts_with" <?= $op==='starts_with'?'selected':'' ?>>starts with</option>
                    <option value="ends_with" <?= $op==='ends_with'?'selected':'' ?>>ends with</option>
                    <option value="is_blank" <?= $op==='is_blank'?'selected':'' ?>>is blank</option>
                    <option value="not_blank" <?= $op==='not_blank'?'selected':'' ?>>not blank</option>
                  </select>
                </td>

                <td>
                  <!-- server reads THIS -->
                  <input type="hidden" class="cat-hidden" name="f_v1[<?= e($c) ?>]" value="<?= e($cur) ?>">

                  <!-- dropdown for equals/not_equals -->
                  <select class="form-select form-select-sm cat-select mb-1" style="display:none" data-loaded="0">
                    <option value="">Loading…</option>
                  </select>

                  <!-- text input for contains/starts/ends -->
                  <input class="form-control form-control-sm cat-text"
                         style="display:none"
                         value="<?= e($cur) ?>"
                         placeholder="type a value…">

                  <div class="form-text">
                    equals/not equals = dropdown (top values). contains/starts/ends = type freely.
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

    <div class="d-flex gap-2 mt-3">
      <button class="btn btn-primary">Apply</button>
      <a class="btn btn-outline-secondary" href="?r=explore/table">Reset</a>
    </div>
  </div>
</div>






    </div>
  </div>
</form>

<!-- Quick profile panel -->
<div class="card shadow-sm mb-3 profile-card">
  <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <div class="fw-semibold">Quick Profile (selected column)</div>
      <div class="text-muted small">Missing · Unique · Min/Median/Max · Tiny preview</div>
    </div>

    <div class="row g-3 align-items-end">
      <div class="col-md-4">
        <label class="form-label">Column</label>
        <select id="profileCol" class="form-select">
          <?php foreach ($selected as $c): ?>
            <option value="<?= e($c) ?>"><?= e($c) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-2">
        <label class="form-label">Max rows</label>
        <input id="profileRows" class="form-control" type="number" min="1000" max="200000" value="<?= (int)$statsSampleRows ?>">
      </div>

      <div class="col-md-2">
        <button id="btnProfile" class="btn btn-outline-primary w-100" type="button">Refresh</button>
      </div>

      <div class="col-md-4 text-end">
        <div class="small text-muted">Matched rows: <strong><?= (int)$totalMatched ?></strong> · Page <?= (int)$page ?> / <?= (int)$totalPages ?></div>
      </div>
    </div>

    <div class="row g-3 mt-2">
      <div class="col-md-3">
        <div class="kv">
          <div class="k">Missing %</div>
          <div class="v" id="pMissingPct">—</div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="kv">
          <div class="k">Unique</div>
          <div class="v" id="pUnique">—</div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="kv">
          <div class="k">Min</div>
          <div class="v" id="pMin">—</div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="kv">
          <div class="k">Median</div>
          <div class="v" id="pMedian">—</div>
        </div>
      </div>
      <div class="col-md-2">
        <div class="kv">
          <div class="k">Max</div>
          <div class="v" id="pMax">—</div>
        </div>
      </div>
    </div>

    <div class="mt-3">
      <canvas id="profileChart" height="70"></canvas>
      <div id="profileErr" class="text-danger small mt-2"></div>
    </div>
  </div>
</div>

<!-- Data table -->
<div class="card shadow-sm">
  <div class="card-body">
    <div class="table-responsive sticky-head">
      <table class="table table-sm table-hover align-middle">
        <thead class="table-light">
          <tr>
            <th class="text-muted small">#</th>
            <?php foreach ($selected as $c): ?>
              <?php
                $isActive = (($sort ?? '') === $c);
                $nextDir = ($isActive && (($dir ?? 'asc') === 'asc')) ? 'desc' : 'asc';

                $q2 = $base;
                $q2['sort'] = $c;
                $q2['dir']  = $nextDir;

                $arrow = '';
                if ($isActive) $arrow = (($dir ?? 'asc') === 'asc') ? ' ▲' : ' ▼';

                $info = $colInfo[$c] ?? ['type'=>'', 'missing_pct'=>0, 'unique'=>0];
                $mp = (float)($info['missing_pct'] ?? 0);
              ?>
              <th class="kaggle-th text-nowrap">
                <a class="text-decoration-none" href="?<?= e(http_build_query($q2)) ?>">
                  <?= e($c) ?><?= e($arrow) ?>
                </a>
                <div class="col-meta">
                  <?= e((string)($info['type'] ?? '')) ?>
                  · missing <?= e(sprintf('%.1f%%', $mp)) ?>
                  · unique <?= (int)($info['unique'] ?? 0) ?>
                </div>
                <div class="progress mini-progress">
                  <div class="progress-bar" role="progressbar" style="width: <?= e((string)min(100, max(0, $mp))) ?>%"></div>
                </div>
              </th>
            <?php endforeach; ?>
          </tr>
        </thead>

        <tbody>
          <?php if (empty($rows)): ?>
            <tr><td colspan="<?= count($selected) + 1 ?>" class="text-muted">No rows matched.</td></tr>
          <?php endif; ?>

          <?php $rowNum = ($page - 1) * $perPage; ?>
          <?php foreach ($rows as $r): ?>
            <?php $rowNum++; ?>
            <tr>
              <td class="text-muted small"><?= (int)$rowNum ?></td>
              <?php foreach ($selected as $c): ?>
                <td class="cell-wrap" title="<?= e((string)($r[$c] ?? '')) ?>"><?= e((string)($r[$c] ?? '')) ?></td>
              <?php endforeach; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <nav class="d-flex justify-content-between align-items-center mt-2">
      <div class="text-muted small">Sorting is <strong>page-only</strong> (fast).</div>
      <ul class="pagination pagination-sm mb-0">
        <?php
          $mk = function(int $p) use ($base): string {
            $b = $base;
            $b['page'] = $p;
            return '?' . http_build_query($b);
          };
          $prev = max(1, $page - 1);
          $next = min($totalPages, $page + 1);
        ?>
        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="<?= e($mk($prev)) ?>">Prev</a></li>
        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>"><a class="page-link" href="<?= e($mk($next)) ?>">Next</a></li>
      </ul>
    </nav>
  </div>
</div>

<script>
(function(){
  // --- filter UI: disable "range max" unless op=range
  // --- FILTER UI (numeric vs categorical)
async function fetchJson(url) {
  const r = await fetch(url);
  return await r.json();
}

function profileRowsValue() {
  const inp = document.querySelector('input[name="profile_rows"]');
  return inp ? (parseInt(inp.value || '20000', 10) || 20000) : 20000;
}

function refreshNumericRow(tr) {
  const op = tr.querySelector('.num-op')?.value || '';
  const v1 = tr.querySelector('.num-v1');
  const v2 = tr.querySelector('.num-v2');

  const needsTwo = (op === 'between');
  const needsNone = (op === '' || op === 'is_blank' || op === 'not_blank');

  if (v1) v1.disabled = needsNone;
  if (v2) {
    v2.disabled = needsNone ? true : !needsTwo;
    if (!needsTwo) v2.value = '';
  }
}

async function ensureCatOptions(tr) {
  const sel = tr.querySelector('.cat-select');
  const hidden = tr.querySelector('.cat-hidden');
  const col = tr.getAttribute('data-col');
  if (!sel || !hidden || !col) return;

  if (sel.getAttribute('data-loaded') === '1') return;

  const maxRows = profileRowsValue();
  const top = 50;

  const res = await fetchJson(`?r=api/value_counts&col=${encodeURIComponent(col)}&top=${top}&max_rows=${encodeURIComponent(maxRows)}`);
  if (!res.ok) {
    sel.innerHTML = `<option value="">(failed to load)</option>`;
    sel.setAttribute('data-loaded', '1');
    return;
  }

  const current = hidden.value || '';
  const labels = Array.isArray(res.labels) ? res.labels : [];
  const counts = Array.isArray(res.counts) ? res.counts : [];

  let html = `<option value="">(choose…)</option>`;
  for (let i = 0; i < labels.length; i++) {
    const v = String(labels[i]);
    const c = counts[i] ?? '';
    const selected = (v === current) ? ' selected' : '';
    html += `<option value="${v.replace(/"/g,'&quot;')}"${selected}>${v} (${c})</option>`;
  }

  if (current && !labels.includes(current)) {
    html = `<option value="${current.replace(/"/g,'&quot;')}" selected>${current} (current)</option>` + html;
  }

  sel.innerHTML = html;
  sel.setAttribute('data-loaded', '1');

  sel.addEventListener('change', () => {
    hidden.value = sel.value || '';
  });
}

function refreshCategoricalRow(tr) {
  const op = tr.querySelector('.cat-op')?.value || '';
  const sel = tr.querySelector('.cat-select');
  const txt = tr.querySelector('.cat-text');
  const hidden = tr.querySelector('.cat-hidden');

  const showDropdown = (op === 'equals' || op === 'not_equals');
  const showText = (op === 'contains' || op === 'starts_with' || op === 'ends_with');
  const needsNone = (op === '' || op === 'is_blank' || op === 'not_blank');

  if (sel) sel.style.display = showDropdown ? '' : 'none';
  if (txt) txt.style.display = showText ? '' : 'none';

  if (needsNone) {
    if (hidden) hidden.value = '';
    if (txt) txt.value = '';
    return;
  }

  if (showDropdown) ensureCatOptions(tr);

  if (showText && hidden && txt) {
    hidden.value = txt.value || '';
    txt.addEventListener('input', () => hidden.value = txt.value || '');
  }
}

function refreshAllFilters() {
  document.querySelectorAll('tr.filter-row').forEach(tr => {
    const t = tr.getAttribute('data-type');
    if (t === 'numeric') refreshNumericRow(tr);
    if (t === 'categorical') refreshCategoricalRow(tr);
  });
}

document.addEventListener('change', (ev) => {
  const el = ev.target;
  if (el.classList.contains('num-op') || el.classList.contains('cat-op')) refreshAllFilters();
});

refreshAllFilters();


  // --- Quick Profile panel
  let profileChart = null;

  function setProfileError(msg) {
    document.getElementById('profileErr').textContent = msg || '';
  }

  async function loadProfile() {
    setProfileError('');

    const col = document.getElementById('profileCol').value;
    const maxRows = parseInt(document.getElementById('profileRows').value || '20000', 10);

    try {
      const res = await fetch(`?r=api/col_profile&col=${encodeURIComponent(col)}&max_rows=${encodeURIComponent(maxRows)}`);
      const json = await res.json();
      if (!json.ok) throw new Error(json.error || 'Failed to profile column.');

      document.getElementById('pMissingPct').textContent = (json.missing_pct ?? '—') + '%';
      document.getElementById('pUnique').textContent = String(json.unique ?? '—') + (json.unique_capped ? '+' : '');
      document.getElementById('pMin').textContent = json.min ?? '—';
      document.getElementById('pMedian').textContent = json.median ?? '—';
      document.getElementById('pMax').textContent = json.max ?? '—';

      const canvas = document.getElementById('profileChart');
      if (profileChart) { profileChart.destroy(); profileChart = null; }
      if (json.chart && typeof Chart !== 'undefined') {
        profileChart = new Chart(canvas, json.chart);
      }
    } catch (e) {
      console.error(e);
      setProfileError(e?.message || String(e));
    }
  }

  document.getElementById('btnProfile').addEventListener('click', loadProfile);
  document.getElementById('profileCol').addEventListener('change', loadProfile);

  // initial load
  loadProfile();
})();
</script>
