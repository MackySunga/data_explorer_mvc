<?php
// app/Views/visualize.php
// expected from controller: $meta, $maxRows, $summary
$types = $summary['types'] ?? [];
$cols  = $summary['columns'] ?? [];
$numeric = array_values(array_filter($cols, fn($c) => ($types[$c] ?? '') === 'numeric'));
?>

<h1 class="h4 mb-3 d-flex justify-content-between align-items-center">
  <span>Visualize: <?= e($meta['name']) ?></span>

  <div class="d-flex gap-2 align-items-center">
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/table">Back</a>
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/reports">Reports</a>

    <button id="btnDownloadPdf" class="btn btn-success btn-sm" type="button">
      Download PDF (queued charts)
    </button>

    <span class="small text-muted">
      Queued: <span data-queue-count>0</span>
    </span>
  </div>
</h1>

<div class="row g-3">
  <!-- LEFT: Builder -->
  <div class="col-lg-4">
    <div class="card shadow-sm">
      <div class="card-body">
        <h2 class="h6 mb-3">Chart Builder</h2>

        <div class="mb-2">
          <label class="form-label">Max rows used</label>
          <input id="maxRows" class="form-control" type="number" min="1000" max="200000" value="<?= (int)$maxRows ?>">
          <div class="form-text">Used for chart data sampling/aggregation.</div>
        </div>

        <div class="mb-2">
          <label class="form-label">Chart type</label>
          <select id="chartType" class="form-select">
            <optgroup label="Common">
              <option value="hist">Histogram (numeric)</option>
              <option value="bar">Bar chart (categorical)</option>
              <option value="pie">Pie (categorical)</option>
              <option value="doughnut">Doughnut (categorical)</option>
              <option value="line">Line (numeric over X or row index)</option>
              <option value="scatter">Scatter (numeric vs numeric)</option>
            </optgroup>
            <optgroup label="Distribution (plugin)">
              <option value="boxplot">Box plot (numeric)</option>
              <option value="violin">Violin plot (numeric)</option>
            </optgroup>
          </select>
          <div class="form-text">
            Box/Violin use a Chart.js plugin loaded via CDN (no Composer).
          </div>
        </div>

        <!-- Single-column selector -->
        <div id="singleColBlock" class="mb-2">
          <label class="form-label">Column</label>
          <select id="col1" class="form-select">
            <?php foreach ($cols as $c): ?>
              <option value="<?= e($c) ?>"><?= e($c) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- Line options -->
        <div id="lineBlock" class="mb-2" style="display:none;">
          <label class="form-label">X column (optional)</label>
          <select id="lineX" class="form-select mb-2">
            <option value="">(use row index)</option>
            <?php foreach ($cols as $c): ?>
              <option value="<?= e($c) ?>"><?= e($c) ?></option>
            <?php endforeach; ?>
          </select>

          <label class="form-label">Y column (numeric)</label>
          <select id="lineY" class="form-select">
            <?php foreach ($numeric as $c): ?>
              <option value="<?= e($c) ?>"><?= e($c) ?></option>
            <?php endforeach; ?>
          </select>

          <div class="form-text">If X is blank, Y is plotted in file order.</div>
        </div>

        <!-- Scatter options -->
        <div id="scatterBlock" class="mb-2" style="display:none;">
          <label class="form-label">X column (numeric)</label>
          <select id="xCol" class="form-select mb-2">
            <?php foreach ($numeric as $c): ?>
              <option value="<?= e($c) ?>"><?= e($c) ?></option>
            <?php endforeach; ?>
          </select>

          <label class="form-label">Y column (numeric)</label>
          <select id="yCol" class="form-select">
            <?php foreach ($numeric as $c): ?>
              <option value="<?= e($c) ?>"><?= e($c) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- Grouping for box/violin (optional) -->
        <div id="groupBlock" class="mb-2" style="display:none;">
          <label class="form-label">Group by (optional categorical)</label>
          <select id="groupCol" class="form-select">
            <option value="">(no grouping)</option>
            <?php foreach ($cols as $c): ?>
              <option value="<?= e($c) ?>"><?= e($c) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="form-text">If set, box/violin will show per-group distributions (top groups only).</div>
        </div>

        <!-- Histogram options -->
        <div id="histOpts" class="mb-2">
          <label class="form-label">Bins (histogram)</label>
          <input id="bins" class="form-control" type="number" min="5" max="50" value="12">
        </div>

        <!-- Category options (bar/pie/doughnut) -->
        <div id="catOpts" class="mb-2" style="display:none;">
          <label class="form-label">Top N categories</label>
          <input id="topN" class="form-control" type="number" min="5" max="50" value="12">
          <div class="form-text">Anything beyond top N becomes “Others”.</div>
        </div>

        <div class="d-flex gap-2 mt-3">
          <button id="btnDraw" class="btn btn-primary w-100" type="button">Draw</button>
          <button id="btnAddToPdf" class="btn btn-outline-primary w-100" type="button">Add to PDF</button>
        </div>

        <div class="form-check mt-3">
          <input class="form-check-input" type="checkbox" id="showLegend" checked>
          <label class="form-check-label" for="showLegend">Show legend</label>
        </div>

        <div id="pdfStatus" class="small mt-2"></div>

        <hr class="my-3">

        <div class="d-flex justify-content-between align-items-center mb-2">
          <div class="fw-semibold">PDF Queue</div>
          <button id="btnClearQueue" class="btn btn-sm btn-outline-secondary" type="button">Clear</button>
        </div>

        <div id="queueInfo" class="small"></div>
      </div>
    </div>
  </div>

  <!-- RIGHT: Canvas -->
  <div class="col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <canvas id="chartCanvas" height="140" data-report-chart data-report-chart-title="Chart"></canvas>
        <div id="chartError" class="text-danger small mt-2"></div>
      </div>
    </div>
  </div>
</div>

<!-- Box/Violin plugin (Chart.js boxplots + violin plots) -->
<script src="https://cdn.jsdelivr.net/npm/@sgratzl/chartjs-chart-boxplot@4.4.5/build/index.umd.min.js"></script>

<script>
(function(){
  // =========================
  // UI toggles
  // =========================
  const chartTypeEl = document.getElementById('chartType');
  const singleColBlock = document.getElementById('singleColBlock');
  const scatterBlock = document.getElementById('scatterBlock');
  const lineBlock = document.getElementById('lineBlock');
  const histOpts = document.getElementById('histOpts');
  const catOpts = document.getElementById('catOpts');
  const groupBlock = document.getElementById('groupBlock');

  function updateBlocks() {
    const t = chartTypeEl.value;

    singleColBlock.style.display = '';
    scatterBlock.style.display = 'none';
    lineBlock.style.display = 'none';
    histOpts.style.display = 'none';
    catOpts.style.display = 'none';
    groupBlock.style.display = 'none';

    if (t === 'scatter') {
      singleColBlock.style.display = 'none';
      scatterBlock.style.display = '';
    } else if (t === 'line') {
      singleColBlock.style.display = 'none';
      lineBlock.style.display = '';
    } else if (t === 'hist') {
      histOpts.style.display = '';
    } else if (t === 'bar' || t === 'pie' || t === 'doughnut') {
      catOpts.style.display = '';
    } else if (t === 'boxplot' || t === 'violin') {
      groupBlock.style.display = '';
    }
  }
  chartTypeEl.addEventListener('change', updateBlocks);
  updateBlocks();

  // =========================
  // Chart render
  // =========================
  let currentChart = null;

  function setError(msg) {
    document.getElementById('chartError').textContent = msg || '';
  }

  async function drawChart() {
    setError('');
    const maxRows = parseInt(document.getElementById('maxRows').value || '50000', 10);
    const type = document.getElementById('chartType').value;
    const showLegend = document.getElementById('showLegend').checked;

    const payload = {
      max_rows: maxRows,
      chart_type: type,
      show_legend: !!showLegend,
      col1: document.getElementById('col1')?.value || '',
      bins: parseInt(document.getElementById('bins')?.value || '12', 10),
      topN: parseInt(document.getElementById('topN')?.value || '12', 10),
      xCol: document.getElementById('xCol')?.value || '',
      yCol: document.getElementById('yCol')?.value || '',
      lineX: document.getElementById('lineX')?.value || '',
      lineY: document.getElementById('lineY')?.value || '',
      groupCol: document.getElementById('groupCol')?.value || '',
    };

    try {
      const res = await fetch('?r=explore/chart_data', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload),
      });
      const json = await res.json();

      if (!json.ok) throw new Error(json.error || 'Failed to generate chart.');

      const title = json.title || 'Chart';
      document.getElementById('chartCanvas').setAttribute('data-report-chart-title', title);

      if (currentChart) { currentChart.destroy(); currentChart = null; }
      currentChart = new Chart(document.getElementById('chartCanvas'), json.chart);
    } catch (e) {
      console.error(e);
      setError(e?.message || String(e));
    }
  }

  document.getElementById('btnDraw').addEventListener('click', drawChart);

  // =========================
  // PDF Queue (ALWAYS works)
  // Reads/writes same localStorage key as app.js
  // =========================
  const QUEUE_KEY = "data_explorer_pdf_queue_v1";

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (m) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
    }[m]));
  }

  function loadQueueLS() {
    try {
      const v = JSON.parse(localStorage.getItem(QUEUE_KEY) || "[]");
      return Array.isArray(v) ? v : [];
    } catch (e) {
      return [];
    }
  }

  function saveQueueLS(q) {
    localStorage.setItem(QUEUE_KEY, JSON.stringify(q || []));
  }

  function updateCountEls(q) {
    const n = (q ? q.length : loadQueueLS().length);
    document.querySelectorAll("[data-queue-count]").forEach(el => el.textContent = String(n));
    // if app.js exists, let it sync too
    if (window.ReportQueue && typeof ReportQueue.updateCountEls === 'function') {
      ReportQueue.updateCountEls();
    }
  }

  function renderQueueInfo() {
    const el = document.getElementById('queueInfo');
    const q = loadQueueLS();
    updateCountEls(q);

    if (!q.length) {
      el.innerHTML = '<span class="text-muted">Queue is empty. Draw a chart, then “Add to PDF”.</span>';
      return;
    }

    const items = q.map((c, i) => `
      <div class="d-flex justify-content-between align-items-center border rounded p-2 mb-1">
        <div><strong>${i+1}.</strong> ${escapeHtml(c.title || 'Chart')}</div>
        <button class="btn btn-sm btn-outline-danger" type="button" data-remove="${i}">Remove</button>
      </div>
    `).join('');

    el.innerHTML = `
      <div class="mb-2"><strong>Queued charts:</strong> ${q.length}</div>
      ${items}
    `;

    el.querySelectorAll('[data-remove]').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-remove'), 10);
        const qq = loadQueueLS();
        qq.splice(idx, 1);
        saveQueueLS(qq);
        renderQueueInfo();
      });
    });
  }

  async function addToPdfQueue() {
    const status = document.getElementById('pdfStatus');
    const canvas = document.getElementById('chartCanvas');

    if (!currentChart) {
      status.innerHTML = '<span class="text-warning">Draw a chart first.</span>';
      return;
    }

    await new Promise(r => setTimeout(r, 150));

    const title = canvas.getAttribute('data-report-chart-title') || 'Chart';
    const dataUrl = canvas.toDataURL('image/png', 1.0);

    const q = loadQueueLS();
    q.push({ title, dataUrl });
    saveQueueLS(q);

    status.innerHTML = `<span class="text-success">Added to queue: ${escapeHtml(title)}</span>`;
    renderQueueInfo();
  }

  document.getElementById('btnAddToPdf').addEventListener('click', addToPdfQueue);

  document.getElementById('btnClearQueue').addEventListener('click', () => {
    if (!confirm('Clear queued charts?')) return;
    saveQueueLS([]);
    renderQueueInfo();
  });

  async function downloadPdfQueuedCharts() {
    const btn = document.getElementById('btnDownloadPdf');
    const status = document.getElementById('pdfStatus');

    const q = loadQueueLS();
    if (!q.length) {
      alert('Queue is empty. Add charts first.');
      return;
    }

    const maxRows = parseInt(document.getElementById('maxRows').value || '50000', 10);

    try {
      btn.disabled = true;
      btn.textContent = 'Preparing PDF...';
      status.innerHTML = '<span class="text-muted">Saving report...</span>';

      // 1) Save report JSON
      const saveRes = await fetch('?r=explore/report_save_ajax&max_rows=' + encodeURIComponent(maxRows), { method: 'POST' });
      const saveJson = await saveRes.json();
      if (!saveJson.ok) throw new Error(saveJson.error || 'Failed to save report.');
      const reportFile = saveJson.file;

      // 2) Attach queued charts
      status.innerHTML = '<span class="text-muted">Uploading charts...</span>';
      const attachRes = await fetch('?r=explore/report_attach_charts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ file: reportFile, charts: q })
      });
      const attachJson = await attachRes.json();
      if (!attachJson.ok) throw new Error(attachJson.error || 'Failed to attach charts.');

      status.innerHTML = '<span class="text-success">Downloading PDF...</span>';
      window.location.href = '?r=explore/report_pdf&file=' + encodeURIComponent(reportFile);
    } catch (e) {
      console.error(e);
      alert(e?.message || String(e));
      status.innerHTML = '<span class="text-danger">Failed. See console.</span>';
    } finally {
      btn.disabled = false;
      btn.textContent = 'Download PDF (queued charts)';
    }
  }

  document.getElementById('btnDownloadPdf').addEventListener('click', downloadPdfQueuedCharts);

  // Initial render + keep fresh when returning to tab
  renderQueueInfo();
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) renderQueueInfo();
  });
})();
</script>
