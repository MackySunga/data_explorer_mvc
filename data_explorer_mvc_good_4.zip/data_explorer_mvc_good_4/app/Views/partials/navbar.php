<?php
declare(strict_types=1);
/**
 * app/Views/partials/navbar.php
 * Expects:
 *  - $navItems (from layout.php)
 * Uses:
 *  - e() helper for escaping
 */
$navItems = is_array($navItems ?? null) ? $navItems : [];

// Use unique IDs to avoid collisions with any view content.
$collapseId = 'de_nav_collapse';
$themeMenuId = 'de_theme_menu';
?>
<nav class="navbar navbar-expand-lg bg-body-tertiary border-bottom sticky-top" style="z-index:1030;">
  <div class="container-fluid">
    <a class="navbar-brand fw-semibold" href="?r=dataset/upload">Data Explorer</a>

    <button class="navbar-toggler" type="button"
            data-bs-toggle="collapse"
            data-bs-target="#<?= e($collapseId) ?>"
            aria-controls="<?= e($collapseId) ?>"
            aria-expanded="false"
            aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div id="<?= e($collapseId) ?>" class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <?php foreach ($navItems as $group): ?>
          <?php
            $label = (string)($group['label'] ?? '');
            $isGroupActive = !empty($group['active']);
            $items = is_array($group['items'] ?? null) ? $group['items'] : [];

            // IMPORTANT: fallback href behavior
            // - If dropdown JS fails, clicking the group will still navigate somewhere useful.
            // - Use the first item href (if any), else group href (if provided), else "#".
            $fallbackHref = '#';
            if (!empty($items) && isset($items[0]['href'])) {
              $fallbackHref = (string)$items[0]['href'];
            } elseif (!empty($group['href'])) {
              $fallbackHref = (string)$group['href'];
            }
          ?>

          <?php if (!empty($items)): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle <?= $isGroupActive ? 'active fw-semibold' : '' ?>"
                 href="<?= e($fallbackHref) ?>"
                 role="button"
                 data-bs-toggle="dropdown"
                 data-bs-auto-close="outside"
                 aria-expanded="false">
                <?= e($label) ?>
              </a>

              <ul class="dropdown-menu">
                <?php foreach ($items as $item): ?>
                  <?php
                    $itemLabel = (string)($item['label'] ?? '');
                    $itemHref  = (string)($item['href'] ?? '#');
                    $itemActive = !empty($item['active']);
                  ?>
                  <li>
                    <a class="dropdown-item <?= $itemActive ? 'active fw-semibold' : '' ?>"
                       href="<?= e($itemHref) ?>"
                       <?= $itemActive ? 'aria-current="page"' : '' ?>>
                      <?= e($itemLabel) ?>
                    </a>
                  </li>
                <?php endforeach; ?>
              </ul>
            </li>

          <?php else: ?>
            <li class="nav-item">
              <a class="nav-link <?= $isGroupActive ? 'active fw-semibold' : '' ?>"
                 href="<?= e((string)($group['href'] ?? '#')) ?>"
                 <?= $isGroupActive ? 'aria-current="page"' : '' ?>>
                <?= e($label) ?>
              </a>
            </li>
          <?php endif; ?>

        <?php endforeach; ?>

      </ul>

      <div class="d-flex gap-2 align-items-center">
        <div class="dropdown">
          <button class="btn btn-outline-secondary btn-sm dropdown-toggle"
                  type="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false">
            Theme
          </button>
          <ul class="dropdown-menu dropdown-menu-end" id="<?= e($themeMenuId) ?>"></ul>
        </div>
      </div>
    </div>
  </div>
</nav>

<script>
  // If your app.js is still using "theme-menu", map it to the new ID seamlessly.
  // (So you don't have to touch app.js right now.)
  document.addEventListener("DOMContentLoaded", () => {
    const old = document.getElementById("theme-menu");
    const neu = document.getElementById("<?= $themeMenuId ?>");
    if (!old && neu) neu.id = "theme-menu";
  });
</script>
