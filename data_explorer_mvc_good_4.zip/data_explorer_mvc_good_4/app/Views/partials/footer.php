<footer class="border-top mt-4 py-3">
  <div class="container">
    <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-2">
      <div class="text-muted small">
        Built with PHP MVC (Model-View-Controller) + Bootstrap + Chart.js (no Composer).
        <span class="mx-1">·</span>
        Created by <strong>Bob Mathew David Sunga</strong>
      </div>
      <div class="text-muted small">© <?= date('Y') ?></div>
    </div>
  </div>
</footer>
