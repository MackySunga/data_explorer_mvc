<?php
/** @var string $pageTitle */
$pageTitle = $pageTitle ?? 'Data Explorer MVC';
?>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle ?? 'Data Explorer') ?></title>


  <link id="theme-css" rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">

  <link rel="stylesheet" href="assets/css/app.css">

  <!-- Chart.js (JavaScript charting library) -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
</head>
