<?php
/** @var array $flashes */
$flashes = $flashes ?? [];
?>

<?php foreach ($flashes as $f): ?>
  <div class="alert alert-<?= e($f['type']) ?>">
    <pre class="mb-0"><?= e($f['message']) ?></pre>
  </div>
<?php endforeach; ?>
