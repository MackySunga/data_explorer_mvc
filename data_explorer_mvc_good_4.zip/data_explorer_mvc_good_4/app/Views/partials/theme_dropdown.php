<div class="dropdown">
  <button class="btn btn-outline-secondary btn-sm dropdown-toggle" data-bs-toggle="dropdown">
    Theme
  </button>
  <ul class="dropdown-menu dropdown-menu-end" id="theme-menu"></ul>
</div>
