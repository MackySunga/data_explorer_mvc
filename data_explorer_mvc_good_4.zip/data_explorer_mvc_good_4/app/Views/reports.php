<?php
declare(strict_types=1);
/**
 * Expects:
 *  - $meta (active dataset meta)
 *  - $files (array of report json basenames)
 */
?>

<h1 class="h4 mb-3">Reports: <?= e($meta['name']) ?></h1>

<div class="card shadow-sm mb-3">
  <div class="card-body">
    <form method="post" action="?r=explore/report_save" class="d-flex gap-2 align-items-end flex-wrap">
      <div>
        <label class="form-label">Max rows used for report</label>
        <input class="form-control" type="number" name="max_rows" min="1000" max="200000" value="50000">
      </div>
      <button class="btn btn-primary">Save report</button>
      <a class="btn btn-outline-secondary" href="?r=explore/table">Back</a>
    </form>
  </div>
</div>

<div class="card shadow-sm">
  <div class="card-body">
    <h2 class="h6">Saved report files</h2>

    <?php if (empty($files)): ?>
      <div class="text-muted">No reports saved yet.</div>
    <?php else: ?>
      <div class="list-group">
        <?php foreach ($files as $f): ?>
          <div class="list-group-item d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div class="small">
              <div class="fw-semibold"><?= e($f) ?></div>
              <div class="text-muted">Stored in <code>storage/reports/</code></div>
            </div>

            <div class="d-flex gap-2 flex-wrap">
              <a class="btn btn-sm btn-outline-secondary" href="?r=explore/report_view&file=<?= e($f) ?>">View</a>
              <a class="btn btn-sm btn-outline-secondary" href="?r=explore/report_download&file=<?= e($f) ?>">Download JSON</a>
              <a class="btn btn-sm btn-outline-secondary" href="?r=explore/report_pdf&file=<?= e($f) ?>">PDF</a>

              <form method="post"
                    action="?r=explore/report_delete"
                    class="d-inline"
                    onsubmit="return confirm('Delete this report?\\n\\n<?= e($f) ?>');">
                <input type="hidden" name="file" value="<?= e($f) ?>">
                <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="text-muted small mt-2">
        Tip: Deleting a report removes the JSON file. Any chart images that are no longer referenced by other reports will also be cleaned up.
      </div>
    <?php endif; ?>
  </div>
</div>
