<?php
declare(strict_types=1);

$route = (string)($_GET['r'] ?? 'dataset/upload');
$navItems = \App\ViewData\Nav::items($route);

$flashes = flash_get_all();

// IMPORTANT: do NOT override pageTitle if controller/render already set it
if (!isset($pageTitle) || trim((string)$pageTitle) === '') {
    $pageTitle = 'Data Explorer MVC';
}

// $viewFile is provided by your render() function
?>
<!doctype html>
<html lang="en">
<?php include __DIR__ . '/partials/head.php'; ?>
<body>

<?php include __DIR__ . '/partials/navbar.php'; ?>

<main class="container py-4">
  <?php include __DIR__ . '/partials/flashes.php'; ?>

  <?php include $viewFile; ?>
</main>

<?php include __DIR__ . '/partials/footer.php'; ?>

<?php include __DIR__ . '/partials/scripts.php'; ?>
</body>
</html>
