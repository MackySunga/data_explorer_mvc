<?php
$M = $fmt['meta'] ?? [];
$corr = $fmt['corr'] ?? ['cols'=>[], 'matrix'=>[], 'cap'=>12];
$cols = $corr['cols'] ?? [];
$mat  = $corr['matrix'] ?? [];
$cap  = (int)($corr['cap'] ?? 12);
?>

<div class="d-flex justify-content-between align-items-start mb-3">
  <div>
    <h1 class="h4 mb-1">Correlation: <?= e($meta['name'] ?? '') ?></h1>
    <div class="text-muted small">
      Same capped correlation matrix as the PDF report.
      · Max rows used: <strong><?= (int)$maxRows ?></strong>
      · Columns shown: <strong><?= (int)count($cols) ?></strong> (cap <?= $cap ?>)
    </div>
  </div>

  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/table">Explore</a>
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/reports">Reports</a>
    <a class="btn btn-primary btn-sm" href="?r=explore/report_save&max_rows=<?= (int)$maxRows ?>">Save Report</a>
  </div>
</div>

<div class="card shadow-sm mb-3">
  <div class="card-body">
    <form class="row g-2 align-items-end" method="get">
      <input type="hidden" name="r" value="explore/correlation">

      <div class="col-sm-4 col-md-3">
        <label class="form-label">Max rows used</label>
        <input name="max_rows" class="form-control" type="number" min="1000" max="200000" value="<?= (int)$maxRows ?>">
        <div class="form-text">Higher = more accurate, but slower.</div>
      </div>

      <div class="col-sm-3 col-md-2">
        <button class="btn btn-primary w-100" type="submit">Recompute</button>
      </div>

      <div class="col-sm-3 col-md-2">
        <a class="btn btn-outline-secondary w-100" href="?r=explore/table">Explore</a>
      </div>
    </form>
  </div>
</div>

<!-- Small chart -->
<div class="card shadow-sm mb-3">
  <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <div class="fw-semibold">Top Absolute Correlations</div>
      <div class="text-muted small">Top 10 pairs from the capped matrix</div>
    </div>

    <?php if (empty($cols) || empty($mat)): ?>
      <div class="text-muted small">No correlation matrix available (not enough numeric columns).</div>
    <?php else: ?>
      <canvas id="topCorrChart" height="130"></canvas>

      <div class="d-flex flex-wrap gap-2 mt-2 align-items-center">
        <button class="btn btn-outline-primary btn-sm" type="button"
          data-queue-add="#topCorrChart"
          data-queue-title="Correlation: Top Absolute Correlations"
          data-queue-status="#queueStatusCorr">
          Add chart to PDF queue
        </button>

        <button class="btn btn-success btn-sm" type="button"
          data-queue-download
          data-maxrows="<?= (int)$maxRows ?>">
          Download PDF (queued charts)
        </button>

        <button class="btn btn-outline-secondary btn-sm" type="button" data-queue-clear>
          Clear queue
        </button>

        <span class="small text-muted">Queued: <span data-queue-count></span></span>
        <span id="queueStatusCorr" class="small text-muted"></span>
      </div>
    <?php endif; ?>

    <hr class="my-3">
    <div class="fw-semibold mb-2">PDF Queue Items</div>
    <div id="queueInfoCorr" class="small"></div>
  </div>
</div>

<style>
  .report-table { font-size: 0.92rem; }
  .report-mono { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace; }
  .report-table th { white-space: nowrap; }
</style>

<div class="card shadow-sm">
  <div class="card-body">
    <h2 class="h6 mb-2">Correlation Matrix (Pearson r)</h2>
    <div class="text-muted small mb-2">Capped to first <?= (int)$cap ?> numeric columns (same as PDF).</div>

    <?php if (empty($cols) || empty($mat)): ?>
      <div class="text-muted small">No correlation matrix available.</div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-sm table-bordered report-table align-middle">
          <thead class="table-light">
            <tr>
              <th></th>
              <?php foreach ($cols as $c): ?>
                <th class="text-end"><?= e((string)$c) ?></th>
              <?php endforeach; ?>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($mat as $i => $row): ?>
              <tr>
                <th><?= e((string)($cols[$i] ?? '')) ?></th>
                <?php foreach ($row as $v): ?>
                  <td class="text-end report-mono"><?= e((string)$v) ?></td>
                <?php endforeach; ?>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php if (!empty($cols) && !empty($mat)): ?>
<script>
(function(){
  const cols = <?= json_encode($cols, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
  const mat  = <?= json_encode($mat,  JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
  const ctx = document.getElementById('topCorrChart');
  if (!ctx || typeof Chart === 'undefined') return;

  const pairs = [];
  for (let i = 0; i < cols.length; i++) {
    for (let j = i + 1; j < cols.length; j++) {
      const r = parseFloat(mat[i][j]);
      if (!Number.isFinite(r)) continue;
      pairs.push({
        label: `${cols[i]} vs ${cols[j]}`,
        abs: Math.abs(r),
        r: r
      });
    }
  }

  pairs.sort((a,b) => b.abs - a.abs);
  const top = pairs.slice(0, 10);

  const labels = top.map(x => x.label);
  const vals = top.map(x => x.abs);
  const signed = top.map(x => x.r);

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: '|r| (absolute Pearson correlation)',
        data: vals
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      plugins: {
        legend: { display: true, position: 'bottom' },
        tooltip: {
          enabled: true,
          callbacks: {
            label: (tt) => {
              const i = tt.dataIndex;
              const abs = tt.raw;
              const r = signed[i];
              return ` |r|=${abs.toFixed(3)} (r=${r.toFixed(3)})`;
            }
          }
        }
      },
      scales: {
        x: { beginAtZero: true, max: 1 }
      }
    }
  });
})();
</script>
<?php endif; ?>

<script>
(function(){
  const KEY = "data_explorer_pdf_queue_v1";
  const box = document.getElementById("queueInfoCorr");
  if (!box) return;

  const esc = (s) => String(s).replace(/[&<>"']/g, (m) => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[m]));

  function loadQ(){
    try {
      const q = JSON.parse(localStorage.getItem(KEY) || "[]");
      return Array.isArray(q) ? q : [];
    } catch (e) {
      return [];
    }
  }

  function saveQ(q) {
    localStorage.setItem(KEY, JSON.stringify(q || []));
    document.querySelectorAll("[data-queue-count]").forEach(el => el.textContent = String((q||[]).length));
    if (window.ReportQueue && typeof window.ReportQueue.updateCountEls === "function") {
      window.ReportQueue.updateCountEls();
    }
  }

  function render(){
    const q = loadQ();
    document.querySelectorAll("[data-queue-count]").forEach(el => el.textContent = String(q.length));

    if (!q.length) {
      box.innerHTML = '<span class="text-muted">Queue is empty. Add charts from any page using “Add chart to PDF queue”.</span>';
      return;
    }

    const rows = q.map((c, i) => `
      <div class="d-flex justify-content-between align-items-center border rounded p-2 mb-1">
        <div><strong>${i+1}.</strong> ${esc(c.title || "Chart")}</div>
        <button type="button" class="btn btn-sm btn-outline-danger" data-q-remove="${i}">Remove</button>
      </div>
    `).join("");

    box.innerHTML = `
      <div class="mb-2"><strong>Queued charts:</strong> ${q.length}</div>
      ${rows}
      <div class="d-flex gap-2 mt-2">
        <button type="button" class="btn btn-sm btn-outline-secondary" data-q-clear>Clear queue</button>
      </div>
    `;

    box.querySelectorAll("[data-q-remove]").forEach(btn => {
      btn.addEventListener("click", () => {
        const idx = parseInt(btn.getAttribute("data-q-remove"), 10);
        const qq = loadQ();
        qq.splice(idx, 1);
        saveQ(qq);
        render();
      });
    });

    box.querySelector("[data-q-clear]")?.addEventListener("click", () => {
      if (!confirm("Clear queued charts?")) return;
      saveQ([]);
      render();
    });
  }

  render();

  document.querySelectorAll("[data-queue-add],[data-queue-clear],[data-queue-download]").forEach(btn => {
    btn.addEventListener("click", () => setTimeout(render, 250));
  });

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) render();
  });
})();
</script>
