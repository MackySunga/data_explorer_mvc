<div class="row g-4">
  <div class="col-lg-7">
    <div class="card shadow-sm">
      <div class="card-body">
        <h1 class="h4 mb-3">Upload CSV</h1>
        <form method="post" enctype="multipart/form-data" action="?r=dataset/upload">
          <div class="mb-3">
            <label class="form-label">CSV File</label>
            <input class="form-control" type="file" name="csv" accept=".csv,text/csv">
            <div class="form-text">If upload fails, the error message will show exactly what’s wrong (temp path, permissions, etc.).</div>
          </div>
          <button class="btn btn-primary">Upload & Explore</button>
          <a class="btn btn-outline-secondary" href="?r=dataset/list">Manage datasets</a>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card shadow-sm">
      <div class="card-body">
        <h2 class="h6">What you can do here</h2>
        <ul class="mb-0">
          <li>Preview data with paging, search, and column selection</li>
          <li>Compute descriptive stats and missing values</li>
          <li>Make charts (histogram, bar chart, scatter plot)</li>
          <li>Correlation, outliers, and saved reports</li>
        </ul>
      </div>
    </div>
  </div>
</div>
