<?php
// app/Views/table.php
// expected vars from controller (common):
// $meta, $rows, $columns, $selectedCols, $search, $page, $pages, $perPage, $matchedRows, $maxRows
$meta = $meta ?? [];
$rows = $rows ?? [];
$columns = $columns ?? [];
$selectedCols = $selectedCols ?? $columns;

$search = (string)($search ?? '');
$page = (int)($page ?? 1);
$pages = (int)($pages ?? 1);
$perPage = (int)($perPage ?? 25);
$matchedRows = (int)($matchedRows ?? count($rows));
$maxRows = (int)($maxRows ?? 50000);

function q(array $extra = []): string {
  $params = array_merge($_GET, $extra);
  return '?' . http_build_query($params);
}
?>

<h1 class="h4 mb-3 d-flex justify-content-between align-items-center">
  <span>Explore: <?= e((string)($meta['name'] ?? '')) ?></span>

  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/stats">Stats</a>
    <a class="btn btn-outline-secondary btn-sm" href="?r=explore/visualize">Visualize</a>
  </div>
</h1>

<div class="row g-3">
  <!-- LEFT: Kaggle-like table -->
  <div class="col-lg-9">
    <div class="card shadow-sm mb-3">
      <div class="card-body">
        <form class="row g-2 align-items-end" method="get">
          <input type="hidden" name="r" value="explore/table">

          <div class="col-md-5">
            <label class="form-label">Global Search</label>
            <input class="form-control" name="q" value="<?= e($search) ?>" placeholder="Search across all columns...">
          </div>

          <div class="col-md-2">
            <label class="form-label">Rows / page</label>
            <input class="form-control" type="number" name="per_page" min="10" max="200" value="<?= (int)$perPage ?>">
          </div>

          <div class="col-md-5">
            <label class="form-label">Columns to show</label>
            <select class="form-select" name="cols[]" multiple size="5">
              <?php foreach ($columns as $c): ?>
                <option value="<?= e($c) ?>" <?= in_array($c, $selectedCols, true) ? 'selected' : '' ?>>
                  <?= e($c) ?>
                </option>
              <?php endforeach; ?>
            </select>
            <div class="form-text">Hold Ctrl to select multiple.</div>
          </div>

          <div class="col-12 d-flex gap-2 mt-2">
            <button class="btn btn-primary" type="submit">Apply</button>
            <a class="btn btn-outline-secondary" href="?r=explore/table">Reset</a>

            <div class="ms-auto d-flex gap-2">
              <button class="btn btn-outline-secondary" type="button" data-bs-toggle="offcanvas" data-bs-target="#insightsCanvas">
                Column Insights
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>

    <div class="card shadow-sm">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <div class="text-muted small">Matched rows: <strong><?= (int)$matchedRows ?></strong></div>
          <div class="text-muted small">Page <?= (int)$page ?> / <?= (int)$pages ?></div>
        </div>

        <div class="table-responsive kaggle-table-wrap">
          <table class="table table-sm table-hover align-middle kaggle-table" id="exploreTable">
            <thead>
              <tr>
                <?php foreach ($selectedCols as $c): ?>
                  <th class="kaggle-th" data-col="<?= e($c) ?>" title="Click for insights">
                    <?= e($c) ?>
                    <span class="ms-1 text-muted small">↗</span>
                  </th>
                <?php endforeach; ?>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rows as $r): ?>
                <tr>
                  <?php foreach ($selectedCols as $c): ?>
                    <td><?= e((string)($r[$c] ?? '')) ?></td>
                  <?php endforeach; ?>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <!-- simple pager -->
        <div class="d-flex justify-content-between align-items-center mt-2">
          <div class="text-muted small">Tip: Click a column header to see distribution.</div>
          <div class="d-flex gap-2">
            <a class="btn btn-outline-secondary btn-sm <?= $page <= 1 ? 'disabled' : '' ?>"
               href="<?= e(q(['page' => max(1, $page - 1)])) ?>">Prev</a>

            <a class="btn btn-outline-secondary btn-sm <?= $page >= $pages ? 'disabled' : '' ?>"
               href="<?= e(q(['page' => min($pages, $page + 1)])) ?>">Next</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- RIGHT: sticky insights panel (desktop) -->
  <div class="col-lg-3 d-none d-lg-block">
    <div class="card shadow-sm position-sticky" style="top: 12px;">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <div class="fw-semibold">Column Insights</div>
          <span class="badge text-bg-light" id="insType">—</span>
        </div>

        <div class="small text-muted mb-2" id="insCol">Click a column header</div>

        <div class="mb-2">
          <div class="d-flex justify-content-between small">
            <span class="text-muted">Missing</span>
            <span id="insMissingTxt">—</span>
          </div>
          <div class="progress" style="height: 8px;">
            <div class="progress-bar" id="insMissingBar" style="width:0%"></div>
          </div>
        </div>

        <canvas id="insightsChart" height="140" data-report-chart data-report-chart-title="Explore: Column Insight"></canvas>

        <div class="mt-2" id="insDetails"></div>

        <hr>

        <!-- Client-side filter for current page (Kaggle-ish) -->
        <div class="fw-semibold mb-2">Quick Filter (this page)</div>
        <input class="form-control form-control-sm" id="colFilterInput" placeholder="Type to filter visible rows...">
        <div class="d-flex gap-2 mt-2">
          <button class="btn btn-outline-secondary btn-sm" type="button" id="btnClearClientFilter">Clear</button>

          <button class="btn btn-outline-primary btn-sm" type="button"
            data-queue-add="#insightsChart"
            data-queue-status="#insQueueStatus">
            Add chart to PDF queue
          </button>
        </div>

        <div class="small text-muted mt-2">
          Queued: <span data-queue-count>0</span>
          <span id="insQueueStatus" class="ms-2"></span>
        </div>

        <button class="btn btn-success btn-sm w-100 mt-2" type="button"
          data-queue-download
          data-maxrows="<?= (int)$maxRows ?>">
          Download PDF (queued charts)
        </button>
      </div>
    </div>
  </div>
</div>

<!-- Offcanvas insights (mobile/tablet) -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="insightsCanvas">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title">Column Insights</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
  </div>
  <div class="offcanvas-body">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <div class="fw-semibold" id="insCol2">Click a column header</div>
      <span class="badge text-bg-light" id="insType2">—</span>
    </div>

    <div class="mb-2">
      <div class="d-flex justify-content-between small">
        <span class="text-muted">Missing</span>
        <span id="insMissingTxt2">—</span>
      </div>
      <div class="progress" style="height: 8px;">
        <div class="progress-bar" id="insMissingBar2" style="width:0%"></div>
      </div>
    </div>

    <canvas id="insightsChart2" height="160"></canvas>
    <div class="mt-2" id="insDetails2"></div>
  </div>
</div>

<script>
(() => {
  const maxRows = <?= (int)$maxRows ?>;

  let activeCol = null;
  let chart = null;
  let chart2 = null;

  const insCol = document.getElementById('insCol');
  const insType = document.getElementById('insType');
  const insMissingTxt = document.getElementById('insMissingTxt');
  const insMissingBar = document.getElementById('insMissingBar');
  const insDetails = document.getElementById('insDetails');
  const insightsChart = document.getElementById('insightsChart');

  const insCol2 = document.getElementById('insCol2');
  const insType2 = document.getElementById('insType2');
  const insMissingTxt2 = document.getElementById('insMissingTxt2');
  const insMissingBar2 = document.getElementById('insMissingBar2');
  const insDetails2 = document.getElementById('insDetails2');
  const insightsChart2 = document.getElementById('insightsChart2');

  function clearHeaderActive() {
    document.querySelectorAll('.kaggle-th.active').forEach(th => th.classList.remove('active'));
  }

  function fmtPct(p) {
    const x = Number(p || 0);
    return x.toFixed(2) + '%';
  }

  function destroyCharts() {
    if (chart) { chart.destroy(); chart = null; }
    if (chart2) { chart2.destroy(); chart2 = null; }
  }

  function renderMissing(pct, total, miss) {
    const text = `${fmtPct(pct)} (${miss}/${total})`;
    insMissingTxt.textContent = text;
    insMissingTxt2.textContent = text;

    insMissingBar.style.width = pct + '%';
    insMissingBar2.style.width = pct + '%';
  }

  function setType(t) {
    insType.textContent = t || '—';
    insType2.textContent = t || '—';
  }

  function setColName(c) {
    insCol.textContent = c ? ('Column: ' + c) : 'Click a column header';
    insCol2.textContent = c ? ('Column: ' + c) : 'Click a column header';
  }

  function renderDetails(html) {
    insDetails.innerHTML = html;
    insDetails2.innerHTML = html;
  }

  function renderNumeric(data) {
    const n = data.numeric || null;
    const hist = data.histogram || {labels:[], counts:[]};

    const html = `
      <div class="small">
        <div class="fw-semibold mb-1">Summary</div>
        <div class="d-flex justify-content-between"><span class="text-muted">Count</span><span>${n?.count ?? '—'}</span></div>
        <div class="d-flex justify-content-between"><span class="text-muted">Mean</span><span>${n?.mean ?? '—'}</span></div>
        <div class="d-flex justify-content-between"><span class="text-muted">Std</span><span>${n?.std ?? '—'}</span></div>
        <div class="d-flex justify-content-between"><span class="text-muted">Min</span><span>${n?.min ?? '—'}</span></div>
        <div class="d-flex justify-content-between"><span class="text-muted">Median</span><span>${n?.median ?? '—'}</span></div>
        <div class="d-flex justify-content-between"><span class="text-muted">Max</span><span>${n?.max ?? '—'}</span></div>
      </div>
    `;
    renderDetails(html);

    destroyCharts();

    const cfg = {
      type: 'bar',
      data: {
        labels: hist.labels,
        datasets: [{ label: 'Histogram', data: hist.counts }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { x: { display: false }, y: { display: false } }
      }
    };

    chart = new Chart(insightsChart, cfg);
    chart2 = new Chart(insightsChart2, cfg);

    // set dynamic title for PDF capture
    insightsChart.setAttribute('data-report-chart-title', 'Explore: ' + activeCol + ' (Histogram)');
  }

  function renderCategorical(data) {
    const c = data.categorical || {unique:0, top:[], other:{count:0,pct:0}};
    const labels = c.top.map(x => x.label).concat(c.other.count > 0 ? ['Other'] : []);
    const counts = c.top.map(x => x.count).concat(c.other.count > 0 ? [c.other.count] : []);

    const rows = c.top.map(x => `
      <div class="mb-1">
        <div class="d-flex justify-content-between small">
          <span class="text-truncate" style="max-width: 160px;">${escapeHtml(x.label)}</span>
          <span class="text-muted">${x.pct.toFixed(2)}%</span>
        </div>
        <div class="progress" style="height: 8px;">
          <div class="progress-bar" style="width:${x.pct}%;"></div>
        </div>
      </div>
    `).join('');

    const html = `
      <div class="small">
        <div class="fw-semibold mb-1">Top values</div>
        <div class="text-muted mb-2">Unique: ${c.unique}</div>
        ${rows || '<div class="text-muted">No values.</div>'}
      </div>
    `;
    renderDetails(html);

    destroyCharts();

    const cfg = {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [{ label: 'Counts', data: counts }]
      },
      options: { responsive: true, plugins: { legend: { display: true, position: 'bottom' } } }
    };

    chart = new Chart(insightsChart, cfg);
    chart2 = new Chart(insightsChart2, cfg);

    insightsChart.setAttribute('data-report-chart-title', 'Explore: ' + activeCol + ' (Top values)');
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (m) => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
    }[m]));
  }

  async function loadProfile(col) {
    activeCol = col;
    setColName(col);

    renderDetails('<div class="text-muted small">Loading…</div>');
    setType('—');
    renderMissing(0, 0, 0);

    const url = `?r=api/column_profile&col=${encodeURIComponent(col)}&max_rows=${maxRows}&bins=18&top=8`;
    const res = await fetch(url);
    const json = await res.json();

    if (!json.ok) {
      renderDetails(`<div class="text-danger small">${escapeHtml(json.error || 'Failed')}</div>`);
      return;
    }

    const data = json.data;
    setType(data.type);
    renderMissing(data.missing_pct, data.total, data.missing);

    if (data.type === 'numeric') renderNumeric(data);
    else renderCategorical(data);
  }

  // click header -> load insights
  document.querySelectorAll('.kaggle-th').forEach(th => {
    th.addEventListener('click', () => {
      clearHeaderActive();
      th.classList.add('active');
      loadProfile(th.getAttribute('data-col'));
    });
  });

  // Quick client-side filter (this page only)
  const filterInput = document.getElementById('colFilterInput');
  const clearBtn = document.getElementById('btnClearClientFilter');
  const table = document.getElementById('exploreTable');

  function applyClientFilter() {
    const q = (filterInput.value || '').toLowerCase();
    if (!activeCol || !table) return;

    const headers = Array.from(table.querySelectorAll('thead th'));
    const colIndex = headers.findIndex(h => h.getAttribute('data-col') === activeCol);
    if (colIndex < 0) return;

    table.querySelectorAll('tbody tr').forEach(tr => {
      const td = tr.children[colIndex];
      const txt = (td?.textContent || '').toLowerCase();
      tr.style.display = (q === '' || txt.includes(q)) ? '' : 'none';
    });
  }

  filterInput?.addEventListener('input', applyClientFilter);
  clearBtn?.addEventListener('click', () => {
    filterInput.value = '';
    if (!table) return;
    table.querySelectorAll('tbody tr').forEach(tr => tr.style.display = '');
  });
})();
</script>
