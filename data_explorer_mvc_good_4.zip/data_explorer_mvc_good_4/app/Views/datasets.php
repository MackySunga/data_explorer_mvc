<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h4 mb-0">Datasets</h1>
  <a class="btn btn-sm btn-primary" href="?r=dataset/upload">Upload new</a>
</div>

<?php if (empty($datasets)): ?>
  <div class="alert alert-info">No datasets uploaded yet.</div>
<?php else: ?>
  <div class="table-responsive">
    <table class="table table-sm align-middle">
      <thead>
        <tr>
          <th>Name</th>
          <th>Created</th>
          <th>Active</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($datasets as $id => $d): ?>
        <tr>
          <td class="fw-semibold"><?= e($d['name']) ?></td>
          <td class="text-muted small"><?= e($d['created_at']) ?></td>
          <td>
            <?php if (($active ?? '') === $id): ?>
              <span class="badge text-bg-success">Active</span>
            <?php else: ?>
              <span class="badge text-bg-secondary">—</span>
            <?php endif; ?>
          </td>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-primary" href="?r=dataset/list&set=<?= e($id) ?>">Set Active</a>
            <a class="btn btn-sm btn-outline-secondary" href="?r=dataset/download&id=<?= e($id) ?>">Download</a>
            <a class="btn btn-sm btn-outline-danger"
               onclick="return confirm('Delete this dataset?')"
               href="?r=dataset/delete&id=<?= e($id) ?>">Delete</a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>
