<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\DatasetStore;
use App\Services\StatsService;
use App\Services\CsvReader;

final class ApiController
{
    private DatasetStore $store;
    private StatsService $stats;
    private CsvReader $csv;

    public function __construct() {
        $this->store = new DatasetStore();
        $this->stats = new StatsService();
        $this->csv   = new CsvReader();
    }

    private function activeMeta(): ?array {
        $id = $this->store->activeId();
        return $id ? $this->store->get($id) : null;
    }

    public function histogram(): void {
        $meta = $this->activeMeta();
        if (!$meta) json_out(['ok' => false, 'error' => 'No active dataset'], 400);

        $col = (string)($_GET['col'] ?? '');
        $bins = max(5, min(50, (int)($_GET['bins'] ?? 12)));
        $maxRows = min(200000, max(1000, (int)($_GET['max_rows'] ?? 50000)));

        json_out($this->stats->histogram((string)$meta['csv_path'], $col, $bins, $maxRows));
    }

    public function valueCounts(): void {
        $meta = $this->activeMeta();
        if (!$meta) json_out(['ok' => false, 'error' => 'No active dataset'], 400);

        $col = (string)($_GET['col'] ?? '');
        $top = max(5, min(50, (int)($_GET['top'] ?? 15)));
        $maxRows = min(200000, max(1000, (int)($_GET['max_rows'] ?? 50000)));

        json_out($this->stats->valueCounts((string)$meta['csv_path'], $col, $top, $maxRows));
    }

    public function scatter(): void {
        $meta = $this->activeMeta();
        if (!$meta) json_out(['ok' => false, 'error' => 'No active dataset'], 400);

        $x = (string)($_GET['x'] ?? '');
        $y = (string)($_GET['y'] ?? '');
        $maxRows = min(200000, max(1000, (int)($_GET['max_rows'] ?? 50000)));

        json_out($this->stats->scatter((string)$meta['csv_path'], $x, $y, 2000, $maxRows));
    }

    /**
     * Kaggle-like quick column profile
     * Route: ?r=api/col_profile&col=COLNAME&max_rows=20000&bins=12&top=10
     * Returns: { ok, col, type, missing_pct, unique, min/median/max (if numeric), chart (Chart.js config) }
     */
    public function colProfile(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) json_out(['ok' => false, 'error' => 'Select a dataset first.'], 400);

        $col = trim((string)($_GET['col'] ?? ''));
        if ($col === '') json_out(['ok' => false, 'error' => 'Missing col parameter.'], 400);

        $maxRows = min(200000, max(1000, (int)($_GET['max_rows'] ?? 20000)));
        $bins    = min(30, max(5, (int)($_GET['bins'] ?? 12)));
        $topN    = min(20, max(5, (int)($_GET['top'] ?? 10)));

        $csvPath = (string)($meta['csv_path'] ?? '');
        if ($csvPath === '' || !is_file($csvPath)) {
            json_out(['ok' => false, 'error' => 'CSV file not found on disk.'], 404);
        }

        // Determine type using your StatsService (consistent with your app)
        $summary = $this->stats->summary($csvPath, $maxRows);
        $types   = is_array($summary['types'] ?? null) ? $summary['types'] : [];
        $type    = (string)($types[$col] ?? '');

        // Scan ONLY this column (fast)
        $missing = 0;
        $total   = 0;

        $unique = [];
        $uniqueCap = 50000;
        $uniqueCapped = false;

        $nums = [];
        $cats = [];

        foreach ($this->csv->iterate($csvPath, 0, 0) as $row) {
            if ($total >= $maxRows) break;
            $total++;

            $v = isset($row[$col]) ? trim((string)$row[$col]) : '';
            if ($v === '') {
                $missing++;
                continue;
            }

            if (!$uniqueCapped) {
                $unique[$v] = 1;
                if (count($unique) >= $uniqueCap) $uniqueCapped = true;
            }

            // If type not known, infer lightly
            $isNum = ($type === 'numeric') || ($type === '' && is_numeric($v));

            if ($isNum && is_numeric($v)) {
                $nums[] = (float)$v;
            } else {
                $cats[$v] = ($cats[$v] ?? 0) + 1;
            }
        }

        $used = $total;
        $missingPct = $used > 0 ? ($missing / $used) * 100.0 : 0.0;
        $uniqueCount = $uniqueCapped ? $uniqueCap : count($unique);

        // Decide final type based on what we actually captured
        $finalType = (!empty($nums) && empty($cats)) ? 'numeric' : (($type !== '') ? $type : 'categorical');

        $resp = [
            'ok' => true,
            'col' => $col,
            'type' => $finalType,
            'total' => $used,
            'missing' => $missing,
            'missing_pct' => round($missingPct, 2),
            'unique' => $uniqueCount,
            'unique_capped' => $uniqueCapped,
        ];

        // Build chart config
        if ($finalType === 'numeric' && !empty($nums)) {
            sort($nums);
            $n = count($nums);

            $min = $nums[0];
            $max = $nums[$n - 1];
            $median = $nums[(int)floor(($n - 1) / 2)];

            $resp['min'] = $this->fmtNum($min);
            $resp['median'] = $this->fmtNum($median);
            $resp['max'] = $this->fmtNum($max);

            $labels = [];
            $counts = array_fill(0, $bins, 0);

            if ($min === $max) {
                $labels = [$this->fmtNum($min)];
                $counts = [$n];
            } else {
                $w = ($max - $min) / $bins;

                for ($i = 0; $i < $bins; $i++) {
                    $a = $min + $i * $w;
                    $b = $min + ($i + 1) * $w;
                    $labels[] = $this->fmtNum($a) . '–' . $this->fmtNum($b);
                }

                foreach ($nums as $x) {
                    $idx = (int)floor(($x - $min) / $w);
                    if ($idx >= $bins) $idx = $bins - 1;
                    if ($idx < 0) $idx = 0;
                    $counts[$idx]++;
                }
            }

            $resp['chart'] = [
                'type' => 'bar',
                'data' => [
                    'labels' => $labels,
                    'datasets' => [[
                        'label' => 'Histogram',
                        'data' => $counts,
                    ]],
                ],
                'options' => [
                    'responsive' => true,
                    'plugins' => [
                        'legend' => ['display' => false],
                        'tooltip' => ['enabled' => true],
                    ],
                    'scales' => [
                        'x' => ['ticks' => ['maxRotation' => 0, 'autoSkip' => true]],
                        'y' => ['beginAtZero' => true],
                    ],
                ],
            ];
        } else {
            // Categorical: top-N + Others
            arsort($cats);
            $labels = [];
            $counts = [];
            $i = 0;
            $others = 0;

            foreach ($cats as $k => $v) {
                $i++;
                if ($i <= $topN) {
                    $labels[] = (string)$k;
                    $counts[] = (int)$v;
                } else {
                    $others += (int)$v;
                }
            }
            if ($others > 0) {
                $labels[] = 'Others';
                $counts[] = $others;
            }

            $resp['chart'] = [
                'type' => 'bar',
                'data' => [
                    'labels' => $labels,
                    'datasets' => [[
                        'label' => 'Top values',
                        'data' => $counts,
                    ]],
                ],
                'options' => [
                    'responsive' => true,
                    'plugins' => [
                        'legend' => ['display' => false],
                        'tooltip' => ['enabled' => true],
                    ],
                    'scales' => [
                        'x' => ['ticks' => ['autoSkip' => true]],
                        'y' => ['beginAtZero' => true],
                    ],
                ],
            ];
        }

        json_out($resp);
    }

    private function fmtNum(float $x): string
    {
        return sprintf('%.5g', $x);
    }
}
