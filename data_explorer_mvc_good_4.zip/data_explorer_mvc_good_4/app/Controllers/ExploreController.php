<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\DatasetStore;
use App\Services\CsvReader;
use App\Services\FilterEngine;
use App\Services\StatsService;
use App\Services\InsightService;
use App\Services\PdfReportService;
use App\Services\ReportFormatService;

use App\Services\RegressionService;

use App\Services\ChartDataService;
use App\Services\Explore\DatasetPathResolver;
use App\Services\Explore\ChartDataEndpoint;
use App\Services\Explore\ColumnProfiler;
use App\Services\Explore\ColumnProfileEndpoint;

use App\Services\Explore\ReportWorkflow;
use App\Services\Explore\ReportFileStore;
use App\Services\Explore\ChartStorage;
use App\Services\Explore\RegressionWorkflow;

final class ExploreController
{
    private DatasetStore $store;
    private CsvReader $csv;
    private FilterEngine $filter;
    private StatsService $stats;
    private InsightService $insight;

    private ReportWorkflow $reports;
    private RegressionWorkflow $regFlow;

    private DatasetPathResolver $pathResolver;
    private ChartDataEndpoint $chartEndpoint;
    private ColumnProfileEndpoint $columnEndpoint;

    public function __construct()
    {
        $this->store  = new DatasetStore();
        $this->csv    = new CsvReader();
        $this->filter = new FilterEngine();
        $this->stats  = new StatsService();
        $this->insight= new InsightService();

        $this->pathResolver = new DatasetPathResolver();
        $this->chartEndpoint = new ChartDataEndpoint($this->pathResolver, new ChartDataService());
        $this->columnEndpoint = new ColumnProfileEndpoint($this->pathResolver, new ColumnProfiler());

        $this->reports = new ReportWorkflow(
            $this->stats,
            $this->insight,
            new PdfReportService(),
            new ReportFormatService(),
            new ReportFileStore(),
            new ChartStorage()
        );

        $this->regFlow = new RegressionWorkflow($this->stats, $this->csv);
    }

    private function activeMeta(): ?array
    {
        $id = $this->store->activeId();
        return $id ? $this->store->get($id) : null;
    }

    private function json(array $data, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_SLASHES);
        exit;
    }

    private function sanitizeRegressionExtra(array $reg): array
    {
        $out = [];
        $out['y'] = (string)($reg['y'] ?? '');
        $out['x'] = array_values(array_map('strval', is_array($reg['x'] ?? null) ? $reg['x'] : []));
        $out['regression_stats'] = is_array($reg['regression_stats'] ?? null) ? $reg['regression_stats'] : [];
        $out['anova'] = is_array($reg['anova'] ?? null) ? $reg['anova'] : [];
        $out['coefficients'] = is_array($reg['coefficients'] ?? null) ? $reg['coefficients'] : [];
        $out['note'] = (string)($reg['note'] ?? '');
        return $out;
    }

    /* =========================
       TABLE (left as-is for now)
       ========================= */

    public function table(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) {
            flash_set('warning', 'Upload or select a dataset first.');
            redirect('dataset/upload');
        }

        $csvPath = (string)$meta['csv_path'];
        $columns = $this->csv->readHeader($csvPath);

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = min(100, max(10, (int)($_GET['per_page'] ?? 25)));
        $q = trim((string)($_GET['q'] ?? ''));

        $selected = $_GET['cols'] ?? [];
        if (!is_array($selected) || empty($selected)) $selected = $columns;
        $selected = array_values(array_intersect($selected, $columns));
        if (empty($selected)) $selected = $columns;

        $sort = (string)($_GET['sort'] ?? '');
        $dir  = strtolower((string)($_GET['dir'] ?? 'asc'));
        if ($dir !== 'asc' && $dir !== 'desc') $dir = 'asc';
        if (!in_array($sort, $selected, true)) $sort = '';

        $profileRows = min(50000, max(1000, (int)($_GET['profile_rows'] ?? 20000)));

        $summary = $this->stats->summary($csvPath, $profileRows);
        $types   = is_array($summary['types'] ?? null) ? $summary['types'] : [];
        $stats   = is_array($summary['stats'] ?? null) ? $summary['stats'] : [];

        $colInfo = [];
        foreach ($selected as $c) {
            $s = is_array($stats[$c] ?? null) ? $stats[$c] : [];
            $count = (int)($s['count'] ?? 0);
            $missing = (int)($s['missing'] ?? 0);
            $missingPct = $count > 0 ? ($missing / $count) * 100.0 : 0.0;

            $colInfo[$c] = [
                'type' => (string)($types[$c] ?? 'categorical'),
                'missing_pct' => $missingPct,
                'unique' => (int)($s['unique'] ?? 0),
            ];
        }

        $f_op = $_GET['f_op'] ?? [];
        $f_v1 = $_GET['f_v1'] ?? [];
        $f_v2 = $_GET['f_v2'] ?? [];
        if (!is_array($f_op)) $f_op = [];
        if (!is_array($f_v1)) $f_v1 = [];
        if (!is_array($f_v2)) $f_v2 = [];

        $matchColFilter = function(array $row, string $col, string $type, string $op, string $v1, string $v2): bool {
            $raw = isset($row[$col]) ? trim((string)$row[$col]) : '';
            $isBlank = ($raw === '');

            if ($op === 'is_blank') return $isBlank;
            if ($op === 'not_blank') return !$isBlank;
            if ($isBlank) return false;

            if ($type === 'numeric') {
                if (!is_numeric($raw)) return false;
                $x = (float)$raw;

                $v1t = trim($v1);
                $v2t = trim($v2);

                if ($op === 'between') {
                    if ($v1t === '' && $v2t === '') return true;
                    if ($v1t !== '' && !is_numeric($v1t)) return false;
                    if ($v2t !== '' && !is_numeric($v2t)) return false;

                    $min = ($v1t === '') ? -INF : (float)$v1t;
                    $max = ($v2t === '') ?  INF : (float)$v2t;
                    return ($x >= $min && $x <= $max);
                }

                if ($v1t === '' || !is_numeric($v1t)) return false;
                $a = (float)$v1t;

                return match ($op) {
                    'gte' => $x >= $a,
                    'lte' => $x <= $a,
                    'eq'  => $x == $a,
                    'ne'  => $x != $a,
                    default => true,
                };
            }

            $hay = mb_strtolower($raw);
            $needle = mb_strtolower(trim($v1));

            if ($needle === '' && in_array($op, ['equals','not_equals','contains','starts_with','ends_with'], true)) {
                return false;
            }

            return match ($op) {
                'equals'      => $hay === $needle,
                'not_equals'  => $hay !== $needle,
                'contains'    => mb_stripos($hay, $needle) !== false,
                'starts_with' => str_starts_with($hay, $needle),
                'ends_with'   => str_ends_with($hay, $needle),
                default       => true,
            };
        };

        $start = ($page - 1) * $perPage;
        $end = $start + $perPage;

        $rows = [];
        $matched = 0;

        foreach ($this->csv->iterate($csvPath, 0, 0) as $row) {
            if (!$this->filter->match($row, $q, [])) continue;

            $ok = true;
            foreach ($f_op as $col => $op) {
                $col = (string)$col;
                $op  = trim((string)$op);
                if ($op === '') continue;
                if (!in_array($col, $columns, true)) continue;

                $type = (string)($types[$col] ?? 'categorical');
                $v1 = (string)($f_v1[$col] ?? '');
                $v2 = (string)($f_v2[$col] ?? '');

                if (!$matchColFilter($row, $col, $type, $op, $v1, $v2)) { $ok = false; break; }
            }
            if (!$ok) continue;

            if ($matched >= $start && $matched < $end) {
                $rows[] = array_intersect_key($row, array_flip($selected));
            }
            $matched++;
        }

        if ($sort !== '') {
            usort($rows, function(array $a, array $b) use ($sort, $dir): int {
                $va = (string)($a[$sort] ?? '');
                $vb = (string)($b[$sort] ?? '');

                $ea = trim($va) === '';
                $eb = trim($vb) === '';
                if ($ea && $eb) return 0;
                if ($ea) return 1;
                if ($eb) return -1;

                if (is_numeric($va) && is_numeric($vb)) $cmp = ((float)$va <=> (float)$vb);
                else $cmp = strnatcasecmp($va, $vb);

                return ($dir === 'desc') ? -$cmp : $cmp;
            });
        }

        $totalMatched = $matched;
        $totalPages = max(1, (int)ceil($totalMatched / $perPage));

        render('explore', [
            'meta' => $meta,
            'columns' => $columns,
            'selected' => $selected,
            'rows' => $rows,
            'page' => $page,
            'perPage' => $perPage,
            'totalMatched' => $totalMatched,
            'totalPages' => $totalPages,
            'q' => $q,
            'sort' => $sort,
            'dir' => $dir,
            'types' => $types,
            'colInfo' => $colInfo,
            'statsSampleRows' => $profileRows,
            'f_op' => $f_op,
            'f_v1' => $f_v1,
            'f_v2' => $f_v2,
        ]);
    }

    /* =========================
       STATS PAGES (now use workflow builder/formatter)
       ========================= */

    public function stats(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { flash_set('warning', 'Select a dataset first.'); redirect('dataset/upload'); }

        $maxRows = $this->reports->clampMaxRows($_GET['max_rows'] ?? 50000);
        $payload = $this->reports->build($meta, $maxRows);
        $fmt = $this->reports->normalize($payload);

        render('stats', ['meta' => $meta, 'maxRows' => $maxRows, 'fmt' => $fmt]);
    }

    public function correlation(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { flash_set('warning', 'Select a dataset first.'); redirect('dataset/upload'); }

        $maxRows = $this->reports->clampMaxRows($_GET['max_rows'] ?? 50000);
        $payload = $this->reports->build($meta, $maxRows);
        $fmt = $this->reports->normalize($payload);

        render('correlation', ['meta' => $meta, 'maxRows' => $maxRows, 'fmt' => $fmt]);
    }

    public function missing(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { flash_set('warning', 'Select a dataset first.'); redirect('dataset/upload'); }

        $maxRows = $this->reports->clampMaxRows($_GET['max_rows'] ?? 50000);
        $payload = $this->reports->build($meta, $maxRows);
        $fmt = $this->reports->normalize($payload);

        render('missing', ['meta' => $meta, 'maxRows' => $maxRows, 'fmt' => $fmt]);
    }

    public function outliers(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { flash_set('warning', 'Select a dataset first.'); redirect('dataset/upload'); }

        $maxRows = $this->reports->clampMaxRows($_GET['max_rows'] ?? 50000);
        $payload = $this->reports->build($meta, $maxRows);
        $fmt = $this->reports->normalize($payload);

        render('outliers', ['meta' => $meta, 'maxRows' => $maxRows, 'fmt' => $fmt]);
    }

    public function visualize(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { flash_set('warning', 'Upload or select a dataset first.'); redirect('dataset/upload'); }

        $maxRows = $this->reports->clampMaxRows($_GET['max_rows'] ?? 50000);
        $summary = $this->stats->summary((string)$meta['csv_path'], $maxRows);

        render('visualize', ['meta' => $meta, 'summary' => $summary, 'maxRows' => $maxRows]);
    }

    /* =========================
       REPORTS (moved to workflow)
       ========================= */

    public function reports(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { flash_set('warning', 'Select a dataset first.'); redirect('dataset/upload'); }

        $files = $this->reports->listFiles($meta);
        render('reports', ['meta' => $meta, 'files' => $files]);
    }

    public function reportSave(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { flash_set('warning', 'Select a dataset first.'); redirect('dataset/upload'); }
        if (request_method() !== 'POST') redirect('explore/reports');

        $maxRows = $this->reports->clampMaxRows($_POST['max_rows'] ?? 50000);

        try {
            $file = $this->reports->saveNew($meta, $maxRows);
        } catch (\Throwable $e) {
            flash_set('danger', $e->getMessage());
            redirect('explore/reports');
        }

        flash_set('success', 'Report saved: ' . $file);
        redirect('explore/reports');
    }

    public function reportView(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { flash_set('warning', 'Select a dataset first.'); redirect('dataset/upload'); }

        $file = (string)($_GET['file'] ?? '');

        try {
            $json = $this->reports->load($meta, $file);
        } catch (\Throwable $e) {
            flash_set('danger', $e->getMessage());
            redirect('explore/reports');
        }

        $fmt = $this->reports->normalize($json);

        render('report_view', [
            'meta' => $meta,
            'file' => preg_replace('/[^a-zA-Z0-9_.-]/', '', $file) ?? '',
            'report' => $json,
            'fmt' => $fmt,
        ]);
    }

    public function reportDownload(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { http_response_code(400); echo "No active dataset."; return; }

        $file = (string)($_GET['file'] ?? '');

        try {
            $path = $this->reports->absolutePath($meta, $file);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo $e->getMessage();
            return;
        }

        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . basename($path) . '"');
        readfile($path);
    }

    public function reportDelete(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) {
            flash_set('warning', 'Select a dataset first.');
            redirect('dataset/upload');
        }

        if (request_method() !== 'POST') {
            redirect('explore/reports');
        }

        $file = (string)($_POST['file'] ?? '');
        $file = preg_replace('/[^a-zA-Z0-9_.-]/', '', $file) ?? '';

        if ($file === '' || !str_starts_with($file, (string)$meta['id'] . '_')) {
            flash_set('danger', 'Invalid report file.');
            redirect('explore/reports');
        }

        $path = REPORTS_PATH . '/' . $file;
        if (!is_file($path)) {
            flash_set('danger', 'Report not found.');
            redirect('explore/reports');
        }

        $payload = json_decode((string)@file_get_contents($path), true);
        $chartPaths = [];
        if (is_array($payload) && is_array($payload['charts'] ?? null)) {
            foreach ($payload['charts'] as $ch) {
                if (!is_array($ch)) continue;
                $rel = (string)($ch['path'] ?? '');
                if (str_starts_with($rel, 'charts/')) $chartPaths[] = $rel;
            }
        }

        $ok = @unlink($path);
        if (!$ok) {
            flash_set('danger', 'Failed to delete report file. Check file permissions.');
            redirect('explore/reports');
        }

        $this->cleanupOrphanCharts((string)$meta['id'], $chartPaths, $file);

        flash_set('success', 'Deleted report: ' . $file);
        redirect('explore/reports');
    }

    private function cleanupOrphanCharts(string $datasetId, array $chartPaths, string $deletedReportFile): void
    {
        if (empty($chartPaths)) return;

        $others = glob(REPORTS_PATH . "/{$datasetId}_*.json") ?: [];
        $others = array_filter($others, fn($p) => basename((string)$p) !== $deletedReportFile);

        foreach ($chartPaths as $rel) {
            $rel = (string)$rel;
            if (!str_starts_with($rel, 'charts/')) continue;

            $stillUsed = false;
            foreach ($others as $p) {
                $txt = @file_get_contents((string)$p);
                if ($txt !== false && str_contains($txt, $rel)) {
                    $stillUsed = true;
                    break;
                }
            }
            if ($stillUsed) continue;

            $img = substr($rel, strlen('charts/'));
            $img = preg_replace('/[^a-zA-Z0-9_.-]/', '', $img) ?? '';
            if ($img === '') continue;

            if (!str_starts_with($img, $datasetId . '_')) continue;

            $abs = REPORTS_PATH . '/charts/' . $img;
            if (is_file($abs)) @unlink($abs);
        }
    }

    public function reportPdf(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { flash_set('warning', 'Select a dataset first.'); redirect('dataset/upload'); }

        $file = (string)($_GET['file'] ?? '');
        $file = preg_replace('/[^a-zA-Z0-9_.-]/', '', $file) ?? '';

        if ($file !== '') {
            try {
                $payload = $this->reports->loadAndRepair($meta, $file);
            } catch (\Throwable $e) {
                flash_set('danger', $e->getMessage());
                redirect('explore/reports');
            }
            $downloadName = 'report_' . $meta['id'] . '.pdf';
        } else {
            $maxRows = $this->reports->clampMaxRows($_GET['max_rows'] ?? 50000);
            $payload = $this->reports->build($meta, $maxRows);
            $downloadName = 'report_live_' . $meta['id'] . '.pdf';
        }

        $this->reports->streamPdf($meta, $payload, $downloadName);
    }

    public function reportSaveAjax(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) $this->json(['ok' => false, 'error' => 'Select a dataset first.'], 400);

        $maxRows = $this->reports->clampMaxRows($_GET['max_rows'] ?? 50000);

        try {
            $file = $this->reports->saveNew($meta, $maxRows);
        } catch (\Throwable $e) {
            $this->json(['ok' => false, 'error' => $e->getMessage()], 500);
        }

        $this->json(['ok' => true, 'file' => $file]);
    }

    public function reportAttachCharts(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) {
            $this->json(['ok' => false, 'error' => 'No active dataset.']);
            return;
        }

        $body = json_decode((string)file_get_contents('php://input'), true);
        if (!is_array($body)) {
            $this->json(['ok' => false, 'error' => 'Invalid JSON body.']);
            return;
        }

        $file = preg_replace('/[^a-zA-Z0-9_.-]/', '', (string)($body['file'] ?? '')) ?? '';
        if ($file === '' || !str_starts_with($file, (string)$meta['id'] . '_')) {
            $this->json(['ok' => false, 'error' => 'Invalid report file.']);
            return;
        }

        $path = REPORTS_PATH . '/' . $file;
        if (!is_file($path)) {
            $this->json(['ok' => false, 'error' => 'Report file not found.']);
            return;
        }

        $payload = json_decode((string)file_get_contents($path), true);
        if (!is_array($payload)) {
            $this->json(['ok' => false, 'error' => 'Report file is corrupted.']);
            return;
        }

        $chartsDir = REPORTS_PATH . '/charts';
        if (!is_dir($chartsDir)) {
            @mkdir($chartsDir, 0777, true);
        }

        $charts = $body['charts'] ?? [];
        $saved = [];

        if (is_array($charts)) {
            foreach ($charts as $i => $ch) {
                if (!is_array($ch)) continue;

                $title = (string)($ch['title'] ?? ('Chart ' . ($i + 1)));
                $dataUrl = (string)($ch['dataUrl'] ?? '');

                if (!str_starts_with($dataUrl, 'data:image/png;base64,')) continue;

                $b64 = substr($dataUrl, strlen('data:image/png;base64,'));
                $bin = base64_decode($b64, true);
                if ($bin === false) continue;

                $fn = (string)$meta['id'] . '_' . date('Ymd_His') . '_' . $i . '.png';
                $full = $chartsDir . '/' . $fn;

                if (@file_put_contents($full, $bin) !== false) {
                    $saved[] = ['title' => $title, 'path' => 'charts/' . $fn];
                }
            }
        }

        $payload['charts'] = $saved;

        $reg = $body['regression'] ?? null;
        if (is_array($reg)) {
            $payload['regression'] = $this->sanitizeRegressionExtra($reg);
        }

        $hasTables =
            isset($payload['summary']) &&
            isset($payload['missing']) &&
            isset($payload['outliers']) &&
            isset($payload['correlation']);

        if (!$hasTables) {
            $savedCharts = (is_array($payload['charts'] ?? null)) ? $payload['charts'] : [];
            $savedReg    = (is_array($payload['regression'] ?? null)) ? $payload['regression'] : null;

            $maxRows = (int)($payload['max_rows'] ?? 50000);
            $maxRows = min(200000, max(1000, $maxRows ?: 50000));

            $payload = $this->reports->build($meta, $maxRows);

            if (!empty($savedCharts)) $payload['charts'] = $savedCharts;
            if (is_array($savedReg))  $payload['regression'] = $savedReg;
        }

        file_put_contents($path, json_encode($payload, JSON_PRETTY_PRINT));

        $this->json(['ok' => true, 'charts_saved' => count($saved), 'regression_attached' => is_array($reg)]);
    }

    public function reportAttachRegression(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) $this->json(['ok' => false, 'error' => 'Select a dataset first.'], 400);

        $raw = (string)file_get_contents('php://input');
        $body = json_decode($raw, true);
        if (!is_array($body)) $this->json(['ok' => false, 'error' => 'Invalid JSON body.'], 400);

        $file = preg_replace('/[^a-zA-Z0-9_.-]/', '', (string)($body['file'] ?? '')) ?? '';
        if ($file === '') $this->json(['ok' => false, 'error' => 'Missing file.'], 400);

        $reg = $body['regression'] ?? null;
        if (!is_array($reg) || empty($reg)) $this->json(['ok' => false, 'error' => 'Missing regression payload.'], 400);

        try {
            $payload = $this->reports->loadAndRepair($meta, $file);
            $payload['regression'] = $reg;
            $this->reports->overwrite($meta, $file, $payload);
        } catch (\Throwable $e) {
            $this->json(['ok' => false, 'error' => $e->getMessage()], 400);
        }

        $this->json(['ok' => true, 'file' => $file]);
    }

    public function reportChart(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { http_response_code(404); exit('No active dataset.'); }

        $img  = preg_replace('/[^a-zA-Z0-9_.-]/', '', (string)($_GET['img'] ?? '')) ?? '';
        if ($img === '') { http_response_code(400); exit('Bad request.'); }

        $this->reports->chartStorage()->stream($img);
    }

    /* =========================
       REGRESSION (moved to workflow)
       ========================= */

    public function regression(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { flash_set('warning', 'Upload or select a dataset first.'); redirect('dataset/upload'); }

        $maxRows    = $this->regFlow->clampMaxRows($_REQUEST['max_rows'] ?? 50000);
        $diagPoints = $this->regFlow->clampDiagPoints($_REQUEST['diag_points'] ?? 2000);

        $csvPath = (string)($meta['csv_path'] ?? '');
        if ($csvPath === '' || !is_file($csvPath)) {
            flash_set('danger', 'CSV not found on disk.');
            redirect('dataset/list');
        }

        $numericCols = $this->regFlow->numericColumns($csvPath, $maxRows);

        $y = (string)($_REQUEST['y'] ?? '');
        $x = $_REQUEST['x'] ?? [];
        if (!is_array($x)) $x = [];

        [$y, $x] = $this->regFlow->normalizeSelection($y, $x, $numericCols);

        $result = null;
        $error  = '';

        if (request_method() === 'POST') {
            if ($y === '' || empty($x)) {
                $error = 'Select a Dependent (Y) and one or more Independent (X).';
            } else {
                try {
                    $result = $this->regFlow->runOls($csvPath, $y, $x, $maxRows, $diagPoints);
                } catch (\Throwable $e) {
                    $error = $e->getMessage();
                }
            }
        }

        render('regression', [
            'meta' => $meta,
            'numericCols' => $numericCols,
            'y' => $y,
            'x' => $x,
            'maxRows' => $maxRows,
            'diagPoints' => $diagPoints,
            'result' => $result,
            'error' => $error,
        ]);
    }

    public function regressionSave(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) { flash_set('warning', 'Select a dataset first.'); redirect('dataset/upload'); }
        if (request_method() !== 'POST') redirect('explore/regression');

        $maxRows = $this->regFlow->clampMaxRows($_POST['max_rows'] ?? 50000);
        $diagPts = $this->regFlow->clampDiagPoints($_POST['diag_pts'] ?? 2000);

        $y = (string)($_POST['y'] ?? '');
        $x = $_POST['x'] ?? [];
        if (!is_array($x)) $x = [];

        $payload = $this->reports->build($meta, $maxRows);

        try {
            $payload['regression'] = $this->regFlow->fitOlsForReport((string)$meta['csv_path'], trim($y), $x, $maxRows, $diagPts);
            $file = $this->reports->savePayload($meta, $payload);
        } catch (\Throwable $e) {
            flash_set('danger', 'Regression save failed: ' . $e->getMessage());
            redirect('explore/regression&max_rows=' . $maxRows);
        }

        flash_set('success', 'Regression report saved: ' . $file);
        redirect('explore/reports');
    }

    public function chartData(): void
    {
        if (request_method() !== 'POST') $this->json(['ok' => false, 'error' => 'POST required.'], 405);

        $meta = $this->activeMeta();
        if (!$meta) $this->json(['ok' => false, 'error' => 'Select a dataset first.'], 400);

        $raw = (string)file_get_contents('php://input');
        $debug = isset($_GET['debug']) && (string)$_GET['debug'] === '1';

        try {
            $out = $this->chartEndpoint->handle($meta, $raw, $debug);
            $this->json($out);
        } catch (\Throwable $e) {
            $this->json(['ok' => false, 'error' => $e->getMessage()], 400);
        }
    }

    public function columnProfile(): void
    {
        $meta = $this->activeMeta();
        if (!$meta) $this->json(['ok' => false, 'error' => 'Select a dataset first.'], 400);

        $col = trim((string)($_GET['col'] ?? ''));
        if ($col === '') $this->json(['ok' => false, 'error' => 'Missing col.'], 400);

        $maxRows = min(200000, max(1000, (int)($_GET['max_rows'] ?? 50000)));
        $bins    = min(60, max(5, (int)($_GET['bins'] ?? 16)));
        $topN    = min(50, max(5, (int)($_GET['top'] ?? 12)));

        try {
            $out = $this->columnEndpoint->handle($meta, $col, $maxRows, $bins, $topN);
            $this->json($out);
        } catch (\Throwable $e) {
            $this->json(['ok' => false, 'error' => $e->getMessage()], 400);
        }
    }
}
