<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\DatasetStore;

final class DatasetController
{
    private DatasetStore $store;

    public function __construct() {
        $this->store = new DatasetStore();
    }

    public function upload(): void {
        if (request_method() !== 'POST') {
            render('upload', ['active' => $this->store->activeId()]);
            return;
        }

        if (empty($_FILES['csv'] ?? null)) {
            flash_set('danger', 'No file uploaded.');
            redirect('dataset/upload');
        }

        $f = $_FILES['csv'];

        $err = (int)($f['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err !== UPLOAD_ERR_OK) {
            $map = [
                UPLOAD_ERR_INI_SIZE   => 'File too large (upload_max_filesize).',
                UPLOAD_ERR_FORM_SIZE  => 'File too large (MAX_FILE_SIZE).',
                UPLOAD_ERR_PARTIAL    => 'Upload was partial.',
                UPLOAD_ERR_NO_FILE    => 'No file uploaded.',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing temp folder on server.',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
                UPLOAD_ERR_EXTENSION  => 'Upload blocked by a PHP extension.',
            ];
            flash_set('danger', 'Upload error: ' . ($map[$err] ?? ('Code ' . $err)));
            redirect('dataset/upload');
        }

        $tmp = (string)($f['tmp_name'] ?? '');
        if ($tmp === '' || !is_file($tmp)) {
            flash_set('danger', 'Upload temp file missing. Check upload_tmp_dir in php.ini and restart Apache.');
            redirect('dataset/upload');
        }

        $name = (string)($f['name'] ?? 'dataset.csv');
        if (!str_ends_with(strtolower($name), '.csv')) {
            flash_set('warning', 'File does not end with .csv, but I will still try to read it as CSV.');
        }

        try {
            $meta = $this->store->createFromUpload($name, $tmp);
            $this->store->setActive((string)$meta['id']);
            flash_set('success', 'Uploaded: ' . $meta['name']);
            redirect('explore/table');
        } catch (\Throwable $e) {
            flash_set('danger', 'Upload failed: ' . $e->getMessage());
            redirect('dataset/upload');
        }
    }

    public function list(): void {
        $datasets = $this->store->list();

        $set = (string)($_GET['set'] ?? '');
        if ($set !== '') {
            $this->store->setActive($set);
            flash_set('info', 'Active dataset set.');
            redirect('dataset/list');
        }

        render('datasets', [
            'datasets' => $datasets,
            'active' => $this->store->activeId(),
        ]);
    }

    public function delete(): void {
        $id = safe_id((string)($_GET['id'] ?? ''));
        if ($id === '') {
            flash_set('danger', 'Missing dataset id.');
            redirect('dataset/list');
        }
        $ok = $this->store->delete($id);
        flash_set($ok ? 'success' : 'danger', $ok ? 'Deleted dataset.' : 'Delete failed.');
        redirect('dataset/list');
    }

    public function download(): void {
        $id = safe_id((string)($_GET['id'] ?? ''));
        $meta = $this->store->get($id);
        if (!$meta) {
            http_response_code(404);
            echo "Dataset not found.";
            return;
        }
        $path = (string)$meta['csv_path'];
        if (!is_file($path)) {
            http_response_code(404);
            echo "CSV missing on disk.";
            return;
        }

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . basename($path) . '"');
        readfile($path);
    }
}
