<?php
declare(strict_types=1);

namespace App\ViewData;

final class Page
{
    public static function title(string $route, array $data = []): string
    {
        $dataset = self::datasetName($data);

        // base labels
        $label = match (true) {
            $route === 'dataset/upload' => 'Upload',
            $route === 'dataset/list'   => 'Datasets',

            $route === 'explore/table'       => 'Explore',
            $route === 'explore/stats'       => 'Stats',
            $route === 'explore/visualize'   => 'Visualize',
            $route === 'explore/correlation' => 'Correlation',
            $route === 'explore/missing'     => 'Missing Values',
            $route === 'explore/outliers'    => 'Outliers',
            $route === 'explore/reports'     => 'Reports',

            str_starts_with($route, 'explore/report') => 'Report',

            str_starts_with($route, 'api/') => 'API',

            default => 'Data Explorer',
        };

        // attach dataset name when relevant
        $needsDataset = str_starts_with($route, 'explore/') && $dataset !== '';
        if ($needsDataset) {
            return $label . ' — ' . $dataset;
        }

        return $label . ' — Data Explorer';
    }

    private static function datasetName(array $data): string
    {
        // typical explore pages pass $meta
        if (!empty($data['meta']['name'])) {
            return (string)$data['meta']['name'];
        }

        // report view might pass report payload
        if (!empty($data['report']['dataset']['name'])) {
            return (string)$data['report']['dataset']['name'];
        }

        // fallback keys if ever needed
        if (!empty($data['dataset']['name'])) {
            return (string)$data['dataset']['name'];
        }

        return '';
    }
}
