<?php
declare(strict_types=1);

namespace App\ViewData;

final class Nav
{
    public static function items(string $route): array
    {
        $groups = [
            [
                'label' => 'Data Preparation',
                'items' => [
                    self::item('Upload',   'dataset/upload'),
                    self::item('Datasets', 'dataset/list'),
                ],
            ],
            [
                'label' => 'Exploration',
                'items' => [
                    self::item('Explore',      'explore/table'),
                    self::item('Stats',        'explore/stats'),
                    self::item('Correlation',  'explore/correlation'),
                    self::item('Visualize',    'explore/visualize'),
                ],
            ],
            [
                'label' => 'Regression',
                'items' => [
                    self::item('Linear Regression (OLS)', 'explore/regression'),
                ],
            ],
            [
                'label' => 'Verify',
                'items' => [
                    self::item('Missing',  'explore/missing'),
                    self::item('Outliers', 'explore/outliers'),
                ],
            ],
            [
                'label' => 'Reports',
                'href'  => '?r=explore/reports',
                'match' => [
                    'routes'   => ['explore/reports'],
                    'prefixes' => ['explore/report'],
                ],
                'items' => [],
            ],
        ];

        foreach ($groups as &$g) {
            if (!empty($g['items'])) {
                $g['active'] = false;
                foreach ($g['items'] as &$it) {
                    $it['active'] = self::matches($route, $it['match']);
                    if ($it['active']) $g['active'] = true;
                }
                unset($it);
            } else {
                $g['active'] = isset($g['match']) ? self::matches($route, $g['match']) : false;
            }
        }
        unset($g);

        return $groups;
    }

    private static function item(string $label, string $route): array
    {
        return [
            'label' => $label,
            'href'  => '?r=' . $route,
            'match' => ['routes' => [$route], 'prefixes' => []],
            'active'=> false,
        ];
    }

    private static function matches(string $route, array $match): bool
    {
        $routes = $match['routes'] ?? [];
        if (in_array($route, $routes, true)) return true;

        $prefixes = $match['prefixes'] ?? [];
        foreach ($prefixes as $p) {
            if ($p !== '' && str_starts_with($route, $p)) return true;
        }
        return false;
    }
}
