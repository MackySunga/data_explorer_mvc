<?php
declare(strict_types=1);

function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function base_url(string $path = ''): string {
    $base = str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/index.php')));
    $base = rtrim($base, '/');
    if ($base === '' || $base === '.') $base = '';
    return $base . '/' . ltrim($path, '/');
}

function redirect(string $route, array $params = []): never {
    $q = http_build_query(array_merge(['r' => $route], $params));
    header('Location: ' . base_url('index.php?' . $q));
    exit;
}

function request_method(): string {
    return strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
}

function flash_set(string $type, string $message): void {
    $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
}

function flash_get_all(): array {
    $items = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $items;
}

function render(string $view, array $data = []): void
{
    // current route
    $route = (string)($_GET['r'] ?? 'dataset/upload');

    // default page title if controller didn’t provide one
    if (!isset($data['pageTitle']) || trim((string)$data['pageTitle']) === '') {
        $label = match (true) {
            $route === 'dataset/upload' => 'Upload',
            $route === 'dataset/list'   => 'Datasets',

            $route === 'explore/table'       => 'Explore',
            $route === 'explore/stats'       => 'Stats',
            $route === 'explore/visualize'   => 'Visualize',
            $route === 'explore/correlation' => 'Correlation',
            $route === 'explore/missing'     => 'Missing Values',
            $route === 'explore/outliers'    => 'Outliers',
            $route === 'explore/reports'     => 'Reports',

            str_starts_with($route, 'explore/report') => 'Report',
            str_starts_with($route, 'api/')           => 'API',

            default => 'Data Explorer',
        };

        $ds = '';
        if (!empty($data['meta']['name'])) {
            $ds = (string)$data['meta']['name'];
        }

        $data['pageTitle'] = $ds !== '' ? ($label . ' — ' . $ds) : ($label . ' — Data Explorer');
    }

    // resolve view file
    $viewFile = APP_PATH . '/Views/' . $view . '.php';
    if (!is_file($viewFile)) {
        throw new RuntimeException("View not found: {$viewFile}");
    }

    // make vars available to layout + view
    extract($data, EXTR_SKIP);

    // layout includes the view
    include APP_PATH . '/Views/layout.php';
}


function json_out(array $payload, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function safe_id(string $id): string {
    return preg_replace('/[^a-zA-Z0-9_-]/', '', $id) ?? '';
}
