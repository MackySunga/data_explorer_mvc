<?php
declare(strict_types=1);

namespace App\Models;

final class DatasetStore
{
    public function list(): array {
        $indexFile = META_PATH . '/index.json';
        if (!is_file($indexFile)) return [];
        $json = json_decode((string)file_get_contents($indexFile), true);
        return is_array($json) ? $json : [];
    }

    public function get(string $id): ?array {
        $id = preg_replace('/[^a-zA-Z0-9_-]/', '', $id);
        $metaFile = META_PATH . "/$id.json";
        if (!is_file($metaFile)) return null;
        $meta = json_decode((string)file_get_contents($metaFile), true);
        return is_array($meta) ? $meta : null;
    }

    public function createFromUpload(string $originalName, string $tmpPath): array {
        $id = $this->newId();
        $safeName = $this->sanitizeFilename($originalName);

        if (!is_dir(UPLOADS_PATH)) {
            @mkdir(UPLOADS_PATH, 0775, true);
        }

        $csvPath = UPLOADS_PATH . "/{$id}_{$safeName}";

        $isUploaded = is_uploaded_file($tmpPath);
        $tmpExists  = is_file($tmpPath);

        $moved = false;

        // preferred
        if ($tmpExists && $isUploaded) {
            $moved = @move_uploaded_file($tmpPath, $csvPath);
        }

        // fallback (some setups block is_uploaded_file/move_uploaded_file)
        if (!$moved && $tmpExists) {
            $moved = @copy($tmpPath, $csvPath);
            if ($moved) @unlink($tmpPath);
        }

        if (!$moved) {
            $last = error_get_last();
            $reason = $last ? ($last['message'] ?? 'unknown') : 'unknown';

            throw new \RuntimeException(
                "Failed to store upload.\n" .
                "tmpPath={$tmpPath} (exists=" . ($tmpExists ? 'yes' : 'no') . ", is_uploaded_file=" . ($isUploaded ? 'yes' : 'no') . ")\n" .
                "dest={$csvPath} (uploads_dir_exists=" . (is_dir(UPLOADS_PATH) ? 'yes' : 'no') . ", writable=" . (is_writable(UPLOADS_PATH) ? 'yes' : 'no') . ")\n" .
                "last_error={$reason}"
            );
        }

        $meta = [
            'id' => $id,
            'name' => $safeName,
            'csv_path' => $csvPath,
            'created_at' => date('c'),
        ];

        file_put_contents(META_PATH . "/$id.json", json_encode($meta, JSON_PRETTY_PRINT));

        $index = $this->list();
        $index[$id] = [
            'id' => $id,
            'name' => $safeName,
            'created_at' => $meta['created_at'],
        ];
        file_put_contents(META_PATH . "/index.json", json_encode($index, JSON_PRETTY_PRINT));

        return $meta;
    }

    public function delete(string $id): bool {
        $id = preg_replace('/[^a-zA-Z0-9_-]/', '', $id);
        $meta = $this->get($id);
        if (!$meta) return false;

        @unlink((string)($meta['csv_path'] ?? ''));
        @unlink(META_PATH . "/$id.json");

        foreach (glob(CACHE_PATH . "/{$id}_*.json") ?: [] as $f) {
            @unlink($f);
        }
        foreach (glob(REPORTS_PATH . "/{$id}_*.json") ?: [] as $f) {
            @unlink($f);
        }

        $index = $this->list();
        unset($index[$id]);
        file_put_contents(META_PATH . "/index.json", json_encode($index, JSON_PRETTY_PRINT));

        if (($_SESSION['active_dataset_id'] ?? '') === $id) {
            unset($_SESSION['active_dataset_id']);
        }

        return true;
    }

    public function setActive(string $id): void {
        $_SESSION['active_dataset_id'] = preg_replace('/[^a-zA-Z0-9_-]/', '', $id);
    }

    public function activeId(): ?string {
        $id = (string)($_SESSION['active_dataset_id'] ?? '');
        return $id !== '' ? $id : null;
    }

    private function newId(): string {
        return bin2hex(random_bytes(8));
    }

    private function sanitizeFilename(string $name): string {
        $name = basename($name);
        $name = preg_replace('/\s+/', '_', $name) ?? 'dataset.csv';
        $name = preg_replace('/[^a-zA-Z0-9._-]/', '', $name) ?? 'dataset.csv';
        if (!str_ends_with(strtolower($name), '.csv')) {
            $name .= '.csv';
        }
        return $name;
    }
}
