<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '1');

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH',  BASE_PATH . '/app');
define('PUBLIC_PATH', BASE_PATH . '/public');
define('STORAGE_PATH', BASE_PATH . '/storage');
define('UPLOADS_PATH', STORAGE_PATH . '/uploads');
define('META_PATH', STORAGE_PATH . '/meta');
define('CACHE_PATH', STORAGE_PATH . '/cache');
define('REPORTS_PATH', STORAGE_PATH . '/reports');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once APP_PATH . '/helpers.php';

// Ensure storage folders exist
$dirs = [
    STORAGE_PATH,
    UPLOADS_PATH,
    META_PATH,
    CACHE_PATH,
    REPORTS_PATH,
];

foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
}

// Tiny PSR-4 style autoloader (no composer)
spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) return;

    $rel = substr($class, strlen($prefix));
    $path = APP_PATH . '/' . str_replace('\\', '/', $rel) . '.php';
    if (is_file($path)) require_once $path;
});
