<?php
declare(strict_types=1);

namespace App\Services\Explore;

final class ReportPayloadRepair
{
    public function __construct(private ReportPayloadBuilder $builder) {}

    public function ensureCoreTables(array $payload, array $meta): array
    {
        $hasTables =
            isset($payload['summary']) &&
            isset($payload['missing']) &&
            isset($payload['outliers']) &&
            isset($payload['correlation']);

        if ($hasTables) return $payload;

        $savedCharts = (is_array($payload['charts'] ?? null)) ? $payload['charts'] : [];
        $savedReg    = (is_array($payload['regression'] ?? null)) ? $payload['regression'] : null;

        $maxRows = (int)($payload['max_rows'] ?? 50000);
        $maxRows = min(200000, max(1000, $maxRows ?: 50000));

        $rebuilt = $this->builder->build($meta, $maxRows);

        if (!empty($savedCharts)) $rebuilt['charts'] = $savedCharts;
        if (is_array($savedReg))  $rebuilt['regression'] = $savedReg;

        return $rebuilt;
    }
}
