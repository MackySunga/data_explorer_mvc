<?php
declare(strict_types=1);

namespace App\Services\Explore;

final class DatasetPathResolver
{
    public function resolve(array $meta): string
    {
        $candidates = [];

        // direct path-style fields
        foreach (['path','file_path','filepath','full_path','disk_path','stored_path','csv_path'] as $k) {
            if (!empty($meta[$k])) $candidates[] = (string)$meta[$k];
        }

        // filename-style fields
        foreach (['stored_name','stored','filename','file','basename','name_on_disk'] as $k) {
            if (!empty($meta[$k])) $candidates[] = (string)$meta[$k];
        }

        // likely base directories
        $bases = [];
        if (defined('DATASETS_PATH')) $bases[] = (string)DATASETS_PATH;
        if (defined('UPLOADS_PATH'))  $bases[] = (string)UPLOADS_PATH;

        if (defined('STORAGE_PATH')) {
            $bases[] = (string)STORAGE_PATH;
            $bases[] = rtrim((string)STORAGE_PATH, '/\\') . DIRECTORY_SEPARATOR . 'datasets';
            $bases[] = rtrim((string)STORAGE_PATH, '/\\') . DIRECTORY_SEPARATOR . 'uploads';
        }

        // fallback bases from APP_PATH or project root
        $root = defined('APP_PATH')
            ? dirname((string)APP_PATH)
            : dirname(__DIR__, 3); // app/Services/Explore -> project root

        $bases[] = $root . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'datasets';
        $bases[] = $root . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'uploads';
        $bases[] = $root . DIRECTORY_SEPARATOR . 'storage';

        $tried = [];

        foreach ($candidates as $p) {
            $p = trim($p);
            if ($p === '') continue;

            $pNorm = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $p);

            // 1) as-is
            if ($this->isExistingFile($pNorm)) return $this->real($pNorm);
            $tried[] = $pNorm;

            // 2) if relative, try joining bases
            if (!$this->isAbsolutePath($pNorm)) {
                foreach ($bases as $b) {
                    $try = rtrim($b, '/\\') . DIRECTORY_SEPARATOR . ltrim($pNorm, '/\\');
                    if ($this->isExistingFile($try)) return $this->real($try);
                    $tried[] = $try;
                }
            }
        }

        // Extra: if meta has an id and you save files like "<id>.csv"
        if (!empty($meta['id'])) {
            foreach ($bases as $b) {
                $try = rtrim($b, '/\\') . DIRECTORY_SEPARATOR . (string)$meta['id'] . '.csv';
                if ($this->isExistingFile($try)) return $this->real($try);
                $tried[] = $try;
            }
        }

        throw new \RuntimeException(
            'Dataset file not found on disk. Tried: ' . implode(' | ', array_slice($tried, 0, 25))
        );
    }

    private function isAbsolutePath(string $p): bool
    {
        // Windows: C:\... or \\server\share
        if (preg_match('~^[A-Za-z]:\\\\~', $p) === 1) return true;
        if (str_starts_with($p, '\\\\')) return true;

        // Linux/macOS: /...
        return str_starts_with($p, '/');
    }

    private function isExistingFile(string $p): bool
    {
        if (is_file($p)) return true;
        $rp = @realpath($p);
        return $rp !== false && is_file($rp);
    }

    private function real(string $p): string
    {
        $rp = @realpath($p);
        return ($rp !== false) ? $rp : $p;
    }
}
