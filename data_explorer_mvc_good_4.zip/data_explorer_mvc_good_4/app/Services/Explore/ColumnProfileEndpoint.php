<?php
declare(strict_types=1);

namespace App\Services\Explore;

final class ColumnProfileEndpoint
{
    public function __construct(
        private DatasetPathResolver $resolver,
        private ColumnProfiler $profiler
    ) {}

    public function handle(array $meta, string $col, int $maxRows, int $bins, int $topN): array
    {
        $csvPath = $this->resolver->resolve($meta);
        return $this->profiler->profile($csvPath, $col, $maxRows, $bins, $topN);
    }
}
