<?php
declare(strict_types=1);

namespace App\Services\Explore;

final class ReportFileStore
{
    public function listForDataset(string $datasetId): array
    {
        $files = glob(REPORTS_PATH . "/{$datasetId}_*.json") ?: [];
        rsort($files);
        return array_map('basename', $files);
    }

    public function saveNew(string $datasetId, array $payload): string
    {
        $this->ensureDir(REPORTS_PATH);

        $file = $datasetId . '_' . date('Ymd_His') . '.json';
        $file = $this->sanitizeFile($file);

        if ($file === '') {
            throw new \RuntimeException('Failed to create report filename.');
        }

        $path = REPORTS_PATH . '/' . $file;
        $ok = @file_put_contents($path, json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
        if ($ok === false) {
            throw new \RuntimeException('Failed to write report file to disk.');
        }

        return $file;
    }

    public function load(string $datasetId, string $file): array
    {
        $file = $this->sanitizeFile($file);

        if ($file === '' || !str_starts_with($file, $datasetId . '_')) {
            throw new \RuntimeException('Invalid report file.');
        }

        $path = REPORTS_PATH . '/' . $file;
        if (!is_file($path)) {
            throw new \RuntimeException('Report not found.');
        }

        $payload = json_decode((string)file_get_contents($path), true);
        if (!is_array($payload)) {
            throw new \RuntimeException('Report is corrupted.');
        }

        return $payload;
    }

    public function overwrite(string $datasetId, string $file, array $payload): void
    {
        $file = $this->sanitizeFile($file);

        if ($file === '' || !str_starts_with($file, $datasetId . '_')) {
            throw new \RuntimeException('Invalid report file.');
        }

        $path = REPORTS_PATH . '/' . $file;
        if (!is_file($path)) {
            throw new \RuntimeException('Report not found on disk.');
        }

        $ok = @file_put_contents($path, json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
        if ($ok === false) {
            throw new \RuntimeException('Failed to update report JSON on disk.');
        }
    }

    public function absolutePath(string $datasetId, string $file): string
    {
        $file = $this->sanitizeFile($file);

        if ($file === '' || !str_starts_with($file, $datasetId . '_')) {
            throw new \RuntimeException('Invalid report file.');
        }

        $path = REPORTS_PATH . '/' . $file;
        if (!is_file($path)) {
            throw new \RuntimeException('Report not found.');
        }

        return $path;
    }

    private function ensureDir(string $dir): void
    {
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
    }

    private function sanitizeFile(string $file): string
    {
        return preg_replace('/[^a-zA-Z0-9_.-]/', '', $file) ?? '';
    }
}
