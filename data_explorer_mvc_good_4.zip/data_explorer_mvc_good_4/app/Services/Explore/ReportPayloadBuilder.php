<?php
declare(strict_types=1);

namespace App\Services\Explore;

use App\Services\StatsService;
use App\Services\InsightService;

final class ReportPayloadBuilder
{
    public function __construct(
        private StatsService $stats,
        private InsightService $insight
    ) {}

    public function build(array $meta, int $maxRows): array
    {
        $csvPath = (string)($meta['csv_path'] ?? '');
        $summary = $this->stats->summary($csvPath, $maxRows);

        $types = $summary['types'] ?? [];
        $cols  = $summary['columns'] ?? [];
        $numeric = array_values(array_filter($cols, fn($c) => ($types[$c] ?? '') === 'numeric'));

        $corr     = $this->insight->correlationMatrix($csvPath, $numeric, $maxRows);
        $missing  = $this->insight->missingByColumn($csvPath, $cols, $maxRows);
        $outliers = $this->insight->outlierSummary($csvPath, $numeric, $maxRows);

        return [
            'dataset' => [
                'id' => $meta['id'] ?? null,
                'name' => $meta['name'] ?? null,
                'created_at' => $meta['created_at'] ?? null,
            ],
            'generated_at' => date('c'),
            'max_rows' => $maxRows,
            'summary' => $summary,
            'correlation' => $corr,
            'missing' => $missing,
            'outliers' => $outliers,
        ];
    }
}
