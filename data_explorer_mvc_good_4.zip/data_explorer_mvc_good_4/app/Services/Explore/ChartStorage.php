<?php
declare(strict_types=1);

namespace App\Services\Explore;

final class ChartStorage
{
    public function ensureChartsDir(): void
    {
        $dir = REPORTS_PATH . '/charts';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
    }

    /** Saves dataURL image and returns relative path like "charts/<name>.png" */
    public function saveDataUrlImage(string $dataUrl, string $datasetId): string
    {
        if (!str_starts_with($dataUrl, 'data:image/')) return '';

        $comma = strpos($dataUrl, ',');
        if ($comma === false) return '';

        $meta = substr($dataUrl, 0, $comma);
        $b64  = substr($dataUrl, $comma + 1);

        $ext = 'png';
        if (str_contains($meta, 'image/jpeg') || str_contains($meta, 'image/jpg')) $ext = 'jpg';
        if (str_contains($meta, 'image/png')) $ext = 'png';

        $bin = base64_decode($b64, true);
        if ($bin === false) return '';

        $this->ensureChartsDir();

        $name = $datasetId . '_chart_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $name = preg_replace('/[^a-zA-Z0-9_.-]/', '_', $name) ?? '';
        if ($name === '') return '';

        $abs = REPORTS_PATH . '/charts/' . $name;
        $ok = @file_put_contents($abs, $bin);
        if ($ok === false) return '';

        return 'charts/' . $name;
    }

    public function stream(string $imgBasename): void
    {
        $imgBasename = preg_replace('/[^a-zA-Z0-9_.-]/', '', $imgBasename) ?? '';
        $path = REPORTS_PATH . '/charts/' . $imgBasename;

        if ($imgBasename === '' || !is_file($path)) {
            http_response_code(404);
            exit('Not found.');
        }

        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $ct = match ($ext) {
            'jpg', 'jpeg' => 'image/jpeg',
            default => 'image/png',
        };

        header('Content-Type: ' . $ct);
        header('Cache-Control: private, max-age=3600');
        readfile($path);
        exit;
    }
}
