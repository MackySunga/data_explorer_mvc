<?php
declare(strict_types=1);

namespace App\Services\Explore;

use App\Services\StatsService;
use App\Services\InsightService;
use App\Services\PdfReportService;
use App\Services\ReportFormatService;

final class ReportWorkflow
{
    private ReportPayloadBuilder $builder;
    private ReportPayloadRepair $repair;

    public function __construct(
        private StatsService $stats,
        private InsightService $insight,
        private PdfReportService $pdf,
        private ReportFormatService $formatter,
        private ReportFileStore $files,
        private ChartStorage $charts
    ) {
        $this->builder = new ReportPayloadBuilder($this->stats, $this->insight);
        $this->repair  = new ReportPayloadRepair($this->builder);
    }

    public function clampMaxRows(mixed $v, int $default = 50000): int
    {
        $n = (int)($v ?? $default);
        return min(200000, max(1000, $n ?: $default));
    }

    public function build(array $meta, int $maxRows): array
    {
        return $this->builder->build($meta, $maxRows);
    }

    public function normalize(array $payload): array
    {
        return $this->formatter->normalize($payload);
    }

    public function listFiles(array $meta): array
    {
        $id = (string)($meta['id'] ?? '');
        if ($id === '') return [];
        return $this->files->listForDataset($id);
    }

    public function saveNew(array $meta, int $maxRows): string
    {
        $id = (string)($meta['id'] ?? '');
        if ($id === '') throw new \RuntimeException('Dataset id missing.');
        $payload = $this->builder->build($meta, $maxRows);
        return $this->files->saveNew($id, $payload);
    }

    public function savePayload(array $meta, array $payload): string
    {
        $id = (string)($meta['id'] ?? '');
        if ($id === '') throw new \RuntimeException('Dataset id missing.');
        return $this->files->saveNew($id, $payload);
    }

    public function load(array $meta, string $file): array
    {
        $id = (string)($meta['id'] ?? '');
        if ($id === '') throw new \RuntimeException('Dataset id missing.');
        return $this->files->load($id, $file);
    }

    public function loadAndRepair(array $meta, string $file): array
    {
        $payload = $this->load($meta, $file);
        return $this->repair->ensureCoreTables($payload, $meta);
    }

    public function overwrite(array $meta, string $file, array $payload): void
    {
        $id = (string)($meta['id'] ?? '');
        if ($id === '') throw new \RuntimeException('Dataset id missing.');
        $this->files->overwrite($id, $file, $payload);
    }

    public function absolutePath(array $meta, string $file): string
    {
        $id = (string)($meta['id'] ?? '');
        if ($id === '') throw new \RuntimeException('Dataset id missing.');
        return $this->files->absolutePath($id, $file);
    }

    /** chartsIn: [{title, dataUrl}, ...] => returns saved list for report JSON */
    public function saveChartsFromQueue(string $datasetId, array $chartsIn): array
    {
        $saved = [];

        foreach ($chartsIn as $ch) {
            if (!is_array($ch)) continue;
            $title = (string)($ch['title'] ?? 'Chart');
            $dataUrl = (string)($ch['dataUrl'] ?? '');
            if ($dataUrl === '') continue;

            $rel = $this->charts->saveDataUrlImage($dataUrl, $datasetId);
            if ($rel === '') continue;

            $saved[] = ['title' => $title, 'path' => $rel];
        }

        return $saved;
    }

    public function streamPdf(array $meta, array $payload, string $downloadName): void
    {
        $this->pdf->stream($payload, $downloadName);
    }

    public function chartStorage(): ChartStorage
    {
        return $this->charts;
    }
}
