<?php
declare(strict_types=1);

namespace App\Services\Explore;

use App\Services\ChartDataService;

final class ChartDataEndpoint
{
    public function __construct(
        private DatasetPathResolver $resolver,
        private ChartDataService $chartData
    ) {}

    public function handle(array $meta, string $rawBody, bool $debug = false): array
    {
        $csvPath = $this->resolver->resolve($meta);

        $params = json_decode($rawBody, true);
        if (!is_array($params)) {
            throw new \RuntimeException('Invalid JSON body.');
        }

        $out = $this->chartData->build($csvPath, $params);

        // Optional debug append (useful while developing)
        if ($debug && is_array($out)) {
            $out['_debug'] = [
                'csv_path' => $csvPath,
                'meta_keys' => array_keys($meta),
            ];
        }

        return $out;
    }
}
