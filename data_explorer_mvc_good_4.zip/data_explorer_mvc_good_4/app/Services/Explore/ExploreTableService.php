<?php
declare(strict_types=1);

namespace App\Services\Explore;

use App\Services\CsvReader;
use App\Services\FilterEngine;
use App\Services\StatsService;

final class ExploreTableService
{
    public function __construct(
        private CsvReader $csv,
        private FilterEngine $filter,
        private StatsService $stats
    ) {}

    public function build(string $csvPath, array $query): array
    {
        $columns = $this->csv->readHeader($csvPath);

        $page = max(1, (int)($query['page'] ?? 1));
        $perPage = min(100, max(10, (int)($query['per_page'] ?? 25)));
        $q = trim((string)($query['q'] ?? ''));

        $selected = $query['cols'] ?? [];
        if (!is_array($selected) || empty($selected)) $selected = $columns;
        $selected = array_values(array_intersect($selected, $columns));
        if (empty($selected)) $selected = $columns;

        $sort = (string)($query['sort'] ?? '');
        $dir  = strtolower((string)($query['dir'] ?? 'asc'));
        if ($dir !== 'asc' && $dir !== 'desc') $dir = 'asc';
        if (!in_array($sort, $selected, true)) $sort = '';

        $profileRows = min(50000, max(1000, (int)($query['profile_rows'] ?? 20000)));
        $summary = $this->stats->summary($csvPath, $profileRows);

        $types = is_array($summary['types'] ?? null) ? $summary['types'] : [];
        $stats = is_array($summary['stats'] ?? null) ? $summary['stats'] : [];

        $colInfo = [];
        foreach ($selected as $c) {
            $s = is_array($stats[$c] ?? null) ? $stats[$c] : [];
            $count = (int)($s['count'] ?? 0);
            $missing = (int)($s['missing'] ?? 0);
            $missingPct = $count > 0 ? ($missing / $count) * 100.0 : 0.0;

            $colInfo[$c] = [
                'type' => (string)($types[$c] ?? 'categorical'),
                'missing_pct' => $missingPct,
                'unique' => (int)($s['unique'] ?? 0),
            ];
        }

        $f_op = $query['f_op'] ?? [];
        $f_v1 = $query['f_v1'] ?? [];
        $f_v2 = $query['f_v2'] ?? [];
        if (!is_array($f_op)) $f_op = [];
        if (!is_array($f_v1)) $f_v1 = [];
        if (!is_array($f_v2)) $f_v2 = [];

        $start = ($page - 1) * $perPage;
        $end = $start + $perPage;

        $rows = [];
        $matched = 0;

        foreach ($this->csv->iterate($csvPath, 0, 0) as $row) {
            if (!$this->filter->match($row, $q, [])) continue;

            $ok = true;
            foreach ($f_op as $col => $op) {
                $col = (string)$col;
                $op  = trim((string)$op);
                if ($op === '') continue;
                if (!in_array($col, $columns, true)) continue;

                $type = (string)($types[$col] ?? 'categorical');
                $v1 = (string)($f_v1[$col] ?? '');
                $v2 = (string)($f_v2[$col] ?? '');

                if (!$this->matchColFilter($row, $col, $type, $op, $v1, $v2)) { $ok = false; break; }
            }
            if (!$ok) continue;

            if ($matched >= $start && $matched < $end) {
                $rows[] = array_intersect_key($row, array_flip($selected));
            }
            $matched++;
        }

        if ($sort !== '') {
            usort($rows, function(array $a, array $b) use ($sort, $dir): int {
                $va = (string)($a[$sort] ?? '');
                $vb = (string)($b[$sort] ?? '');

                $ea = trim($va) === '';
                $eb = trim($vb) === '';
                if ($ea && $eb) return 0;
                if ($ea) return 1;
                if ($eb) return -1;

                if (is_numeric($va) && is_numeric($vb)) {
                    $cmp = ((float)$va <=> (float)$vb);
                } else {
                    $cmp = strnatcasecmp($va, $vb);
                }
                return ($dir === 'desc') ? -$cmp : $cmp;
            });
        }

        $totalMatched = $matched;
        $totalPages = max(1, (int)ceil($totalMatched / $perPage));

        return [
            'columns' => $columns,
            'selected' => $selected,
            'rows' => $rows,
            'page' => $page,
            'perPage' => $perPage,
            'totalMatched' => $totalMatched,
            'totalPages' => $totalPages,
            'q' => $q,
            'sort' => $sort,
            'dir' => $dir,
            'types' => $types,
            'colInfo' => $colInfo,
            'statsSampleRows' => $profileRows,
            'f_op' => $f_op,
            'f_v1' => $f_v1,
            'f_v2' => $f_v2,
        ];
    }

    private function matchColFilter(array $row, string $col, string $type, string $op, string $v1, string $v2): bool
    {
        $raw = isset($row[$col]) ? trim((string)$row[$col]) : '';
        $isBlank = ($raw === '');

        if ($op === 'is_blank') return $isBlank;
        if ($op === 'not_blank') return !$isBlank;

        if ($isBlank) return false;

        if ($type === 'numeric') {
            if (!is_numeric($raw)) return false;
            $x = (float)$raw;

            $v1t = trim($v1);
            $v2t = trim($v2);

            if ($op === 'between') {
                if ($v1t === '' && $v2t === '') return true;
                if ($v1t !== '' && !is_numeric($v1t)) return false;
                if ($v2t !== '' && !is_numeric($v2t)) return false;

                $min = ($v1t === '') ? -INF : (float)$v1t;
                $max = ($v2t === '') ?  INF : (float)$v2t;
                return ($x >= $min && $x <= $max);
            }

            if ($v1t === '' || !is_numeric($v1t)) return false;
            $a = (float)$v1t;

            return match ($op) {
                'gte' => $x >= $a,
                'lte' => $x <= $a,
                'eq'  => $x == $a,
                'ne'  => $x != $a,
                default => true,
            };
        }

        $hay = mb_strtolower($raw);
        $needle = mb_strtolower(trim($v1));

        if ($needle === '' && in_array($op, ['equals','not_equals','contains','starts_with','ends_with'], true)) {
            return false;
        }

        return match ($op) {
            'equals'      => $hay === $needle,
            'not_equals'  => $hay !== $needle,
            'contains'    => mb_stripos($hay, $needle) !== false,
            'starts_with' => str_starts_with($hay, $needle),
            'ends_with'   => str_ends_with($hay, $needle),
            default       => true,
        };
    }
}
