<?php
declare(strict_types=1);

namespace App\Services\Explore;

final class ColumnProfiler
{
    public function profile(string $csvPath, string $col, int $maxRows, int $bins, int $topN): array
    {
        if (!is_file($csvPath)) {
            throw new \RuntimeException('Dataset file not found on disk.');
        }

        $fh = @fopen($csvPath, 'rb');
        if (!$fh) throw new \RuntimeException('Unable to open CSV.');

        $first = fgets($fh);
        if ($first === false) {
            fclose($fh);
            throw new \RuntimeException('CSV seems empty.');
        }

        // delimiter detect
        $delims = [',' => substr_count($first, ','), ';' => substr_count($first, ';'), "\t" => substr_count($first, "\t")];
        arsort($delims);
        $delim = (string)array_key_first($delims);
        if ($delim === '' || ($delims[$delim] ?? 0) === 0) $delim = ',';
        rewind($fh);

        $header = fgetcsv($fh, 0, $delim);
        if (!is_array($header)) {
            fclose($fh);
            throw new \RuntimeException('Failed to read header.');
        }

        $idx = null;
        foreach ($header as $i => $h) {
            if ((string)$h === $col) { $idx = (int)$i; break; }
        }
        if ($idx === null) {
            fclose($fh);
            throw new \RuntimeException('Column not found: ' . $col);
        }

        $total = 0;
        $missing = 0;

        $numCount = 0;
        $nonMissing = 0;

        $nums = [];
        $mean = 0.0;
        $m2 = 0.0;

        $freq = [];

        while (($row = fgetcsv($fh, 0, $delim)) !== false) {
            if ($total >= $maxRows) break;
            $total++;

            $v = $row[$idx] ?? '';
            $v = is_string($v) ? trim($v) : trim((string)$v);

            if ($v === '') {
                $missing++;
                continue;
            }

            $nonMissing++;

            if (is_numeric($v)) {
                $x = (float)$v;
                $numCount++;

                $delta = $x - $mean;
                $mean += $delta / $numCount;
                $m2 += $delta * ($x - $mean);

                $nums[] = $x;
            } else {
                $freq[$v] = ($freq[$v] ?? 0) + 1;
            }
        }
        fclose($fh);

        $missingPct = ($total > 0) ? ($missing / $total) * 100.0 : 0.0;

        $type = 'categorical';
        if ($nonMissing > 0) {
            $ratio = $numCount / $nonMissing;
            if ($ratio >= 0.85 && $numCount >= 10) $type = 'numeric';
        }

        $fmt = function($v): string {
            if ($v === null) return '';
            if (!is_numeric($v)) return (string)$v;
            return sprintf('%.5g', (float)$v);
        };

        $quantile = function(array $sorted, float $p) {
            $n = count($sorted);
            if ($n === 0) return null;
            if ($n === 1) return $sorted[0];
            $pos = ($n - 1) * $p;
            $lo = (int)floor($pos);
            $hi = (int)ceil($pos);
            if ($lo === $hi) return $sorted[$lo];
            $w = $pos - $lo;
            return $sorted[$lo] * (1.0 - $w) + $sorted[$hi] * $w;
        };

        if ($type === 'numeric') {
            sort($nums);
            $n = count($nums);
            $min = $n ? $nums[0] : null;
            $max = $n ? $nums[$n - 1] : null;
            $std = ($numCount > 1) ? sqrt($m2 / ($numCount - 1)) : 0.0;

            $q1  = $quantile($nums, 0.25);
            $med = $quantile($nums, 0.50);
            $q3  = $quantile($nums, 0.75);

            $labels = [];
            $counts = [];

            if ($n === 0 || $min === null || $max === null) {
                $labels = [];
                $counts = [];
            } elseif ($min == $max) {
                $labels = [$fmt($min)];
                $counts = [$n];
            } else {
                $counts = array_fill(0, $bins, 0);
                $range = $max - $min;
                $step = $range / $bins;

                for ($i = 0; $i < $bins; $i++) {
                    $a = $min + $i * $step;
                    $b = ($i === $bins - 1) ? $max : ($min + ($i + 1) * $step);
                    $labels[] = $fmt($a) . '–' . $fmt($b);
                }

                foreach ($nums as $x) {
                    $k = (int)floor(($x - $min) / $step);
                    if ($k < 0) $k = 0;
                    if ($k >= $bins) $k = $bins - 1;
                    $counts[$k]++;
                }
            }

            return [
                'ok' => true,
                'col' => $col,
                'type' => 'numeric',
                'total' => $total,
                'missing' => $missing,
                'missing_pct' => $missingPct,
                'stats' => [
                    'min' => $fmt($min),
                    'max' => $fmt($max),
                    'mean' => $fmt($mean),
                    'std' => $fmt($std),
                    'q1' => $fmt($q1),
                    'median' => $fmt($med),
                    'q3' => $fmt($q3),
                ],
                'hist' => [
                    'labels' => $labels,
                    'counts' => $counts,
                ],
                'unique' => null,
                'top' => [],
            ];
        }

        arsort($freq);
        $top = [];
        $i = 0;
        foreach ($freq as $val => $cnt) {
            $top[] = ['value' => $val, 'count' => (int)$cnt];
            $i++;
            if ($i >= $topN) break;
        }

        return [
            'ok' => true,
            'col' => $col,
            'type' => 'categorical',
            'total' => $total,
            'missing' => $missing,
            'missing_pct' => $missingPct,
            'unique' => count($freq),
            'top' => $top,
            'stats' => null,
            'hist' => ['labels' => [], 'counts' => []],
        ];
    }
}
