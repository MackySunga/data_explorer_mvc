<?php
declare(strict_types=1);

namespace App\Services\Explore;

use App\Services\CsvReader;
use App\Services\StatsService;
use App\Services\RegressionService;

final class RegressionWorkflow
{
    private RegressionService $reg;

    public function __construct(
        private StatsService $stats,
        private CsvReader $csv
    ) {
        $this->reg = new RegressionService($this->csv);
    }

    public function clampMaxRows(mixed $v, int $default = 50000): int
    {
        $n = (int)($v ?? $default);
        return min(200000, max(1000, $n ?: $default));
    }

    public function clampDiagPoints(mixed $v, int $default = 2000): int
    {
        $n = (int)($v ?? $default);
        return min(5000, max(200, $n ?: $default));
    }

    public function numericColumns(string $csvPath, int $maxRows): array
    {
        $summary = $this->stats->summary($csvPath, $maxRows);
        $types = $summary['types'] ?? [];
        $cols  = $summary['columns'] ?? [];
        return array_values(array_filter($cols, fn($c) => ($types[$c] ?? '') === 'numeric'));
    }

    /** returns [y, x] normalized against numericCols */
    public function normalizeSelection(string $y, array $x, array $numericCols): array
    {
        $y = trim($y);
        if ($y !== '' && !in_array($y, $numericCols, true)) $y = '';

        if (!is_array($x)) $x = [];
        $x = array_values(array_intersect($x, $numericCols));
        $x = array_values(array_filter($x, fn($c) => $c !== $y));

        return [$y, $x];
    }

    public function runOls(string $csvPath, string $y, array $x, int $maxRows, int $diagPoints): array
    {
        return $this->reg->ols($csvPath, $y, $x, $maxRows, $diagPoints);
    }

    public function fitOlsForReport(string $csvPath, string $y, array $x, int $maxRows, int $diagPoints): array
    {
        return $this->reg->fitOls($csvPath, $y, $x, $maxRows, $diagPoints);
    }
}
