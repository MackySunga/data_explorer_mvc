<?php
declare(strict_types=1);

namespace App\Services;

final class ChartDataService
{
    public function build(string $csvPath, array $p): array
    {
        $maxRows = $this->clampInt($p['max_rows'] ?? 50000, 1000, 200000);
        $type    = (string)($p['chart_type'] ?? 'hist');
        $showLegend = (bool)($p['show_legend'] ?? true);

        // params
        $col1    = trim((string)($p['col1'] ?? ''));
        $bins    = $this->clampInt($p['bins'] ?? 12, 5, 50);
        $topN    = $this->clampInt($p['topN'] ?? 12, 5, 50);
        $xCol    = trim((string)($p['xCol'] ?? ''));
        $yCol    = trim((string)($p['yCol'] ?? ''));
        $lineX   = trim((string)($p['lineX'] ?? ''));
        $lineY   = trim((string)($p['lineY'] ?? ''));
        $groupCol= trim((string)($p['groupCol'] ?? ''));

        // decide required columns
        $needCols = [];
        if (in_array($type, ['hist','bar','pie','doughnut','boxplot','violin'], true)) {
            if ($col1 === '') return ['ok'=>false,'error'=>'Select a column first.'];
            $needCols[] = $col1;
            if (($type === 'boxplot' || $type === 'violin') && $groupCol !== '') $needCols[] = $groupCol;
        } elseif ($type === 'scatter') {
            if ($xCol === '' || $yCol === '') return ['ok'=>false,'error'=>'Select X and Y columns.'];
            $needCols = [$xCol, $yCol];
        } elseif ($type === 'line') {
            if ($lineY === '') return ['ok'=>false,'error'=>'Select Y column (numeric).'];
            $needCols[] = $lineY;
            if ($lineX !== '') $needCols[] = $lineX;
        } else {
            return ['ok'=>false,'error'=>'Unknown chart type.'];
        }

        // read values
        [$header, $rows] = $this->readCsvColumns($csvPath, $needCols, $maxRows);

        // build chart config
        switch ($type) {
            case 'hist':     return $this->histogram($col1, $rows[$col1] ?? [], $bins, $showLegend);
            case 'bar':      return $this->categoryBar($col1, $rows[$col1] ?? [], $topN, $showLegend);
            case 'pie':      return $this->categoryPie('pie', $col1, $rows[$col1] ?? [], $topN, $showLegend);
            case 'doughnut': return $this->categoryPie('doughnut', $col1, $rows[$col1] ?? [], $topN, $showLegend);
            case 'scatter':  return $this->scatter($xCol, $rows[$xCol] ?? [], $yCol, $rows[$yCol] ?? [], $showLegend);
            case 'line':     return $this->line($lineX, $rows[$lineX] ?? [], $lineY, $rows[$lineY] ?? [], $showLegend);
            case 'boxplot':  return $this->boxOrViolin('boxplot', $col1, $rows[$col1] ?? [], $groupCol, $rows[$groupCol] ?? [], $showLegend);
            case 'violin':   return $this->boxOrViolin('violin', $col1, $rows[$col1] ?? [], $groupCol, $rows[$groupCol] ?? [], $showLegend);
        }

        return ['ok'=>false,'error'=>'Unhandled chart type.'];
    }

    // ---------- Readers

    private function readCsvColumns(string $path, array $columns, int $maxRows): array
    {
        $delimiter = $this->detectDelimiter($path);

        $fh = new \SplFileObject($path, 'rb');
        $fh->setFlags(\SplFileObject::READ_CSV | \SplFileObject::SKIP_EMPTY);
        $fh->setCsvControl($delimiter);

        $header = $fh->fgetcsv();
        if (!is_array($header) || empty($header)) {
            return [[], []];
        }
        $header = array_map(fn($h) => trim((string)$h), $header);

        $map = [];
        foreach ($header as $i => $h) {
            if ($h !== '' && !isset($map[$h])) $map[$h] = (int)$i;
        }

        // validate requested cols exist
        foreach ($columns as $c) {
            if (!isset($map[$c])) {
                throw new \RuntimeException("Column not found in CSV: {$c}");
            }
        }

        $out = [];
        foreach ($columns as $c) $out[$c] = [];

        $count = 0;
        while (!$fh->eof() && $count < $maxRows) {
            $row = $fh->fgetcsv();
            if (!is_array($row)) continue;

            foreach ($columns as $c) {
                $idx = $map[$c];
                $v = $row[$idx] ?? '';
                $out[$c][] = $this->normalizeCell($v);
            }
            $count++;
        }

        return [$header, $out];
    }

    private function normalizeCell($v): string
    {
        $s = trim((string)$v);
        // treat common “missing” tokens as empty
        $low = strtolower($s);
        if ($s === '' || $low === 'na' || $low === 'nan' || $low === 'null' || $low === 'none') return '';
        return $s;
    }

    private function detectDelimiter(string $path): string
    {
        $sample = (string)@file_get_contents($path, false, null, 0, 4096);
        if ($sample === '') return ',';

        $cands = [',' => substr_count($sample, ','), ';' => substr_count($sample, ';'), "\t" => substr_count($sample, "\t"), '|' => substr_count($sample, '|')];
        arsort($cands);
        $best = array_key_first($cands);
        return $best ?: ',';
    }

    private function clampInt($v, int $min, int $max): int
    {
        $n = (int)$v;
        if ($n < $min) return $min;
        if ($n > $max) return $max;
        return $n;
    }

    private function toNumeric(array $vals): array
    {
        $out = [];
        foreach ($vals as $s) {
            if ($s === '') continue;
            if (is_numeric($s)) $out[] = (float)$s;
        }
        return $out;
    }

    // ---------- Chart builders

    private function baseOptions(bool $showLegend): array
    {
        return [
            'responsive' => true,
            'plugins' => [
                'legend' => [
                    'display' => $showLegend,
                    'position' => 'bottom',
                ],
                'tooltip' => [
                    'enabled' => true,
                ],
            ],
        ];
    }

    private function histogram(string $col, array $raw, int $bins, bool $showLegend): array
    {
        $vals = $this->toNumeric($raw);
        if (count($vals) < 2) return ['ok'=>false,'error'=>"Not enough numeric values for histogram: {$col}"];

        $min = min($vals);
        $max = max($vals);
        if ($min === $max) $max = $min + 1.0;

        $w = ($max - $min) / $bins;
        $counts = array_fill(0, $bins, 0);

        foreach ($vals as $v) {
            $i = (int)floor(($v - $min) / $w);
            if ($i < 0) $i = 0;
            if ($i >= $bins) $i = $bins - 1;
            $counts[$i]++;
        }

        $labels = [];
        for ($i=0; $i<$bins; $i++) {
            $a = $min + $i*$w;
            $b = $a + $w;
            $labels[] = sprintf('%.3g–%.3g', $a, $b);
        }

        $title = "Histogram: {$col}";
        $options = $this->baseOptions($showLegend);
        $options['scales'] = [
            'y' => ['beginAtZero' => true],
            'x' => ['ticks' => ['maxRotation' => 45, 'minRotation' => 0]],
        ];

        return [
            'ok' => true,
            'title' => $title,
            'chart' => [
                'type' => 'bar',
                'data' => [
                    'labels' => $labels,
                    'datasets' => [[
                        'label' => 'Count',
                        'data' => $counts,
                    ]],
                ],
                'options' => $options,
            ],
        ];
    }

    private function categoryBar(string $col, array $raw, int $topN, bool $showLegend): array
    {
        [$labels, $data] = $this->topCategories($raw, $topN);

        $title = "Bar: {$col}";
        $options = $this->baseOptions($showLegend);
        $options['scales'] = [
            'y' => ['beginAtZero' => true],
            'x' => ['ticks' => ['maxRotation' => 45, 'minRotation' => 0]],
        ];

        return [
            'ok' => true,
            'title' => $title,
            'chart' => [
                'type' => 'bar',
                'data' => [
                    'labels' => $labels,
                    'datasets' => [[
                        'label' => 'Count',
                        'data' => $data,
                    ]],
                ],
                'options' => $options,
            ],
        ];
    }

    private function categoryPie(string $pieType, string $col, array $raw, int $topN, bool $showLegend): array
    {
        [$labels, $data] = $this->topCategories($raw, $topN);

        $title = ucfirst($pieType) . ": {$col}";
        $options = $this->baseOptions($showLegend);
        // pie looks nicer with legend on right sometimes, but keep bottom for consistency
        return [
            'ok' => true,
            'title' => $title,
            'chart' => [
                'type' => $pieType,
                'data' => [
                    'labels' => $labels,
                    'datasets' => [[
                        'label' => 'Count',
                        'data' => $data,
                    ]],
                ],
                'options' => $options,
            ],
        ];
    }

    private function topCategories(array $raw, int $topN): array
    {
        $counts = [];
        foreach ($raw as $s) {
            $k = ($s === '') ? '(blank)' : $s;
            $counts[$k] = ($counts[$k] ?? 0) + 1;
        }

        arsort($counts);
        $top = array_slice($counts, 0, $topN, true);
        $others = array_slice($counts, $topN, null, true);

        if (!empty($others)) {
            $top['Others'] = array_sum($others);
        }

        return [array_keys($top), array_values($top)];
    }

    private function scatter(string $xName, array $xRaw, string $yName, array $yRaw, bool $showLegend): array
    {
        $pts = [];
        $n = min(count($xRaw), count($yRaw));

        // cap points for performance
        $cap = 5000;

        for ($i=0; $i<$n && count($pts) < $cap; $i++) {
            $x = $xRaw[$i] ?? '';
            $y = $yRaw[$i] ?? '';
            if ($x === '' || $y === '') continue;
            if (!is_numeric($x) || !is_numeric($y)) continue;
            $pts[] = ['x' => (float)$x, 'y' => (float)$y];
        }

        if (count($pts) < 2) return ['ok'=>false,'error'=>"Not enough numeric pairs for scatter: {$xName} vs {$yName}"];

        $title = "Scatter: {$xName} vs {$yName}";
        $options = $this->baseOptions($showLegend);
        $options['scales'] = [
            'x' => ['type' => 'linear', 'position' => 'bottom'],
            'y' => ['type' => 'linear'],
        ];

        return [
            'ok' => true,
            'title' => $title,
            'chart' => [
                'type' => 'scatter',
                'data' => [
                    'datasets' => [[
                        'label' => "{$yName} vs {$xName}",
                        'data' => $pts,
                    ]],
                ],
                'options' => $options,
            ],
        ];
    }

    private function line(string $xName, array $xRaw, string $yName, array $yRaw, bool $showLegend): array
    {
        $ys = [];
        $labels = [];
        $n = count($yRaw);

        // cap points
        $cap = 5000;

        if ($xName === '') {
            // row index
            for ($i=0; $i<$n && count($ys) < $cap; $i++) {
                $y = $yRaw[$i] ?? '';
                if ($y === '' || !is_numeric($y)) continue;
                $labels[] = (string)($i + 1);
                $ys[] = (float)$y;
            }
        } else {
            $n2 = min(count($xRaw), count($yRaw));
            for ($i=0; $i<$n2 && count($ys) < $cap; $i++) {
                $x = $xRaw[$i] ?? '';
                $y = $yRaw[$i] ?? '';
                if ($x === '' || $y === '' || !is_numeric($y)) continue;
                $labels[] = (string)$x;
                $ys[] = (float)$y;
            }
        }

        if (count($ys) < 2) return ['ok'=>false,'error'=>"Not enough numeric values for line chart: {$yName}"];

        $title = ($xName === '')
            ? "Line: {$yName} (by row)"
            : "Line: {$yName} by {$xName}";

        $options = $this->baseOptions($showLegend);
        $options['scales'] = [
            'y' => ['beginAtZero' => false],
            'x' => ['ticks' => ['maxRotation' => 45, 'minRotation' => 0]],
        ];

        return [
            'ok' => true,
            'title' => $title,
            'chart' => [
                'type' => 'line',
                'data' => [
                    'labels' => $labels,
                    'datasets' => [[
                        'label' => $yName,
                        'data' => $ys,
                        'tension' => 0.2,
                        'pointRadius' => 1,
                    ]],
                ],
                'options' => $options,
            ],
        ];
    }

    private function boxOrViolin(string $chartType, string $valueCol, array $rawVals, string $groupCol, array $rawGroups, bool $showLegend): array
    {
        $values = [];
        foreach ($rawVals as $s) {
            $values[] = ($s !== '' && is_numeric($s)) ? (float)$s : null;
        }

        // If grouped, build arrays per group (top 12 groups by count)
        if ($groupCol !== '') {
            $groups = [];
            $n = min(count($values), count($rawGroups));
            for ($i=0; $i<$n; $i++) {
                $g = ($rawGroups[$i] ?? '');
                $g = ($g === '') ? '(blank)' : $g;
                $v = $values[$i];
                if ($v === null) continue;
                $groups[$g][] = $v;
            }

            if (empty($groups)) return ['ok'=>false,'error'=>"No numeric values for {$chartType} plot: {$valueCol}"];

            // sort groups by size desc, take top 12
            uasort($groups, fn($a,$b) => count($b) <=> count($a));
            $groups = array_slice($groups, 0, 12, true);

            // cap each group size (performance)
            foreach ($groups as $k => $arr) {
                if (count($arr) > 2000) $groups[$k] = array_slice($arr, 0, 2000);
            }

            $labels = array_keys($groups);
            $data = array_values($groups);

            $title = ucfirst($chartType) . ": {$valueCol} by {$groupCol}";
            $options = $this->baseOptions($showLegend);

            return [
                'ok' => true,
                'title' => $title,
                'chart' => [
                    'type' => $chartType,
                    'data' => [
                        'labels' => $labels,
                        'datasets' => [[
                            'label' => $valueCol,
                            'data' => $data, // array of arrays, required by plugin
                        ]],
                    ],
                    'options' => $options,
                ],
            ];
        }

        // single distribution (one label)
        $arr = array_values(array_filter($values, fn($v) => $v !== null));
        if (count($arr) < 2) return ['ok'=>false,'error'=>"Not enough numeric values for {$chartType} plot: {$valueCol}"];

        if (count($arr) > 4000) $arr = array_slice($arr, 0, 4000);

        $title = ucfirst($chartType) . ": {$valueCol}";
        $options = $this->baseOptions($showLegend);

        return [
            'ok' => true,
            'title' => $title,
            'chart' => [
                'type' => $chartType,
                'data' => [
                    'labels' => [$valueCol],
                    'datasets' => [[
                        'label' => $valueCol,
                        'data' => [$arr],
                    ]],
                ],
                'options' => $options,
            ],
        ];
    }
}
