<?php
declare(strict_types=1);

namespace App\Services;

final class StatsService
{
    private CsvReader $csv;
    private Profiler $profiler;

    public function __construct() {
        $this->csv = new CsvReader();
        $this->profiler = new Profiler();
    }

    public function summary(string $csvPath, int $maxRows = 50000): array {
        $cacheKey = $this->cacheKey($csvPath, "stats_{$maxRows}");
        if (is_file($cacheKey)) {
            $cached = json_decode((string)file_get_contents($cacheKey), true);
            if (is_array($cached)) return $cached;
        }

        $columns = $this->csv->readHeader($csvPath);
        $sample = [];
        $i = 0;
        foreach ($this->csv->iterate($csvPath, $maxRows, 0) as $row) {
            $sample[] = $row;
            $i++;
            if ($i >= $maxRows) break;
        }

        $types = $this->profiler->inferTypes($sample, $columns);

        $out = [
            'columns' => $columns,
            'types' => $types,
            'max_rows_used' => $maxRows,
            'stats' => [],
        ];

        foreach ($columns as $c) {
            $colVals = array_map(fn($r) => trim((string)($r[$c] ?? '')), $sample);
            $missing = count(array_filter($colVals, fn($v) => $v === ''));
            $nonMissing = array_values(array_filter($colVals, fn($v) => $v !== ''));

            if (($types[$c] ?? 'categorical') === 'numeric') {
                $nums = array_map('floatval', $nonMissing);
                sort($nums);
                $n = count($nums);

                $out['stats'][$c] = [
                    'type' => 'numeric',
                    'count' => $n,
                    'missing' => $missing,
                    'mean' => $n ? array_sum($nums) / $n : null,
                    'std' => $n ? $this->std($nums) : null,
                    'min' => $n ? $nums[0] : null,
                    'q1'  => $n ? $this->percentile($nums, 25) : null,
                    'median' => $n ? $this->percentile($nums, 50) : null,
                    'q3'  => $n ? $this->percentile($nums, 75) : null,
                    'max' => $n ? $nums[$n-1] : null,
                ];
            } else {
                $freq = [];
                foreach ($nonMissing as $v) {
                    $freq[$v] = ($freq[$v] ?? 0) + 1;
                }
                arsort($freq);
                $top = array_slice($freq, 0, 10, true);

                $out['stats'][$c] = [
                    'type' => 'categorical',
                    'count' => count($nonMissing),
                    'missing' => $missing,
                    'unique' => count($freq),
                    'top' => $top,
                ];
            }
        }

        file_put_contents($cacheKey, json_encode($out, JSON_PRETTY_PRINT));
        return $out;
    }

    public function histogram(string $csvPath, string $col, int $bins = 12, int $maxRows = 50000): array {
        $summary = $this->summary($csvPath, $maxRows);
        if (($summary['types'][$col] ?? '') !== 'numeric') {
            return ['ok' => false, 'error' => 'Column is not numeric'];
        }

        $nums = [];
        foreach ($this->csv->iterate($csvPath, $maxRows, 0) as $row) {
            $v = trim((string)($row[$col] ?? ''));
            if ($v === '' || !is_numeric($v)) continue;
            $nums[] = (float)$v;
        }
        if (!$nums) return ['ok' => false, 'error' => 'No numeric values found'];

        $min = min($nums);
        $max = max($nums);
        if ($min === $max) {
            return ['ok' => true, 'labels' => [(string)$min], 'counts' => [count($nums)]];
        }

        $width = ($max - $min) / $bins;
        $counts = array_fill(0, $bins, 0);
        foreach ($nums as $x) {
            $idx = (int)floor(($x - $min) / $width);
            if ($idx >= $bins) $idx = $bins - 1;
            if ($idx < 0) $idx = 0;
            $counts[$idx]++;
        }

        $labels = [];
        for ($i=0; $i<$bins; $i++) {
            $a = $min + $i*$width;
            $b = $a + $width;
            $labels[] = sprintf('%.3g–%.3g', $a, $b);
        }

        return ['ok' => true, 'labels' => $labels, 'counts' => $counts];
    }

    public function valueCounts(string $csvPath, string $col, int $topN = 15, int $maxRows = 50000): array {
        $freq = [];
        $seen = 0;

        foreach ($this->csv->iterate($csvPath, $maxRows, 0) as $row) {
            $v = trim((string)($row[$col] ?? ''));
            if ($v === '') continue;
            $freq[$v] = ($freq[$v] ?? 0) + 1;
            $seen++;
        }

        if ($seen === 0) return ['ok' => false, 'error' => 'No values found'];

        arsort($freq);
        $top = array_slice($freq, 0, $topN, true);

        return ['ok' => true, 'labels' => array_keys($top), 'counts' => array_values($top)];
    }

    public function scatter(string $csvPath, string $xCol, string $yCol, int $maxPoints = 2000, int $maxRows = 50000): array {
        $pts = [];
        foreach ($this->csv->iterate($csvPath, $maxRows, 0) as $row) {
            $x = trim((string)($row[$xCol] ?? ''));
            $y = trim((string)($row[$yCol] ?? ''));
            if ($x === '' || $y === '') continue;
            if (!is_numeric($x) || !is_numeric($y)) continue;

            $pts[] = ['x' => (float)$x, 'y' => (float)$y];
            if (count($pts) >= $maxPoints) break;
        }

        if (!$pts) return ['ok' => false, 'error' => 'No numeric pairs found'];
        return ['ok' => true, 'points' => $pts];
    }

    private function std(array $nums): float {
        $n = count($nums);
        if ($n < 2) return 0.0;
        $mean = array_sum($nums) / $n;
        $ss = 0.0;
        foreach ($nums as $x) $ss += ($x - $mean) ** 2;
        return sqrt($ss / ($n - 1));
    }

    private function percentile(array $sorted, float $p): float {
        $n = count($sorted);
        if ($n === 0) return 0.0;
        $idx = ($p/100) * ($n - 1);
        $lo = (int)floor($idx);
        $hi = (int)ceil($idx);
        if ($lo === $hi) return (float)$sorted[$lo];
        $w = $idx - $lo;
        return (1-$w) * (float)$sorted[$lo] + $w * (float)$sorted[$hi];
    }

    private function cacheKey(string $csvPath, string $suffix): string {
        $base = basename($csvPath);
        $id = preg_replace('/[^a-zA-Z0-9_-]/', '_', $base);
        return CACHE_PATH . "/{$id}_{$suffix}.json";
    }
}
