<?php
declare(strict_types=1);

namespace App\Services;

use App\Models\DatasetStore;

final class ColumnProfileService
{
    /**
     * Returns a Kaggle-like profile for ONE column:
     * - missing stats
     * - inferred type (numeric/categorical)
     * - numeric stats + histogram OR categorical top values
     */
    public function profile(string $col, int $maxRows = 50000, int $bins = 18, int $top = 8): array
    {
        $col = trim($col);
        if ($col === '') {
            throw new \RuntimeException('Missing column name.');
        }

        $maxRows = max(1000, min(200000, $maxRows));
        $bins    = max(5, min(60, $bins));
        $top     = max(3, min(20, $top));

        $path = $this->resolveActiveDatasetPath();
        if (!is_file($path)) {
            throw new \RuntimeException('Dataset file not found on disk.');
        }

        $fh = fopen($path, 'rb');
        if (!$fh) {
            throw new \RuntimeException('Failed to open dataset file.');
        }

        $headers = fgetcsv($fh);
        if (!is_array($headers) || empty($headers)) {
            fclose($fh);
            throw new \RuntimeException('Invalid CSV header row.');
        }

        // Remove UTF-8 BOM if present
        $headers[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string)$headers[0]) ?? (string)$headers[0];

        $idx = array_search($col, $headers, true);
        if ($idx === false) {
            fclose($fh);
            throw new \RuntimeException("Column not found: {$col}");
        }

        $total = 0;
        $missing = 0;

        $numericValues = [];
        $numericCount  = 0;
        $nonNumericCount = 0;

        $catCounts = [];

        while (!feof($fh) && $total < $maxRows) {
            $row = fgetcsv($fh);
            if (!is_array($row)) continue;

            $total++;

            $raw = (string)($row[$idx] ?? '');
            $val = trim($raw);

            if ($val === '') {
                $missing++;
                continue;
            }

            // categorical counts always tracked
            $catCounts[$val] = ($catCounts[$val] ?? 0) + 1;

            if (is_numeric($val)) {
                $numericValues[] = (float)$val;
                $numericCount++;
            } else {
                $nonNumericCount++;
            }
        }

        fclose($fh);

        $nonMissing = $total - $missing;
        $missingPct = ($total > 0) ? round(($missing / $total) * 100, 2) : 0.0;

        // infer numeric if >= 90% of non-missing values are numeric
        $isNumeric = ($nonMissing > 0) && (($numericCount / $nonMissing) >= 0.90);

        $base = [
            'col' => $col,
            'total' => $total,
            'missing' => $missing,
            'missing_pct' => $missingPct,
            'type' => $isNumeric ? 'numeric' : 'categorical',
        ];

        if ($isNumeric) {
            sort($numericValues);
            $n = count($numericValues);

            if ($n === 0) {
                return $base + [
                    'numeric' => null,
                    'histogram' => ['labels' => [], 'counts' => []],
                ];
            }

            $min = $numericValues[0];
            $max = $numericValues[$n - 1];

            $mean = array_sum($numericValues) / $n;

            // std dev (sample)
            $var = 0.0;
            if ($n > 1) {
                foreach ($numericValues as $x) {
                    $var += ($x - $mean) ** 2;
                }
                $var /= ($n - 1);
            }
            $std = sqrt($var);

            $q1 = $this->quantile($numericValues, 0.25);
            $med = $this->quantile($numericValues, 0.50);
            $q3 = $this->quantile($numericValues, 0.75);

            // histogram
            [$labels, $counts] = $this->histogram($numericValues, $bins);

            return $base + [
                'numeric' => [
                    'count' => $n,
                    'mean' => $this->fmt($mean),
                    'std' => $this->fmt($std),
                    'min' => $this->fmt($min),
                    'q1' => $this->fmt($q1),
                    'median' => $this->fmt($med),
                    'q3' => $this->fmt($q3),
                    'max' => $this->fmt($max),
                ],
                'histogram' => [
                    'labels' => $labels,
                    'counts' => $counts,
                ],
            ];
        }

        // categorical
        arsort($catCounts);
        $unique = count($catCounts);

        $topItems = [];
        $i = 0;
        $topSum = 0;
        foreach ($catCounts as $k => $c) {
            $i++;
            if ($i <= $top) {
                $pct = ($nonMissing > 0) ? round(($c / $nonMissing) * 100, 2) : 0.0;
                $topItems[] = ['label' => $k, 'count' => $c, 'pct' => $pct];
                $topSum += $c;
            } else {
                break;
            }
        }

        $other = max(0, $nonMissing - $topSum);
        $otherPct = ($nonMissing > 0) ? round(($other / $nonMissing) * 100, 2) : 0.0;

        return $base + [
            'categorical' => [
                'unique' => $unique,
                'top' => $topItems,
                'other' => ['count' => $other, 'pct' => $otherPct],
            ],
        ];
    }

    private function resolveActiveDatasetPath(): string
    {
        $store = new DatasetStore();

        // Be tolerant to different method names
        $ds = null;
        if (method_exists($store, 'current')) $ds = $store->current();
        elseif (method_exists($store, 'active')) $ds = $store->active();
        elseif (method_exists($store, 'getActive')) $ds = $store->getActive();

        if (!is_array($ds)) {
            throw new \RuntimeException('No active dataset selected.');
        }

        $path = $ds['path'] ?? $ds['file_path'] ?? $ds['filepath'] ?? '';
        $path = (string)$path;

        if ($path === '') {
            throw new \RuntimeException('Active dataset path not found in DatasetStore.');
        }

        return $path;
    }

    private function quantile(array $sorted, float $p): float
    {
        $n = count($sorted);
        if ($n === 0) return 0.0;
        if ($n === 1) return (float)$sorted[0];

        $pos = ($n - 1) * $p;
        $lo = (int)floor($pos);
        $hi = (int)ceil($pos);

        if ($lo === $hi) return (float)$sorted[$lo];

        $w = $pos - $lo;
        return (float)$sorted[$lo] * (1.0 - $w) + (float)$sorted[$hi] * $w;
    }

    private function histogram(array $values, int $bins): array
    {
        $n = count($values);
        if ($n === 0) return [[], []];

        $min = $values[0];
        $max = $values[$n - 1];

        if ($min === $max) {
            return [[(string)$this->fmt($min)], [$n]];
        }

        $bins = max(5, $bins);
        $w = ($max - $min) / $bins;

        $counts = array_fill(0, $bins, 0);
        foreach ($values as $x) {
            $i = (int)floor(($x - $min) / $w);
            if ($i >= $bins) $i = $bins - 1;
            if ($i < 0) $i = 0;
            $counts[$i]++;
        }

        $labels = [];
        for ($i = 0; $i < $bins; $i++) {
            $a = $min + ($i * $w);
            $b = $min + (($i + 1) * $w);
            $labels[] = $this->fmt($a) . '–' . $this->fmt($b);
        }

        return [$labels, $counts];
    }

    private function fmt(float $v): string
    {
        return sprintf('%.5g', $v);
    }
}
