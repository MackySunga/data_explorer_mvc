<?php
declare(strict_types=1);

namespace App\Services;

final class PdfReportService
{
    private string $fpdfPath;

    public function __construct()
    {
        $this->fpdfPath = APP_PATH . '/Lib/fpdf/fpdf.php';

        if (!is_file($this->fpdfPath)) {
            throw new \RuntimeException(
                "Missing FPDF library. Put fpdf.php here: " . $this->fpdfPath
            );
        }

        if (!defined('FPDF_FONTPATH')) {
            define('FPDF_FONTPATH', APP_PATH . '/Lib/fpdf/font/');
        }

        require_once $this->fpdfPath;
    }

    /**
     * Streams a PDF to the browser.
     * IMPORTANT: For value consistency, PDF prints from ReportFormatService output (fmt),
     * not directly from $payload, EXCEPT regression tables which are attached into payload['regression'].
     */
    public function stream(array $payload, string $downloadName = 'report.pdf'): never
    {
        $formatter = new ReportFormatService();
        $fmt = $formatter->normalize($payload);

        $M = $fmt['meta'] ?? [];

        $pdf = new \FPDF('P', 'mm', 'A4');
        $pdf->SetAutoPageBreak(true, 12);
        $pdf->SetMargins(10, 10, 10);

        $datasetName = (string)($M['dataset_name'] ?? 'Dataset');
        $generatedAt = (string)($M['generated_at'] ?? '');
        $maxRows     = (string)($M['max_rows'] ?? '');

        // --- Cover / Summary page
        $pdf->AddPage('P');
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'Data Explorer Report', 0, 1);

        $pdf->SetFont('Arial', '', 11);
        $pdf->Cell(0, 6, "Dataset: {$datasetName}", 0, 1);
        $pdf->Cell(0, 6, "Generated: {$generatedAt}", 0, 1);
        $pdf->Cell(0, 6, "Max rows used: {$maxRows}", 0, 1);
        $pdf->Ln(2);

        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 8, 'Quick Summary', 0, 1);

        $pdf->SetFont('Arial', '', 11);
        $pdf->Cell(0, 6, 'Columns: ' . (int)($M['columns'] ?? 0), 0, 1);
        $pdf->Cell(0, 6, 'Numeric columns: ' . (int)($M['numeric_columns'] ?? 0), 0, 1);
        $pdf->Cell(0, 6, 'Categorical columns: ' . (int)($M['categorical_columns'] ?? 0), 0, 1);

        // --- Descriptive statistics
        $pdf->AddPage('P');
        $pdf->SetFont('Arial', 'B', 13);
        $pdf->Cell(0, 9, 'Descriptive Statistics', 0, 1);
        $pdf->Ln(1);

        $numericRows = is_array($fmt['stats_numeric'] ?? null) ? $fmt['stats_numeric'] : [];
        if (!empty($numericRows)) {
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(0, 8, 'Numeric Columns', 0, 1);

            $headers = ['Column','Count','Missing','Mean','Std','Min','Q1','Median','Q3','Max'];
            $widths  = [45,14,14,17,16,14,14,16,14,14];

            $this->tableHeader($pdf, $headers, $widths, 8, 9);

            $pdf->SetFont('Arial', '', 8);
            foreach ($numericRows as $r) {
                $row = [
                    (string)($r['column'] ?? ''),
                    (string)($r['count'] ?? ''),
                    (string)($r['missing'] ?? ''),
                    (string)($r['mean'] ?? ''),
                    (string)($r['std'] ?? ''),
                    (string)($r['min'] ?? ''),
                    (string)($r['q1'] ?? ''),
                    (string)($r['median'] ?? ''),
                    (string)($r['q3'] ?? ''),
                    (string)($r['max'] ?? ''),
                ];

                $this->tableRow($pdf, $row, $widths, 5);

                if ($pdf->GetY() > 270) {
                    $pdf->AddPage('P');
                    $this->tableHeader($pdf, $headers, $widths, 8, 9);
                    $pdf->SetFont('Arial', '', 8);
                }
            }
            $pdf->Ln(3);
        } else {
            $pdf->SetFont('Arial', '', 11);
            $pdf->MultiCell(0, 6, 'No numeric descriptive statistics found.');
            $pdf->Ln(2);
        }

        $catRows = is_array($fmt['stats_categorical'] ?? null) ? $fmt['stats_categorical'] : [];
        if (!empty($catRows)) {
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(0, 8, 'Categorical Columns', 0, 1);

            $headers = ['Column','Count','Missing','Unique','Top values (shown)'];
            $widths  = [55,18,18,18,81];

            $this->tableHeader($pdf, $headers, $widths, 8, 10);

            $pdf->SetFont('Arial', '', 8);
            foreach ($catRows as $r) {
                $row = [
                    (string)($r['column'] ?? ''),
                    (string)($r['count'] ?? ''),
                    (string)($r['missing'] ?? ''),
                    (string)($r['unique'] ?? ''),
                    (string)($r['top3'] ?? ''),
                ];

                $this->tableRowMultiLast($pdf, $row, $widths, 5);

                if ($pdf->GetY() > 270) {
                    $pdf->AddPage('P');
                    $this->tableHeader($pdf, $headers, $widths, 8, 10);
                    $pdf->SetFont('Arial', '', 8);
                }
            }
        } else {
            $pdf->SetFont('Arial', '', 11);
            $pdf->MultiCell(0, 6, 'No categorical descriptive statistics found.');
        }

        // --- Missing values
        $pdf->AddPage('P');
        $pdf->SetFont('Arial', 'B', 13);
        $pdf->Cell(0, 9, 'Missing Values', 0, 1);
        $pdf->Ln(1);

        $missingTop = is_array($fmt['missing_top'] ?? null) ? $fmt['missing_top'] : [];
        if (empty($missingTop)) {
            $pdf->SetFont('Arial', '', 11);
            $pdf->MultiCell(0, 6, 'No missing-values section found in formatted report.');
        } else {
            $headers = ['Column','Missing','Total','% Missing'];
            $widths  = [90,25,25,30];

            $this->tableHeader($pdf, $headers, $widths, 8, 10);

            $pdf->SetFont('Arial', '', 9);
            foreach ($missingTop as $r) {
                $row = [
                    (string)($r['column'] ?? ''),
                    (string)($r['missing'] ?? 0),
                    (string)($r['total'] ?? 0),
                    (string)($r['pct'] ?? ''),
                ];
                $this->tableRow($pdf, $row, $widths, 6);

                if ($pdf->GetY() > 270) {
                    $pdf->AddPage('P');
                    $this->tableHeader($pdf, $headers, $widths, 8, 10);
                    $pdf->SetFont('Arial', '', 9);
                }
            }

            $pdf->Ln(2);
            $pdf->SetFont('Arial', 'I', 9);
            $pdf->MultiCell(0, 5, 'Note: This table is rendered from the same formatted data as the HTML preview.');
        }

        // --- Outliers
        $pdf->AddPage('P');
        $pdf->SetFont('Arial', 'B', 13);
        $pdf->Cell(0, 9, 'Outliers', 0, 1);
        $pdf->Ln(1);

        $outliersTop = is_array($fmt['outliers_top'] ?? null) ? $fmt['outliers_top'] : [];
        if (empty($outliersTop)) {
            $pdf->SetFont('Arial', '', 11);
            $pdf->MultiCell(0, 6, 'No outliers section found in formatted report.');
        } else {
            $headers = ['Column','N','IQR outliers','Z outliers','IQR fences'];
            $widths  = [60,15,25,20,70];

            $this->tableHeader($pdf, $headers, $widths, 8, 10);
            $pdf->SetFont('Arial', '', 9);

            foreach ($outliersTop as $r) {
                $row = [
                    (string)($r['column'] ?? ''),
                    (string)($r['n'] ?? 0),
                    (string)($r['iqr_outliers'] ?? ''),
                    (string)($r['z_outliers'] ?? ''),
                    (string)($r['fence'] ?? ''),
                ];

                $this->tableRowMultiLast($pdf, $row, $widths, 6);

                if ($pdf->GetY() > 270) {
                    $pdf->AddPage('P');
                    $this->tableHeader($pdf, $headers, $widths, 8, 10);
                    $pdf->SetFont('Arial', '', 9);
                }
            }

            $pdf->Ln(2);
            $pdf->SetFont('Arial', 'I', 9);
            $pdf->MultiCell(0, 5, 'Note: This table is rendered from the same formatted data as the HTML preview.');
        }

        // --- Correlation matrix (Landscape)
        $pdf->AddPage('L');
        $pdf->SetFont('Arial', 'B', 13);
        $pdf->Cell(0, 9, 'Correlation Matrix (Pearson r)', 0, 1);
        $pdf->SetFont('Arial', '', 9);

        $corr = is_array($fmt['corr'] ?? null) ? $fmt['corr'] : [];
        $corrCols = is_array($corr['cols'] ?? null) ? $corr['cols'] : [];
        $corrMat  = is_array($corr['matrix'] ?? null) ? $corr['matrix'] : [];

        if (empty($corrCols) || empty($corrMat)) {
            $pdf->MultiCell(0, 6, 'No correlation matrix found in formatted report.');
        } else {
            $pdf->SetFont('Arial', 'B', 7);
            $cellW = 22;
            $cellH = 6;

            $pdf->Cell($cellW, $cellH, '', 1);
            foreach ($corrCols as $c) {
                $pdf->Cell($cellW, $cellH, $this->truncate((string)$c, 10), 1);
            }
            $pdf->Ln();

            $pdf->SetFont('Arial', '', 7);
            foreach ($corrMat as $i => $row) {
                $pdf->Cell($cellW, $cellH, $this->truncate((string)($corrCols[$i] ?? ''), 10), 1);
                foreach ($row as $v) {
                    $pdf->Cell($cellW, $cellH, (string)$v, 1);
                }
                $pdf->Ln();
            }

            $pdf->Ln(2);
            $pdf->SetFont('Arial', 'I', 9);
            $pdf->MultiCell(0, 5, 'Note: Correlation values and caps are rendered from the same formatted data as the HTML preview.');
        }

        // ============================================================
        // REGRESSION (OLS) TABLES (from payload['regression'])
        // ============================================================
        $reg = $payload['regression'] ?? null;
        if (is_array($reg) && !empty($reg['y']) && !empty($reg['x'])) {
            $pdf->AddPage('P');
            $pdf->SetFont('Arial', 'B', 13);
            $pdf->Cell(0, 9, 'Regression (OLS)', 0, 1);
            $pdf->Ln(1);

            $pdf->SetFont('Arial', '', 11);
            $pdf->MultiCell(0, 6, 'Dependent (Y): ' . (string)$reg['y']);
            $pdf->MultiCell(0, 6, 'Independent (X): ' . implode(', ', array_map('strval', (array)$reg['x'])));
            $pdf->Ln(1);

            // Regression stats
            $rs = is_array($reg['regression_stats'] ?? null) ? $reg['regression_stats'] : [];
            if (!empty($rs)) {
                $pdf->SetFont('Arial', 'B', 12);
                $pdf->Cell(0, 8, 'Regression Statistics', 0, 1);

                $headers = ['Metric', 'Value'];
                $widths  = [90, 100];
                $this->tableHeader($pdf, $headers, $widths, 10, 8);

                $pdf->SetFont('Arial', '', 10);

                $pairs = [
                    ['Multiple R', $rs['multiple_r'] ?? null],
                    ['R Square', $rs['r2'] ?? null],
                    ['Adjusted R Square', $rs['adj_r2'] ?? null],
                    ['Standard Error', $rs['std_error'] ?? null],
                    ['Observations', $rs['observations'] ?? null],
                ];

                foreach ($pairs as [$k, $v]) {
                    $val = is_numeric($v) ? sprintf('%.6g', (float)$v) : (string)($v ?? '');
                    $this->tableRow($pdf, [(string)$k, $val], $widths, 7);
                }

                $pdf->Ln(2);
            }

            // ANOVA
            $an = is_array($reg['anova'] ?? null) ? $reg['anova'] : [];
            if (!empty($an)) {
                $pdf->SetFont('Arial', 'B', 12);
                $pdf->Cell(0, 8, 'ANOVA (Analysis of Variance)', 0, 1);

                $headers = ['', 'df', 'SS', 'MS', 'F'];
                $widths  = [40, 18, 45, 45, 42];

                $this->tableHeader($pdf, $headers, $widths, 10, 8);
                $pdf->SetFont('Arial', '', 10);

                $this->tableRow($pdf, [
                    'Regression',
                    (string)($an['df_reg'] ?? ''),
                    is_numeric($an['ssr'] ?? null) ? sprintf('%.6g', (float)$an['ssr']) : (string)($an['ssr'] ?? ''),
                    is_numeric($an['msr'] ?? null) ? sprintf('%.6g', (float)$an['msr']) : (string)($an['msr'] ?? ''),
                    is_numeric($an['f'] ?? null) ? sprintf('%.6g', (float)$an['f']) : (string)($an['f'] ?? ''),
                ], $widths, 7);

                $this->tableRow($pdf, [
                    'Residual',
                    (string)($an['df_res'] ?? ''),
                    is_numeric($an['sse'] ?? null) ? sprintf('%.6g', (float)$an['sse']) : (string)($an['sse'] ?? ''),
                    is_numeric($an['mse'] ?? null) ? sprintf('%.6g', (float)$an['mse']) : (string)($an['mse'] ?? ''),
                    '',
                ], $widths, 7);

                $this->tableRow($pdf, [
                    'Total',
                    (string)($an['df_tot'] ?? ''),
                    is_numeric($an['sst'] ?? null) ? sprintf('%.6g', (float)$an['sst']) : (string)($an['sst'] ?? ''),
                    '',
                    '',
                ], $widths, 7);

                $pdf->Ln(2);
                $pdf->SetFont('Arial', 'I', 9);
                $pdf->MultiCell(0, 5, 'Note: P-values shown in the web UI may use a normal approximation.');
                $pdf->Ln(1);
            }

            // Coefficients
            $coef = is_array($reg['coefficients'] ?? null) ? $reg['coefficients'] : [];
            if (!empty($coef)) {
                $pdf->SetFont('Arial', 'B', 12);
                $pdf->Cell(0, 8, 'Coefficients', 0, 1);

                $headers = ['Term','Coef','Std Err','t','P','Lo 95%','Hi 95%'];
                $widths  = [45, 22, 22, 18, 18, 32, 33];

                $this->tableHeader($pdf, $headers, $widths, 9, 8);
                $pdf->SetFont('Arial', '', 9);

                foreach ($coef as $r) {
                    if (!is_array($r)) continue;

                    $row = [
                        (string)($r['name'] ?? ''),
                        is_numeric($r['coef'] ?? null) ? sprintf('%.6g', (float)$r['coef']) : (string)($r['coef'] ?? ''),
                        is_numeric($r['se'] ?? null) ? sprintf('%.6g', (float)$r['se']) : (string)($r['se'] ?? ''),
                        is_numeric($r['t'] ?? null) ? sprintf('%.6g', (float)$r['t']) : (string)($r['t'] ?? ''),
                        is_numeric($r['p'] ?? null) ? sprintf('%.6g', (float)$r['p']) : (string)($r['p'] ?? ''),
                        is_numeric($r['lo'] ?? null) ? sprintf('%.6g', (float)$r['lo']) : (string)($r['lo'] ?? ''),
                        is_numeric($r['hi'] ?? null) ? sprintf('%.6g', (float)$r['hi']) : (string)($r['hi'] ?? ''),
                    ];

                    $this->tableRow($pdf, $row, $widths, 6);

                    if ($pdf->GetY() > 270) {
                        $pdf->AddPage('P');
                        $this->tableHeader($pdf, $headers, $widths, 9, 8);
                        $pdf->SetFont('Arial', '', 9);
                    }
                }
            }
        }

        // --- Charts (embedded images)
        $charts = $payload['charts'] ?? [];
        if (is_array($charts) && !empty($charts)) {
            foreach ($charts as $ch) {
                if (!is_array($ch)) continue;

                $title = (string)($ch['title'] ?? 'Chart');
                $rel   = (string)($ch['path'] ?? '');

                if (!str_starts_with($rel, 'charts/')) continue;

                $imgPath = REPORTS_PATH . '/' . $rel;
                if (!is_file($imgPath)) continue;

                $pdf->AddPage('P');
                $pdf->SetFont('Arial', 'B', 13);
                $pdf->Cell(0, 9, $title, 0, 1);
                $pdf->Ln(2);

                $maxW = 190;
                $maxH = 240;

                $size = @getimagesize($imgPath);
                if (!is_array($size)) continue;

                $pxW = (int)$size[0];
                $pxH = (int)$size[1];
                if ($pxW <= 0 || $pxH <= 0) continue;

                $w = $maxW;
                $h = $w * ($pxH / $pxW);

                if ($h > $maxH) {
                    $h = $maxH;
                    $w = $h * ($pxW / $pxH);
                }

                $x = 10 + (($maxW - $w) / 2);
                $y = $pdf->GetY();

                $pdf->Image($imgPath, $x, $y, $w, 0);
            }
        }

        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $this->safeFilename($downloadName) . '"');
        $pdf->Output('D', $this->safeFilename($downloadName));
        exit;
    }

    private function truncate(string $s, int $max): string
    {
        $s = trim($s);
        if (mb_strlen($s) <= $max) return $s;
        return mb_substr($s, 0, $max - 1) . '…';
    }

    private function safeFilename(string $name): string
    {
        $name = preg_replace('/[^a-zA-Z0-9._-]/', '_', $name) ?? 'report.pdf';
        if (!str_ends_with(strtolower($name), '.pdf')) $name .= '.pdf';
        return $name;
    }

    private function tableHeader($pdf, array $headers, array $widths, int $fontSize = 9, int $rowH = 8): void
    {
        $pdf->SetFont('Arial', 'B', $fontSize);
        foreach ($headers as $i => $h) {
            $pdf->Cell($widths[$i], $rowH, $this->truncate((string)$h, 28), 1, 0);
        }
        $pdf->Ln();
    }

    private function tableRow($pdf, array $row, array $widths, int $rowH = 6): void
    {
        foreach ($row as $i => $txt) {
            $pdf->Cell($widths[$i], $rowH, $this->truncate((string)$txt, 70), 1, 0);
        }
        $pdf->Ln();
    }

    private function tableRowMultiLast($pdf, array $row, array $widths, int $rowH = 6): void
    {
        $n = count($row);
        $x0 = $pdf->GetX();
        $y0 = $pdf->GetY();

        $lastText = (string)$row[$n - 1];

        $lines = max(1, (int)ceil(mb_strlen($lastText) / 40));
        $h = $rowH * $lines;

        $x = $x0;
        for ($i = 0; $i < $n - 1; $i++) {
            $pdf->SetXY($x, $y0);
            $pdf->Cell($widths[$i], $h, $this->truncate((string)$row[$i], 70), 1, 0);
            $x += $widths[$i];
        }

        $pdf->SetXY($x, $y0);
        $pdf->MultiCell($widths[$n - 1], $rowH, $lastText, 1);

        $pdf->SetXY($x0, $y0 + $h);
    }
}
