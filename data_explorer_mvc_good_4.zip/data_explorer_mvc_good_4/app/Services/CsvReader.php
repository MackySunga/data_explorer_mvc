<?php
declare(strict_types=1);

namespace App\Services;

final class CsvReader
{
    public function readHeader(string $path): array {
        [$fh, $delim] = $this->open($path);
        $row = fgetcsv($fh, 0, $delim);
        fclose($fh);

        if (!is_array($row)) return [];
        return array_map(fn($h) => trim((string)$h), $row);
    }

    public function iterate(string $path, int $limit = 0, int $offset = 0): \Generator {
        [$fh, $delim] = $this->open($path);

        $header = fgetcsv($fh, 0, $delim);
        if (!is_array($header)) {
            fclose($fh);
            return;
        }
        $header = array_map(fn($h) => trim((string)$h), $header);

        $i = 0;
        $yielded = 0;

        while (($row = fgetcsv($fh, 0, $delim)) !== false) {
            if ($offset > 0 && $i < $offset) { $i++; continue; }

            $assoc = [];
            foreach ($header as $k => $col) {
                $assoc[$col] = isset($row[$k]) ? (string)$row[$k] : '';
            }

            yield $assoc;

            $i++;
            $yielded++;
            if ($limit > 0 && $yielded >= $limit) break;
        }

        fclose($fh);
    }

    private function open(string $path): array {
        $fh = fopen($path, 'rb');
        if (!$fh) {
            throw new \RuntimeException("Cannot open CSV: $path");
        }

        $first = fgets($fh);
        if ($first === false) $first = '';
        rewind($fh);

        $delims = [',', ';', "\t", '|'];
        $best = ',';
        $bestCount = -1;
        foreach ($delims as $d) {
            $c = substr_count($first, $d);
            if ($c > $bestCount) { $bestCount = $c; $best = $d; }
        }

        return [$fh, $best];
    }
}
