<?php
declare(strict_types=1);

namespace App\Services;

final class ChartImageService
{
    /**
     * Accepts a PNG data URL (data:image/png;base64,....), validates, saves to disk, returns filename only.
     */
    public function savePngDataUrl(string $dataUrl, string $destDir, string $baseName): string
    {
        if (!str_starts_with($dataUrl, 'data:image/png;base64,')) {
            throw new \RuntimeException('Chart image must be a PNG data URL.');
        }

        $b64 = substr($dataUrl, strlen('data:image/png;base64,'));
        $bin = base64_decode($b64, true);
        if ($bin === false) {
            throw new \RuntimeException('Invalid base64 image data.');
        }

        // Basic size limit (per chart)
        $maxBytes = 6 * 1024 * 1024; // 6MB
        if (strlen($bin) > $maxBytes) {
            throw new \RuntimeException('Chart image too large (max 6MB).');
        }

        // PNG signature check
        $sig = substr($bin, 0, 8);
        if ($sig !== "\x89PNG\r\n\x1a\n") {
            throw new \RuntimeException('Invalid PNG signature.');
        }

        if (!is_dir($destDir)) {
            if (!mkdir($destDir, 0775, true) && !is_dir($destDir)) {
                throw new \RuntimeException('Failed to create charts directory.');
            }
        }

        $safeBase = preg_replace('/[^a-zA-Z0-9._-]/', '_', $baseName) ?? 'chart';
        $rand = bin2hex(random_bytes(4));
        $filename = $safeBase . '_' . $rand . '.png';
        $path = rtrim($destDir, '/\\') . DIRECTORY_SEPARATOR . $filename;

        if (file_put_contents($path, $bin, LOCK_EX) === false) {
            throw new \RuntimeException('Failed to save chart image.');
        }

        return $filename;
    }
}
