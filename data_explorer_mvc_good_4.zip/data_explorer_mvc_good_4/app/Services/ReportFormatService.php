<?php
declare(strict_types=1);

namespace App\Services;

final class ReportFormatService
{
    public const CORR_CAP = 20;
    public const MISSING_CAP = 35;
    public const OUTLIER_CAP = 35;
    public const CAT_TOP_SHOWN = 5;

    public function normalize(array $payload): array
    {
        $datasetName = (string)($payload['dataset']['name'] ?? 'Dataset');
        $generatedAt = (string)($payload['generated_at'] ?? '');
        $maxRows     = (int)($payload['max_rows'] ?? 0);

        $summary = is_array($payload['summary'] ?? null) ? $payload['summary'] : [];
        $cols    = is_array($summary['columns'] ?? null) ? $summary['columns'] : [];
        $types   = is_array($summary['types'] ?? null) ? $summary['types'] : [];
        $stats   = is_array($summary['stats'] ?? null) ? $summary['stats'] : [];

        $numericCount = 0;
        foreach ($cols as $c) {
            if (($types[$c] ?? '') === 'numeric') $numericCount++;
        }

        // ----- Stats
        $numericRows = [];
        $catRows = [];

        foreach ($stats as $col => $s) {
            $type = (string)($s['type'] ?? '');
            if ($type === 'numeric') {
                $numericRows[] = [
                    'column' => (string)$col,
                    'count' => (int)($s['count'] ?? 0),
                    'missing' => (int)($s['missing'] ?? 0),
                    'mean' => $this->fmt($s['mean'] ?? null),
                    'std' => $this->fmt($s['std'] ?? null),
                    'min' => $this->fmt($s['min'] ?? null),
                    'q1' => $this->fmt($s['q1'] ?? null),
                    'median' => $this->fmt($s['median'] ?? null),
                    'q3' => $this->fmt($s['q3'] ?? null),
                    'max' => $this->fmt($s['max'] ?? null),
                ];
            } else {
                $top = is_array($s['top'] ?? null) ? $s['top'] : [];
                $pairs = [];
                $i = 0;
                foreach ($top as $k => $v) {
                    $pairs[] = (string)$k . ' (' . (int)$v . ')';
                    $i++;
                    if ($i >= self::CAT_TOP_SHOWN) break;
                }

                $catRows[] = [
                    'column' => (string)$col,
                    'count' => (int)($s['count'] ?? 0),
                    'missing' => (int)($s['missing'] ?? 0),
                    'unique' => (int)($s['unique'] ?? 0),
                    // IMPORTANT: your view uses top3
                    'top3' => implode(', ', $pairs),
                ];
            }
        }

        // ----- Missing (sort desc by pct, cap)
        $missing = is_array($payload['missing'] ?? null) ? $payload['missing'] : [];
        uasort($missing, fn($a, $b) => (float)($b['pct'] ?? 0) <=> (float)($a['pct'] ?? 0));

        $missingTop = [];
        $count = 0;
        foreach ($missing as $col => $m) {
            $missingTop[] = [
                'column' => (string)$col,
                'missing' => (int)($m['missing'] ?? 0),
                'total' => (int)($m['total'] ?? 0),
                'pct' => sprintf('%.2f%%', (float)($m['pct'] ?? 0)),
            ];
            $count++;
            if ($count >= self::MISSING_CAP) break;
        }

        // ----- Outliers (sort desc by iqr_outliers, cap)
        $outliers = is_array($payload['outliers'] ?? null) ? $payload['outliers'] : [];
        uasort($outliers, fn($a, $b) => (int)($b['iqr_outliers'] ?? 0) <=> (int)($a['iqr_outliers'] ?? 0));

        $outlierTop = [];
        $count = 0;
        foreach ($outliers as $col => $s) {
            $fence = '';
            if (($s['iqr_outliers'] ?? null) !== null) {
                $fence = '[' . $this->fmt($s['low_fence'] ?? null) . ', ' . $this->fmt($s['high_fence'] ?? null) . ']';
            }

            $outlierTop[] = [
                'column' => (string)$col,
                'n' => (int)($s['n'] ?? 0),
                'iqr_outliers' => ($s['iqr_outliers'] ?? null) === null ? '' : (string)(int)$s['iqr_outliers'],
                'z_outliers' => ($s['z_outliers'] ?? null) === null ? '' : (string)(int)$s['z_outliers'],
                'fence' => $fence,
            ];
            $count++;
            if ($count >= self::OUTLIER_CAP) break;
        }

        // ----- Correlation (cap + format to 3 decimals)
        $corr = is_array($payload['correlation'] ?? null) ? $payload['correlation'] : [];
        $corrCols = is_array($corr['cols'] ?? null) ? $corr['cols'] : [];
        $corrMat  = is_array($corr['matrix'] ?? null) ? $corr['matrix'] : [];

        $corrCols = array_slice($corrCols, 0, self::CORR_CAP);
        $corrMat = array_slice($corrMat, 0, self::CORR_CAP);

        $corrMatFmt = [];
        foreach ($corrMat as $row) {
            $row = is_array($row) ? array_slice($row, 0, self::CORR_CAP) : [];
            $fmtRow = [];
            foreach ($row as $v) {
                $fmtRow[] = ($v === null) ? '' : sprintf('%.3f', (float)$v);
            }
            $corrMatFmt[] = $fmtRow;
        }

        return [
            'meta' => [
                'dataset_name' => $datasetName,
                'generated_at' => $generatedAt,
                'max_rows' => $maxRows,
                'columns' => count($cols),
                'numeric_columns' => $numericCount,
                'categorical_columns' => count($cols) - $numericCount,
            ],
            'stats_numeric' => $numericRows,
            'stats_categorical' => $catRows,
            'missing_top' => $missingTop,
            'outliers_top' => $outlierTop,
            'corr' => [
                // IMPORTANT: your view prints corr['cap']
                'cap' => self::CORR_CAP,
                'cols' => $corrCols,
                'matrix' => $corrMatFmt,
            ],
        ];
    }

    private function fmt($v): string
    {
        if ($v === null || $v === '') return '';
        if (!is_numeric($v)) return (string)$v;
        return sprintf('%.5g', (float)$v);
    }
}
