<?php
declare(strict_types=1);

namespace App\Services;

final class FilterEngine
{
    /**
     * @param array<string,mixed> $row
     * @param string $q Global search query (search across all columns)
     * @param array<string,string> $contains Legacy per-column contains filters (optional)
     * @param array<string,string> $fOp Per-column operator: contains|equals|range
     * @param array<string,string> $fV1 Per-column value (or min for range)
     * @param array<string,string> $fV2 Per-column max (for range)
     */
    public function match(
        array $row,
        string $q = '',
        array $contains = [],
        array $fOp = [],
        array $fV1 = [],
        array $fV2 = []
    ): bool {
        // ---- Global search (Kaggle-like "Search rows")
        $q = trim($q);
        if ($q !== '') {
            $needle = mb_strtolower($q);
            $found = false;

            foreach ($row as $v) {
                $s = trim((string)$v);
                if ($s === '') continue;
                if (mb_stripos($s, $needle) !== false) {
                    $found = true;
                    break;
                }
            }
            if (!$found) return false;
        }

        // ---- Legacy per-column contains (still supported)
        foreach ($contains as $col => $needleRaw) {
            $needleRaw = (string)$needleRaw;
            $needle = trim($needleRaw);
            if ($needle === '') continue;

            $cell = trim((string)($row[$col] ?? ''));
            if ($cell === '') return false;
            if (mb_stripos($cell, $needle) === false) return false;
        }

        // ---- New Kaggle-like per-column filters
        foreach ($fOp as $col => $opRaw) {
            $op = strtolower(trim((string)$opRaw));
            if ($op === '' || $op === 'none') continue;

            $cellRaw = (string)($row[$col] ?? '');
            $cell = trim($cellRaw);

            // Treat blank cell as "missing"
            if ($cell === '') {
                return false;
            }

            if ($op === 'contains') {
                $needle = trim((string)($fV1[$col] ?? ''));
                if ($needle === '') continue;
                if (mb_stripos($cell, $needle) === false) return false;
                continue;
            }

            if ($op === 'equals') {
                $target = trim((string)($fV1[$col] ?? ''));
                if ($target === '') continue;
                if (mb_strtolower($cell) !== mb_strtolower($target)) return false;
                continue;
            }

            if ($op === 'range') {
                $minRaw = trim((string)($fV1[$col] ?? ''));
                $maxRaw = trim((string)($fV2[$col] ?? ''));

                // If both blank, ignore filter
                if ($minRaw === '' && $maxRaw === '') continue;

                if (!is_numeric($cell)) return false;
                $x = (float)$cell;

                if ($minRaw !== '') {
                    if (!is_numeric($minRaw)) return false;
                    if ($x < (float)$minRaw) return false;
                }
                if ($maxRaw !== '') {
                    if (!is_numeric($maxRaw)) return false;
                    if ($x > (float)$maxRaw) return false;
                }
                continue;
            }

            // Unknown operator: ignore (safe)
        }

        return true;
    }
}
