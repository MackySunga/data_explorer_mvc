<?php
declare(strict_types=1);

namespace App\Services;

final class RegressionService
{
    private CsvReader $csv;

    public function __construct(?CsvReader $csv = null)
    {
        $this->csv = $csv ?? new CsvReader();
    }

    /**
     * Ordinary Least Squares (OLS) with intercept.
     * - Drops rows with missing/non-numeric values in Y or any X.
     * - P-values use normal approximation (good when n is large).
     */
    public function ols(
        string $csvPath,
        string $yCol,
        array $xCols,
        int $maxRows = 50000,
        int $diagPoints = 2000
    ): array {
        $xCols = array_values(array_filter($xCols, fn($c) => trim((string)$c) !== ''));
        if ($yCol === '' || empty($xCols)) {
            throw new \InvalidArgumentException('Select a dependent (Y) and at least one independent (X).');
        }

        $X = []; // rows of [1, x1, x2...]
        $y = [];

        $nSeen = 0;
        foreach ($this->csv->iterate($csvPath, 0, 0) as $row) {
            if ($nSeen >= $maxRows) break;
            $nSeen++;

            $yv = $this->numOrNull($row[$yCol] ?? null);
            if ($yv === null) continue;

            $xr = [1.0];
            $ok = true;
            foreach ($xCols as $c) {
                $vv = $this->numOrNull($row[$c] ?? null);
                if ($vv === null) { $ok = false; break; }
                $xr[] = $vv;
            }
            if (!$ok) continue;

            $X[] = $xr;
            $y[] = $yv;
        }

        $n = count($y);
        $p = count($xCols);        // number of predictors
        $k = $p + 1;               // predictors + intercept

        if ($n < ($k + 2)) {
            throw new \RuntimeException("Not enough valid rows after dropping missing/non-numeric. Need at least " . ($k + 2) . ", got {$n}.");
        }

        // Build XtX and Xty incrementally (faster than full matmul)
        $XtX = array_fill(0, $k, array_fill(0, $k, 0.0));
        $Xty = array_fill(0, $k, 0.0);

        for ($i = 0; $i < $n; $i++) {
            $xi = $X[$i];
            $yi = $y[$i];

            for ($a = 0; $a < $k; $a++) {
                $Xty[$a] += $xi[$a] * $yi;
                for ($b = 0; $b < $k; $b++) {
                    $XtX[$a][$b] += $xi[$a] * $xi[$b];
                }
            }
        }

        $invXtX = $this->invert($XtX);

        // beta = inv(XtX) * Xty
        $beta = array_fill(0, $k, 0.0);
        for ($a = 0; $a < $k; $a++) {
            $s = 0.0;
            for ($b = 0; $b < $k; $b++) $s += $invXtX[$a][$b] * $Xty[$b];
            $beta[$a] = $s;
        }

        // yhat, residuals, SSE, meanY, SST
        $sumY = array_sum($y);
        $meanY = $sumY / $n;

        $yhat = [];
        $res  = [];
        $SSE  = 0.0;
        $SST  = 0.0;

        for ($i = 0; $i < $n; $i++) {
            $pred = 0.0;
            for ($j = 0; $j < $k; $j++) $pred += $X[$i][$j] * $beta[$j];

            $yhat[$i] = $pred;
            $e = $y[$i] - $pred;
            $res[$i] = $e;

            $SSE += $e * $e;
            $dy = $y[$i] - $meanY;
            $SST += $dy * $dy;
        }

        $SSR = max(0.0, $SST - $SSE);

        $dfReg = $p;
        $dfRes = $n - $k;
        $dfTot = $n - 1;

        $MSR = ($dfReg > 0) ? ($SSR / $dfReg) : 0.0;
        $MSE = ($dfRes > 0) ? ($SSE / $dfRes) : 0.0;

        $F = ($MSE > 0 && $dfReg > 0) ? ($MSR / $MSE) : 0.0;

        $r2 = ($SST > 0) ? ($SSR / $SST) : 0.0;
        $multipleR = sqrt(max(0.0, $r2));

        $adjR2 = ($dfRes > 0 && $SST > 0)
            ? (1.0 - (1.0 - $r2) * (($n - 1) / $dfRes))
            : 0.0;

        $stdErr = ($MSE > 0) ? sqrt($MSE) : 0.0;

        // Var(beta) = MSE * invXtX
        $seBeta = array_fill(0, $k, 0.0);
        for ($j = 0; $j < $k; $j++) {
            $seBeta[$j] = ($MSE > 0) ? sqrt(max(0.0, $MSE * $invXtX[$j][$j])) : 0.0;
        }

        // t stats, p-values (normal approx), 95% CI (normal approx)
        $zCrit = 1.959963984540054; // approx for 0.975
        $coefRows = [];

        $names = array_merge(['Intercept'], $xCols);
        for ($j = 0; $j < $k; $j++) {
            $b = $beta[$j];
            $se = $seBeta[$j];
            $t = ($se > 0) ? ($b / $se) : 0.0;
            $pval = $this->pTwoTailNormalApprox($t); // good for large n

            $ciLo = $b - $zCrit * $se;
            $ciHi = $b + $zCrit * $se;

            $coefRows[] = [
                'name' => $names[$j] ?? ('X' . $j),
                'coef' => $b,
                'se'   => $se,
                't'    => $t,
                'p'    => $pval,
                'lo'   => $ciLo,
                'hi'   => $ciHi,
            ];
        }

        // Diagnostics sampling
        $diag = $this->buildDiagnostics($X, $res, $yhat, $invXtX, $MSE, $k, $diagPoints);

        return [
            'meta' => [
                'n' => $n,
                'p' => $p,
                'y' => $yCol,
                'x' => $xCols,
            ],
            'regression_stats' => [
                'multiple_r' => $multipleR,
                'r2'         => $r2,
                'adj_r2'     => $adjR2,
                'std_error'  => $stdErr,
                'observations' => $n,
            ],
            'anova' => [
                'df_reg' => $dfReg,
                'df_res' => $dfRes,
                'df_tot' => $dfTot,
                'ssr' => $SSR,
                'sse' => $SSE,
                'sst' => $SST,
                'msr' => $MSR,
                'mse' => $MSE,
                'f'   => $F,
            ],
            'coefficients' => $coefRows,
            'diagnostics' => $diag,
        ];
    }

    private function numOrNull($v): ?float
    {
        $s = trim((string)$v);
        if ($s === '') return null;

        // strip commas (e.g., "1,234.56")
        $s = str_replace(',', '', $s);

        if (!is_numeric($s)) return null;
        return (float)$s;
    }

    private function pTwoTailNormalApprox(float $t): float
    {
        // two-tailed p ~= 2*(1 - Phi(|t|))
        $z = abs($t);
        $phi = $this->normalCdf($z);
        $p = 2.0 * (1.0 - $phi);
        if ($p < 0.0) $p = 0.0;
        if ($p > 1.0) $p = 1.0;
        return $p;
    }

    private function normalCdf(float $z): float
    {
        // Abramowitz & Stegun approximation
        $t = 1.0 / (1.0 + 0.2316419 * abs($z));
        $d = 0.3989423 * exp(-$z * $z / 2.0);
        $p = $d * $t * (0.3193815 + $t * (-0.3565638 + $t * (1.781478 + $t * (-1.821256 + $t * 1.330274))));
        $cdf = ($z >= 0) ? (1.0 - $p) : $p;
        return $cdf;
    }

    private function buildDiagnostics(array $X, array $res, array $yhat, array $invXtX, float $MSE, int $k, int $diagPoints): array
    {
        $n = count($res);
        $diagPoints = max(200, min($diagPoints, $n));

        // sample indices evenly
        $idx = [];
        if ($n <= $diagPoints) {
            for ($i = 0; $i < $n; $i++) $idx[] = $i;
        } else {
            for ($t = 0; $t < $diagPoints; $t++) {
                $i = (int)floor(($t / ($diagPoints - 1)) * ($n - 1));
                $idx[] = $i;
            }
        }

        $fitted = [];
        $resid  = [];
        $cooks  = [];

        // Leverage + Cook’s D on sampled points
        foreach ($idx as $i) {
            $xi = $X[$i];

            // h_ii = x_i^T * invXtX * x_i
            $tmp = array_fill(0, $k, 0.0);
            for ($a = 0; $a < $k; $a++) {
                $s = 0.0;
                for ($b = 0; $b < $k; $b++) $s += $invXtX[$a][$b] * $xi[$b];
                $tmp[$a] = $s;
            }
            $h = 0.0;
            for ($a = 0; $a < $k; $a++) $h += $xi[$a] * $tmp[$a];

            $e = $res[$i];
            $f = $yhat[$i];

            $D = 0.0;
            if ($MSE > 0 && $h < 1.0) {
                $D = (($e * $e) / ($k * $MSE)) * ($h / ((1.0 - $h) * (1.0 - $h)));
            }

            $fitted[] = $f;
            $resid[]  = $e;
            $cooks[]  = $D;
        }

        // Q-Q plot: standardized residuals (sample)
        $std = [];
        for ($i = 0; $i < $n; $i++) $std[] = $res[$i];
        sort($std);

        $qqX = [];
        $qqY = [];

        $m = count($std);
        $qqCount = min($diagPoints, $m);
        for ($t = 0; $t < $qqCount; $t++) {
            $i = (int)floor(($t / ($qqCount - 1)) * ($m - 1));
            $p = (($i + 0.5) / $m);
            $z = $this->normalInv($p);
            $qqX[] = $z;
            $qqY[] = $std[$i];
        }

        return [
            'fitted' => $fitted,
            'residuals' => $resid,
            'cooks' => $cooks,
            'qq_x' => $qqX,
            'qq_y' => $qqY,
        ];
    }

    // Acklam’s inverse normal CDF approximation
    private function normalInv(float $p): float
    {
        if ($p <= 0.0) return -INF;
        if ($p >= 1.0) return INF;

        $a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00];
        $b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01, -1.328068155288572e+01];
        $c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00];
        $d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00];

        $plow = 0.02425;
        $phigh = 1 - $plow;

        if ($p < $plow) {
            $q = sqrt(-2 * log($p));
            return ((((( $c[0]*$q + $c[1])*$q + $c[2])*$q + $c[3])*$q + $c[4])*$q + $c[5]) /
                   (((( $d[0]*$q + $d[1])*$q + $d[2])*$q + $d[3])*$q + 1);
        }

        if ($p > $phigh) {
            $q = sqrt(-2 * log(1 - $p));
            return -((((( $c[0]*$q + $c[1])*$q + $c[2])*$q + $c[3])*$q + $c[4])*$q + $c[5]) /
                     (((( $d[0]*$q + $d[1])*$q + $d[2])*$q + $d[3])*$q + 1);
        }

        $q = $p - 0.5;
        $r = $q * $q;
        return ((((( $a[0]*$r + $a[1])*$r + $a[2])*$r + $a[3])*$r + $a[4])*$r + $a[5]) * $q /
               ((((( $b[0]*$r + $b[1])*$r + $b[2])*$r + $b[3])*$r + $b[4])*$r + 1);
    }

    private function invert(array $A): array
    {
        $n = count($A);
        if ($n === 0 || count($A[0]) !== $n) {
            throw new \RuntimeException('Matrix must be square for inversion.');
        }

        // Augment with identity
        $M = [];
        for ($i = 0; $i < $n; $i++) {
            $M[$i] = array_values($A[$i]);
            for ($j = 0; $j < $n; $j++) {
                $M[$i][] = ($i === $j) ? 1.0 : 0.0;
            }
        }

        $m2 = 2 * $n;

        for ($col = 0; $col < $n; $col++) {
            // pivot
            $pivot = $col;
            $max = abs($M[$col][$col]);
            for ($r = $col + 1; $r < $n; $r++) {
                $v = abs($M[$r][$col]);
                if ($v > $max) { $max = $v; $pivot = $r; }
            }
            if ($max < 1e-12) {
                throw new \RuntimeException('Matrix is singular (cannot invert).');
            }
            if ($pivot !== $col) {
                $tmp = $M[$col]; $M[$col] = $M[$pivot]; $M[$pivot] = $tmp;
            }

            // normalize pivot row
            $pv = $M[$col][$col];
            for ($c = 0; $c < $m2; $c++) $M[$col][$c] /= $pv;

            // eliminate other rows
            for ($r = 0; $r < $n; $r++) {
                if ($r === $col) continue;
                $factor = $M[$r][$col];
                if (abs($factor) < 1e-18) continue;
                for ($c = 0; $c < $m2; $c++) {
                    $M[$r][$c] -= $factor * $M[$col][$c];
                }
            }
        }

        // extract right half
        $inv = [];
        for ($i = 0; $i < $n; $i++) {
            $inv[$i] = array_slice($M[$i], $n, $n);
        }
        return $inv;
    }
}
