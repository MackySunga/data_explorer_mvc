<?php
declare(strict_types=1);

namespace App\Services;

final class Profiler
{
    public function inferTypes(array $rows, array $columns): array {
        $types = array_fill_keys($columns, 'categorical');
        $numericScore = array_fill_keys($columns, 0);
        $seen = array_fill_keys($columns, 0);

        foreach ($rows as $row) {
            foreach ($columns as $c) {
                $v = trim((string)($row[$c] ?? ''));
                if ($v === '') continue;
                $seen[$c]++;

                if (is_numeric($v)) $numericScore[$c]++;
            }
        }

        foreach ($columns as $c) {
            if (($seen[$c] ?? 0) > 0) {
                $ratio = ($numericScore[$c] ?? 0) / max(1, $seen[$c]);
                $types[$c] = ($ratio >= 0.9) ? 'numeric' : 'categorical';
            }
        }

        return $types;
    }
}
