<?php
declare(strict_types=1);

namespace App\Services;

final class InsightService
{
    private CsvReader $csv;

    public function __construct() {
        $this->csv = new CsvReader();
    }

    /**
     * Pearson correlation matrix using pairwise deletion.
     * Stores per-pair sums so results are correct (still fast for typical column counts).
     */
    public function correlationMatrix(string $csvPath, array $numericCols, int $maxRows = 50000): array {
        $p = count($numericCols);
        if ($p === 0) return ['cols' => [], 'matrix' => []];

        // Per-pair accumulators (only for i<=j)
        $n   = array_fill(0, $p, array_fill(0, $p, 0));
        $sx  = array_fill(0, $p, array_fill(0, $p, 0.0));
        $sy  = array_fill(0, $p, array_fill(0, $p, 0.0));
        $sxx = array_fill(0, $p, array_fill(0, $p, 0.0));
        $syy = array_fill(0, $p, array_fill(0, $p, 0.0));
        $sxy = array_fill(0, $p, array_fill(0, $p, 0.0));

        $iRow = 0;
        foreach ($this->csv->iterate($csvPath, $maxRows, 0) as $row) {
            $vals = array_fill(0, $p, null);

            for ($i=0; $i<$p; $i++) {
                $c = $numericCols[$i];
                $v = trim((string)($row[$c] ?? ''));
                if ($v === '' || !is_numeric($v)) continue;
                $vals[$i] = (float)$v;
            }

            for ($i=0; $i<$p; $i++) {
                if ($vals[$i] === null) continue;
                for ($j=$i; $j<$p; $j++) {
                    if ($vals[$j] === null) continue;

                    $x = $vals[$i];
                    $y = $vals[$j];

                    $n[$i][$j] += 1;
                    $sx[$i][$j] += $x;
                    $sy[$i][$j] += $y;
                    $sxx[$i][$j] += $x*$x;
                    $syy[$i][$j] += $y*$y;
                    $sxy[$i][$j] += $x*$y;
                }
            }

            $iRow++;
            if ($iRow >= $maxRows) break;
        }

        $matrix = [];
        for ($i=0; $i<$p; $i++) {
            $rowCorr = [];
            for ($j=0; $j<$p; $j++) {
                if ($i === $j) { $rowCorr[] = 1.0; continue; }

                $a = min($i, $j);
                $b = max($i, $j);
                $nn = $n[$a][$b];

                if ($nn < 3) { $rowCorr[] = null; continue; }

                // r = (n*sxy - sx*sy) / sqrt((n*sxx - sx^2)(n*syy - sy^2))
                $num = ($nn * $sxy[$a][$b]) - ($sx[$a][$b] * $sy[$a][$b]);
                $denA = ($nn * $sxx[$a][$b]) - ($sx[$a][$b] ** 2);
                $denB = ($nn * $syy[$a][$b]) - ($sy[$a][$b] ** 2);
                $den = ($denA > 0 && $denB > 0) ? sqrt($denA * $denB) : 0.0;

                $rowCorr[] = ($den > 0) ? ($num / $den) : null;
            }
            $matrix[] = $rowCorr;
        }

        return ['cols' => $numericCols, 'matrix' => $matrix];
    }

    /** Missing counts + % per column */
    public function missingByColumn(string $csvPath, array $columns, int $maxRows = 50000): array {
        $missing = array_fill_keys($columns, 0);
        $total = 0;

        foreach ($this->csv->iterate($csvPath, $maxRows, 0) as $row) {
            foreach ($columns as $c) {
                $v = trim((string)($row[$c] ?? ''));
                if ($v === '') $missing[$c] += 1;
            }
            $total++;
        }

        $out = [];
        foreach ($columns as $c) {
            $m = $missing[$c] ?? 0;
            $out[$c] = [
                'missing' => $m,
                'total' => $total,
                'pct' => $total > 0 ? ($m / $total) * 100.0 : 0.0,
            ];
        }
        return $out;
    }

    /** Outlier summary using IQR + z-score */
    public function outlierSummary(string $csvPath, array $numericCols, int $maxRows = 50000): array {
        $values = [];
        foreach ($numericCols as $c) $values[$c] = [];

        foreach ($this->csv->iterate($csvPath, $maxRows, 0) as $row) {
            foreach ($numericCols as $c) {
                $v = trim((string)($row[$c] ?? ''));
                if ($v === '' || !is_numeric($v)) continue;
                $values[$c][] = (float)$v;
            }
        }

        $summary = [];
        foreach ($numericCols as $c) {
            $arr = $values[$c];
            sort($arr);
            $n = count($arr);

            if ($n < 10) {
                $summary[$c] = ['n' => $n, 'iqr_outliers' => null, 'z_outliers' => null];
                continue;
            }

            $q1 = $this->percentile($arr, 25);
            $q3 = $this->percentile($arr, 75);
            $iqr = $q3 - $q1;
            $low = $q1 - 1.5*$iqr;
            $high = $q3 + 1.5*$iqr;

            $mean = array_sum($arr) / $n;
            $std = $this->std($arr, $mean);

            $iqrOut = 0;
            $zOut = 0;
            foreach ($arr as $x) {
                if ($x < $low || $x > $high) $iqrOut++;
                if ($std > 0 && abs(($x - $mean)/$std) > 3.0) $zOut++;
            }

            $summary[$c] = [
                'n' => $n,
                'q1' => $q1, 'q3' => $q3, 'iqr' => $iqr,
                'low_fence' => $low, 'high_fence' => $high,
                'mean' => $mean, 'std' => $std,
                'iqr_outliers' => $iqrOut,
                'z_outliers' => $zOut,
            ];
        }

        return $summary;
    }

    private function percentile(array $sorted, float $p): float {
        $n = count($sorted);
        if ($n === 0) return 0.0;
        $idx = ($p/100) * ($n - 1);
        $lo = (int)floor($idx);
        $hi = (int)ceil($idx);
        if ($lo === $hi) return (float)$sorted[$lo];
        $w = $idx - $lo;
        return (1-$w) * (float)$sorted[$lo] + $w * (float)$sorted[$hi];
    }

    private function std(array $nums, float $mean): float {
        $n = count($nums);
        if ($n < 2) return 0.0;
        $ss = 0.0;
        foreach ($nums as $x) $ss += ($x - $mean) ** 2;
        return sqrt($ss / ($n - 1));
    }
}
