<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/app/bootstrap.php';

use App\Controllers\DatasetController;
use App\Controllers\ExploreController;
use App\Controllers\ApiController;


$route = (string)($_GET['r'] ?? 'dataset/upload');

$dataset = new DatasetController();
$explore = new ExploreController();
$api     = new ApiController();

switch ($route) {
    // dataset management
    case 'dataset/upload':   $dataset->upload(); break;
    case 'dataset/list':     $dataset->list(); break;
    case 'dataset/delete':   $dataset->delete(); break;
    case 'dataset/download': $dataset->download(); break;

    // exploration pages
    case 'explore/table':     $explore->table(); break;
    case 'explore/stats':     $explore->stats(); break;
    case 'explore/visualize': $explore->visualize(); break;
    case 'explore/correlation': $explore->correlation(); break;
    case 'explore/missing':     $explore->missing(); break;
    case 'explore/outliers':    $explore->outliers(); break;

    // reports
    case 'explore/reports':        $explore->reports(); break;
    case 'explore/report_save':    $explore->reportSave(); break;
    case 'explore/report_view':    $explore->reportView(); break;
    case 'explore/report_download':$explore->reportDownload(); break;
    case 'explore/report_delete':   $explore->reportDelete(); break;
    case 'explore/report_pdf': $explore->reportPdf(); break;
    ///case 'explore/visualize': $explore->visualize(); break;


    case 'explore/report_save_ajax':    $explore->reportSaveAjax(); break;
    case 'explore/report_attach_charts':$explore->reportAttachCharts(); break;
    case 'explore/report_chart':        $explore->reportChart(); break; // optional but recommended

    
    // JSON API for charts
    case 'api/histogram':    $api->histogram(); break;
    case 'api/value_counts': $api->valueCounts(); break;
    case 'api/scatter':      $api->scatter(); break;

    case 'explore/chart_data': $explore->chartData(); break;

    case 'api/column_profile': $api->columnProfile(); break;
    case 'explore/column_profile': $explore->columnProfile(); break;
    case 'api/col_profile':  $api->colProfile(); break;
    


    case 'explore/regression':  $explore->regression(); break;
    case 'explore/regression_save': $explore->regressionSave(); break;
    case 'explore/report_attach_regression': $explore->reportAttachRegression(); break;



    default:
        http_response_code(404);
        echo "404 Not Found. Unknown route: " . htmlspecialchars($route);
}
