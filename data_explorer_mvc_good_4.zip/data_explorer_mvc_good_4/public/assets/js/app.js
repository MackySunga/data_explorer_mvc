// public/assets/js/app.js

// ===========================
// Theme selector (Bootstrap + Bootswatch)
// ===========================
const THEMES = [
  { key: "bootstrap", name: "Bootstrap Default", url: "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" },
  { key: "cerulean",  name: "Cerulean",         url: "https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/cerulean/bootstrap.min.css" },
  { key: "cosmo",     name: "Cosmo",            url: "https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/cosmo/bootstrap.min.css" },
  { key: "flatly",    name: "Flatly",           url: "https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/flatly/bootstrap.min.css" },
  { key: "litera",    name: "Litera",           url: "https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/litera/bootstrap.min.css" },
  { key: "lumen",     name: "Lumen",            url: "https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/lumen/bootstrap.min.css" },
  { key: "minty",     name: "Minty",            url: "https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/minty/bootstrap.min.css" },
  { key: "sandstone", name: "Sandstone",        url: "https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/sandstone/bootstrap.min.css" },
  { key: "darkly",    name: "Darkly",           url: "https://cdn.jsdelivr.net/npm/bootswatch@5.3.3/dist/darkly/bootstrap.min.css" }
];

function setTheme(key) {
  const theme = THEMES.find(t => t.key === key) || THEMES[0];
  const link = document.getElementById("theme-css");
  if (link) link.href = theme.url;
  localStorage.setItem("de_theme", theme.key);
}

function initThemeMenu() {
  const saved = localStorage.getItem("de_theme") || "bootstrap";
  setTheme(saved);

  const menu = document.getElementById("theme-menu");
  if (!menu) return;

  menu.innerHTML = "";
  THEMES.forEach(t => {
    const li = document.createElement("li");
    const a = document.createElement("a");
    a.className = "dropdown-item";
    a.href = "#";
    a.textContent = t.name;
    a.addEventListener("click", (ev) => { ev.preventDefault(); setTheme(t.key); });
    li.appendChild(a);
    menu.appendChild(li);
  });
}

// ===========================
// Helpers
// ===========================
function getActiveDatasetId() {
  // 1) any element with data-dataset-id
  const el = document.querySelector("[data-dataset-id]");
  if (el) {
    const id = (el.getAttribute("data-dataset-id") || "").trim();
    if (id) return id;
  }

  // 2) meta tag fallback if you ever add it
  const meta = document.querySelector('meta[name="de-dataset-id"]');
  if (meta) {
    const id = (meta.getAttribute("content") || "").trim();
    if (id) return id;
  }

  return "";
}

async function waitFrames(n = 2) {
  for (let i = 0; i < n; i++) {
    await new Promise((r) => requestAnimationFrame(r));
  }
}

function resolveCanvasFromSelector(sel) {
  if (!sel) return null;

  let el = document.querySelector(sel);
  if (!el && sel.startsWith("#")) el = document.getElementById(sel.slice(1));
  if (!el) return null;

  if (el instanceof HTMLCanvasElement) return el;
  const c = el.querySelector("canvas");
  return (c instanceof HTMLCanvasElement) ? c : null;
}

async function captureCanvasPng(canvas) {
  if (!(canvas instanceof HTMLCanvasElement)) {
    throw new Error("captureCanvasPng: target is not a canvas.");
  }

  // If it's a Chart.js chart, force a no-animation update before capture
  if (window.Chart && typeof window.Chart.getChart === "function") {
    const ch = window.Chart.getChart(canvas);
    if (ch) ch.update("none");
  }

  await waitFrames(2);
  return canvas.toDataURL("image/png", 1.0);
}

// ===========================
// RegressionStore (localStorage)
// Saves the regression TABLES so PDF can include them
// ===========================
(function () {
  const KEY = "data_explorer_regression_v1";

  function loadAll() {
    try {
      const obj = JSON.parse(localStorage.getItem(KEY) || "{}");
      return (obj && typeof obj === "object") ? obj : {};
    } catch {
      return {};
    }
  }

  function saveAll(obj) {
    localStorage.setItem(KEY, JSON.stringify(obj || {}));
  }

  function get(datasetId) {
    const all = loadAll();
    return all[datasetId] || null;
  }

  function clear(datasetId) {
    const all = loadAll();
    if (datasetId) delete all[datasetId];
    saveAll(all);
  }

  function set(datasetId, payload) {
    if (!datasetId) return false;
    if (!payload || typeof payload !== "object") return false;

    // basic validation
    const y = String(payload.y || "").trim();
    const x = Array.isArray(payload.x) ? payload.x : [];
    const coeffs = Array.isArray(payload.coefficients) ? payload.coefficients : [];
    const rs = payload.regression_stats || null;
    const an = payload.anova || null;

    if (!y || !x.length) return false;
    if (!rs || !an || !coeffs.length) return false;

    const all = loadAll();
    all[datasetId] = {
      saved_at: new Date().toISOString(),
      ...payload
    };
    saveAll(all);
    return true;
  }

  window.RegressionStore = {
    loadAll,
    get,
    set,
    clear
  };
})();

// ===========================
// PDF Chart Queue (localStorage)
// Shared across Stats/Missing/Outliers/Correlation/Visualize/Regression
// ===========================
(function () {
  const KEY = "data_explorer_pdf_queue_v1";

  function load() {
    try {
      const v = JSON.parse(localStorage.getItem(KEY) || "[]");
      return Array.isArray(v) ? v : [];
    } catch {
      return [];
    }
  }

  function save(queue) {
    localStorage.setItem(KEY, JSON.stringify(queue || []));
  }

  function count() {
    return load().length;
  }

  function updateCountEls() {
    document.querySelectorAll("[data-queue-count]").forEach((el) => {
      el.textContent = String(count());
    });
  }

  function add(title, dataUrl) {
    const q = load();
    q.push({ title: String(title || "Chart"), dataUrl: String(dataUrl || "") });
    save(q);
    updateCountEls();
    return q.length;
  }

  function clear() {
    save([]);
    updateCountEls();
  }

  function removeAt(index) {
    const q = load();
    q.splice(index, 1);
    save(q);
    updateCountEls();
    return q;
  }

  async function downloadPdf(maxRows) {
    const q = load();
    const datasetId = getActiveDatasetId();

    const mr = Number.isFinite(parseInt(maxRows, 10)) ? parseInt(maxRows, 10) : 50000;

    // 1) Save report JSON (tables)
    const saveRes = await fetch("?r=explore/report_save_ajax&max_rows=" + encodeURIComponent(mr), { method: "POST" });
    const saveJson = await saveRes.json();
    if (!saveJson.ok) throw new Error(saveJson.error || "Failed to save report.");
    const reportFile = saveJson.file;

    // 2) Attach queued charts + regression (if present)
    const regression = (datasetId && window.RegressionStore) ? window.RegressionStore.get(datasetId) : null;

    const attachRes = await fetch("?r=explore/report_attach_charts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        file: reportFile,
        charts: q,
        regression: regression
      }),
    });
    const attachJson = await attachRes.json();
    if (!attachJson.ok) throw new Error(attachJson.error || "Failed to attach charts/regression.");

    // 3) Download PDF
    window.location.href = "?r=explore/report_pdf&file=" + encodeURIComponent(reportFile);
  }

  function bindOnce(el, key, handler) {
    const k = "bound_" + key;
    if (el.dataset[k] === "1") return;
    el.dataset[k] = "1";
    el.addEventListener("click", handler);
  }

  function bindButtons() {
    updateCountEls();

    // Add chart buttons
    document.querySelectorAll("[data-queue-add]").forEach((btn) => {
      bindOnce(btn, "queue_add", async () => {
        const sel = btn.getAttribute("data-queue-add");
        const canvas = resolveCanvasFromSelector(sel);

        if (!canvas) {
          alert("Chart canvas not found. Selector: " + sel);
          return;
        }

        const title =
          btn.getAttribute("data-queue-title") ||
          canvas.getAttribute("data-report-chart-title") ||
          "Chart";

        const dataUrl = await captureCanvasPng(canvas);
        add(title, dataUrl);

        const statusSel = btn.getAttribute("data-queue-status");
        if (statusSel) {
          const statusEl = document.querySelector(statusSel);
          if (statusEl) statusEl.textContent = "Added to queue: " + title;
        }
      });
    });

    // Clear queue buttons
    document.querySelectorAll("[data-queue-clear]").forEach((btn) => {
      bindOnce(btn, "queue_clear", () => {
        if (!confirm("Clear queued charts?")) return;
        clear();
      });
    });

    // Download PDF buttons
    document.querySelectorAll("[data-queue-download]").forEach((btn) => {
      bindOnce(btn, "queue_download", async () => {
        const old = btn.textContent;
        try {
          btn.disabled = true;
          btn.textContent = "Preparing PDF...";

          let mr = btn.getAttribute("data-maxrows");
          if (!mr) {
            const inp = document.querySelector('input[name="max_rows"]');
            if (inp) mr = inp.value;
          }

          await downloadPdf(mr);
        } catch (e) {
          console.error(e);
          alert(e?.message || String(e));
        } finally {
          btn.disabled = false;
          btn.textContent = old || "Download PDF (queued charts)";
        }
      });
    });
  }

  // ===========================
  // Regression page helpers
  // ===========================
  function readRegressionJson() {
    const el = document.getElementById("regression-json");
    if (!el) return null;
    try {
      return JSON.parse(el.textContent || "{}");
    } catch {
      return null;
    }
  }

  function setRegStatus(msg, isError = false) {
    const el = document.getElementById("regStatus");
    if (!el) return;
    el.textContent = msg || "";
    el.classList.toggle("text-danger", !!isError);
    el.classList.toggle("text-success", !isError && !!msg);
  }

  async function queueRegressionCharts() {
    // Remove old regression charts but keep other queued items.
    const cleaned = load().filter((item) => {
      const title = (item && typeof item.title === "string") ? item.title : "";
      return !title.startsWith("Regression:");
    });
    save(cleaned);
    updateCountEls();

    // these ids exist in your regression.php
    const charts = [
      { sel: "#chartResFit", title: "Regression: Residuals vs Fitted" },
      { sel: "#chartQQ",     title: "Regression: Q–Q Plot" },
      { sel: "#chartCook",   title: "Regression: Cook’s Distance" }
    ];

    for (const ch of charts) {
      const canvas = resolveCanvasFromSelector(ch.sel);
      if (!canvas) continue;
      const dataUrl = await captureCanvasPng(canvas);
      add(ch.title, dataUrl);
    }
  }

  function bindRegressionButtons() {
    // Save regression tables
    document.querySelectorAll("[data-reg-save]").forEach((btn) => {
      bindOnce(btn, "reg_save", async () => {
        const datasetId = getActiveDatasetId();
        const payload = readRegressionJson();

        if (!payload) {
          alert("Run regression first (no regression result found on page).");
          return;
        }
        if (!window.RegressionStore) {
          alert("RegressionStore not available (app.js not loaded).");
          return;
        }
        if (!datasetId) {
          alert("No active dataset id found. Go to Upload/Datasets and select a dataset first.");
          return;
        }

        const ok = window.RegressionStore.set(datasetId, payload);
        if (!ok) {
          alert("Failed to save regression (missing y/x or coefficients).");
          return;
        }

        setRegStatus("Regression saved for PDF.", false);
      });
    });

    // Queue regression charts
    document.querySelectorAll("[data-reg-queue]").forEach((btn) => {
      bindOnce(btn, "reg_queue", async () => {
        try {
          setRegStatus("Queuing regression charts...", false);
          await queueRegressionCharts();
          setRegStatus("Regression charts added to queue. (Queue: " + count() + ")", false);
        } catch (e) {
          console.error(e);
          setRegStatus(e?.message || String(e), true);
        }
      });
    });

    // One-click: save regression + queue charts + download PDF
    document.querySelectorAll("[data-reg-pdf]").forEach((btn) => {
      bindOnce(btn, "reg_pdf", async () => {
        const old = btn.textContent;
        try {
          btn.disabled = true;
          btn.textContent = "Preparing PDF...";

          const datasetId = getActiveDatasetId();
          const payload = readRegressionJson();

          if (!payload) throw new Error("Run regression first (no regression result found on page).");
          if (!window.RegressionStore) throw new Error("RegressionStore not available (app.js not loaded).");
          if (!datasetId) throw new Error("No active dataset id found. Select a dataset first.");

          const ok = window.RegressionStore.set(datasetId, payload);
          if (!ok) throw new Error("Failed to save regression (missing y/x or coefficients).");

          await queueRegressionCharts();

          // use max_rows input from regression form
          const inp = document.querySelector('input[name="max_rows"]');
          const mr = inp ? inp.value : "50000";

          await downloadPdf(mr);
        } catch (e) {
          console.error(e);
          alert(e?.message || String(e));
        } finally {
          btn.disabled = false;
          btn.textContent = old || "Download PDF (tables + charts)";
        }
      });
    });
  }

  // Expose for debugging
  window.ReportQueue = { load, save, count, add, clear, removeAt, downloadPdf, updateCountEls };
  window.resolveCanvasFromSelector = resolveCanvasFromSelector;
  window.captureCanvasPng = captureCanvasPng;

  document.addEventListener("DOMContentLoaded", () => {
    initThemeMenu();
    bindButtons();
    bindRegressionButtons();
  });
})();
